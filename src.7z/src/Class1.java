/* Class1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class1 {
    int anInt12;
    int anInt13;
    int anInt14;
    int anInt15;

    Class1(Class1 class1_0_) {
	((Class1) this).anInt13 = ((Class1) class1_0_).anInt13;
	((Class1) this).anInt12 = ((Class1) class1_0_).anInt12;
	((Class1) this).anInt14 = ((Class1) class1_0_).anInt14;
	((Class1) this).anInt15 = ((Class1) class1_0_).anInt15;
    }

    Class1() {
	/* empty */
    }
}
