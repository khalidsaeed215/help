/* Class110 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class110 implements Interface8 {
    protected String aString6400;
    protected String aString6401;
    protected String aString6402 = null;
    static int anInt6403;
    public static Class459 aClass459_6404;

    abstract void method1158(int i, int i_0_, Interface9 interface9);

    abstract void method1159(int i, Class233 class233);

    String method1160(int i) {
	try {
	    return aString6402;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("em.a(").append(')').toString());
	}
    }

    abstract void method1161(Class298_Sub31_Sub1 class298_sub31_sub1, float f, float f_1_);

    abstract void method1162(Class298_Sub31_Sub1 class298_sub31_sub1, float f, float f_2_, float f_3_);

    abstract void method1163(Class298_Sub31_Sub1 class298_sub31_sub1, float f, float f_4_, float f_5_, float f_6_);

    abstract void method1164(Class298_Sub31_Sub1 class298_sub31_sub1, float[] fs, int i);

    abstract void method1165(Class298_Sub31_Sub1 class298_sub31_sub1, float f, float f_7_, float f_8_, float f_9_);

    abstract void method1166(Class298_Sub31_Sub1 class298_sub31_sub1, Class233 class233);

    abstract void method1167(Class298_Sub31_Sub1 class298_sub31_sub1, int i, Interface9 interface9);

    abstract void method1168(int i, float f, float f_10_, float f_11_);

    abstract void method1169(int i, float f, float f_12_, float f_13_, float f_14_);

    abstract void method1170(int i, float[] fs, int i_15_);

    abstract void method1171(int i, Class233 class233);

    abstract void method1172(int i, Class233 class233);

    abstract void method1173(int i, Class233 class233);

    abstract void method1174(int i, int i_16_, Interface9 interface9);

    abstract void method1175(int i, Class233 class233);

    abstract void method1176(Class298_Sub31_Sub1 class298_sub31_sub1, float f);

    abstract void method1177(Class298_Sub31_Sub1 class298_sub31_sub1, float[] fs, int i);

    abstract void method1178(Class298_Sub31_Sub1 class298_sub31_sub1, float f, float f_17_, float f_18_, float f_19_);

    abstract void method1179(Class298_Sub31_Sub1 class298_sub31_sub1, float f, float f_20_, float f_21_);

    public abstract boolean method1180();

    abstract void method1181(Class298_Sub31_Sub1 class298_sub31_sub1, float f);

    abstract void method1182(int i, float[] fs, int i_22_);

    abstract void method1183(Class298_Sub31_Sub1 class298_sub31_sub1, float f);

    abstract void method1184(Class298_Sub31_Sub1 class298_sub31_sub1, int i, Interface9 interface9);

    abstract void method1185(Class298_Sub31_Sub1 class298_sub31_sub1, float f, float f_23_);

    abstract void method1186(Class298_Sub31_Sub1 class298_sub31_sub1, float f, float f_24_, float f_25_);

    abstract void method1187(Class298_Sub31_Sub1 class298_sub31_sub1, Class233 class233);

    abstract void method1188(Class298_Sub31_Sub1 class298_sub31_sub1, float f, float f_26_, float f_27_);

    abstract void method1189(Class298_Sub31_Sub1 class298_sub31_sub1, float f, float f_28_, float f_29_, float f_30_);

    abstract void method1190(Class298_Sub31_Sub1 class298_sub31_sub1, float f);

    abstract void method1191(Class298_Sub31_Sub1 class298_sub31_sub1, float f, float f_31_);

    abstract void method1192(Class298_Sub31_Sub1 class298_sub31_sub1, Class233 class233);

    abstract void method1193(Class298_Sub31_Sub1 class298_sub31_sub1, float f, float f_32_, float f_33_, float f_34_);

    abstract void method1194(Class298_Sub31_Sub1 class298_sub31_sub1, float f, float f_35_, float f_36_, float f_37_);

    abstract void method1195(int i, float f, float f_38_, float f_39_);

    abstract void method1196(Class298_Sub31_Sub1 class298_sub31_sub1, float[] fs, int i);

    abstract void method1197(Class298_Sub31_Sub1 class298_sub31_sub1, Class233 class233);

    abstract void method1198(Class298_Sub31_Sub1 class298_sub31_sub1, Class233 class233);

    abstract void method1199(int i, int i_40_, Interface9 interface9);

    abstract void method1200(Class298_Sub31_Sub1 class298_sub31_sub1, Class233 class233);

    Class110() {
	/* empty */
    }

    abstract void method1201(Class298_Sub31_Sub1 class298_sub31_sub1, Class233 class233);

    abstract void method1202(Class298_Sub31_Sub1 class298_sub31_sub1, Class233 class233);

    abstract void method1203(Class298_Sub31_Sub1 class298_sub31_sub1, Class233 class233);

    abstract void method1204(Class298_Sub31_Sub1 class298_sub31_sub1, Class233 class233);

    abstract void method1205(Class298_Sub31_Sub1 class298_sub31_sub1, float f, float f_41_, float f_42_, float f_43_);

    abstract void method1206(int i, float f, float f_44_, float f_45_);

    abstract void method1207(Class298_Sub31_Sub1 class298_sub31_sub1, float f);

    abstract void method1208(Class298_Sub31_Sub1 class298_sub31_sub1, int i, Interface9 interface9);

    public abstract boolean method1209();

    abstract void method1210(int i, float f, float f_46_, float f_47_);

    abstract void method1211(int i, float f, float f_48_, float f_49_);

    abstract void method1212(Class298_Sub31_Sub1 class298_sub31_sub1, int i, Interface9 interface9);

    abstract void method1213(int i, float f, float f_50_, float f_51_);

    abstract void method1214(int i, float[] fs, int i_52_);

    abstract void method1215(Class298_Sub31_Sub1 class298_sub31_sub1, Class233 class233);

    abstract void method1216(Class298_Sub31_Sub1 class298_sub31_sub1, Class233 class233);

    abstract void method1217(int i, Class233 class233);

    abstract void method1218(int i, int i_53_, Interface9 interface9);

    abstract void method1219(int i, float f, float f_54_, float f_55_);

    abstract void method1220(int i, int i_56_, Interface9 interface9);

    public abstract boolean method1221();

    abstract void method1222(int i, float f, float f_57_, float f_58_, float f_59_);

    public static void method1223(int i) {
	try {
	    Class390.method4876(22050, Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub22_7586.method5706((byte) -26) == 1, 2, 1957376607);
	    Class300.aClass284_3212 = Class75.method834(Class52_Sub2_Sub1.aCanvas9079, 0, 22050, -1310188777);
	    MagnetConfig.method777(true, Class8.method318(null, -1887308031), 1581194982);
	    Class3.aClass284_68 = Class75.method834(Class52_Sub2_Sub1.aCanvas9079, 1, 2048, -139744037);
	    Class285.aClass298_Sub19_Sub4_3083 = new Class298_Sub19_Sub4();
	    Class3.aClass284_68.method2679(Class285.aClass298_Sub19_Sub4_3083, 1746054467);
	    Class282.aClass270_6546 = new Class270(22050, 1164070869 * Class284.anInt3059);
	    Class14.method344(-874181924);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("em.a(").append(')').toString());
	}
    }

    static final void method1224(Class403 class403, int i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class318.method3875(class105, class119, class403, -1300595818);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("em.ch(").append(')').toString());
	}
    }

    static final void method1225(Class403 class403, int i) {
	try {
	    int i_60_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    ((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393 - 1)] = Class447.aClass469_5618.method6045(i_60_, (short) -5435).method3462((byte) -114);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("em.acl(").append(')').toString());
	}
    }

    static void method1226(int i, int i_61_, byte i_62_) {
	try {
	    if (HashTable.aClass371_5520.aBoolean4038 || (Class436.anInt5506 * -278777595 != 1 && (!Class396.aBoolean5196 || 2 != -278777595 * Class436.anInt5506 || !(((Class298_Sub37_Sub15) Class436.aClass298_Sub37_Sub15_5477).aString9667.equals(Tradution.aClass470_5910.method6049(Class321.aClass429_3357, -875414210)))))) {
		Class505 class505 = Class142.method1571(-2044946043);
		int i_63_ = (class505.method6264(Tradution.aClass470_5907.method6049(Class321.aClass429_3357, -875414210), -917382772));
		int i_64_;
		if (!Class436.aBoolean5471) {
		    for (Class298_Sub37_Sub15 class298_sub37_sub15 = ((Class298_Sub37_Sub15) Class436.aClass453_5480.method5939(1766612795)); null != class298_sub37_sub15; class298_sub37_sub15 = ((Class298_Sub37_Sub15) Class436.aClass453_5480.method5944(49146))) {
			int i_65_ = Class127_Sub1.method1425(class298_sub37_sub15, class505, 692106883);
			if (i_65_ > i_63_)
			    i_63_ = i_65_;
		    }
		    i_63_ += 8;
		    i_64_ = (-411680299 * Class436.anInt5467 * (Class436.anInt5506 * -278777595)) + 21;
		    Class448.anInt5619 = ((Class436.anInt5467 * -411680299 * (Class436.anInt5506 * -278777595)) + (Class436.aBoolean5496 ? 26 : 22)) * -893561885;
		} else {
		    for (Class298_Sub37_Sub5 class298_sub37_sub5 = ((Class298_Sub37_Sub5) Class436.aClass461_5482.first(-1195719541)); null != class298_sub37_sub5; class298_sub37_sub5 = ((Class298_Sub37_Sub5) Class436.aClass461_5482.next(1977524177))) {
			int i_66_;
			if (1 == (((Class298_Sub37_Sub5) class298_sub37_sub5).anInt9583) * -628325139)
			    i_66_ = (Class127_Sub1.method1425(((Class298_Sub37_Sub15) (((Class298_Sub37_Sub5) class298_sub37_sub5).aClass461_9584.aClass298_Sub37_5679.aClass298_Sub37_7405)), class505, 692106883));
			else
			    i_66_ = Class62.method728(class298_sub37_sub5, class505, 1340388103);
			if (i_66_ > i_63_)
			    i_63_ = i_66_;
		    }
		    i_63_ += 8;
		    i_64_ = (Class436.anInt5479 * 1592446965 * (Class436.anInt5467 * -411680299)) + 21;
		    Class448.anInt5619 = -893561885 * ((Class436.aBoolean5496 ? 26 : 22) + (Class436.anInt5467 * -411680299 * (Class436.anInt5479 * 1592446965)));
		}
		i_63_ += 10;
		int i_67_ = i - i_63_ / 2;
		if (i_63_ + i_67_ > Class462.anInt5683 * -2110394505)
		    i_67_ = -2110394505 * Class462.anInt5683 - i_63_;
		if (i_67_ < 0)
		    i_67_ = 0;
		int i_68_ = i_61_;
		if (i_68_ + i_64_ > -1111710645 * Class298_Sub40_Sub9.anInt9716)
		    i_68_ = Class298_Sub40_Sub9.anInt9716 * -1111710645 - i_64_;
		if (i_68_ < 0)
		    i_68_ = 0;
		Class88.anInt806 = 671566195 * i_67_;
		Class302_Sub4.anInt7658 = 1083843311 * i_68_;
		Class134.anInt6343 = i_63_ * 1077909003;
		Class436.anInt5498 = (int) (Math.random() * 24.0) * 704172827;
		Class436.aBoolean5478 = true;
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("em.r(").append(')').toString());
	}
    }

    static final void method1227(Class403 class403, int i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = class105.anInt1143 * 1354508417;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("em.os(").append(')').toString());
	}
    }
}
