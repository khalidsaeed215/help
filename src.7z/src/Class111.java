/* Class111 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class111 {
    public static Class111 idx_24;
    public static Class111 idx_8;
    public static Class111 idx_2;
    public static Class111 idx_3;
    public static Class111 idx_16;
    public static Class111 idx_5;
    public static Class111 idx_6;
    public static Class111 idx_10;
    public static Class111 idx_35;
    public static Class111 idx_9;
    public static Class111 idx_0 = new Class111(0);
    public static Class111 idx_11;
    public static Class111 idx_1 = new Class111(1);
    public static Class111 idx_13;
    public static Class111 idx_14;
    public static Class111 idx_15;
    public static Class111 idx_29;
    public static Class111 idx_17;
    public static Class111 idx_18;
    public static Class111 idx_20;
    public static Class111 idx_22;
    public static Class111 idx_21;
    public static Class111 idx_12;
    public static Class111 idx_31;
    public static Class111 idx_7;
    public static Class111 idx_25;
    public static Class111 idx_26;
    public static Class111 idx_27;
    public static Class111 idx_28;
    public static Class111 idx_30;
    public static Class111 idx_4;
    public static Class111 idx_19;
    public static Class111 idx_32;
    public static Class111 idx_33;
    public static Class111 idx_34;
    public static Class111 idx_23;
    public static Class111 idx_36;
    int anInt1366;
    static int anInt1367;

    static {
	idx_2 = new Class111(2);
	idx_3 = new Class111(3);
	idx_4 = new Class111(4);
	idx_5 = new Class111(5);
	idx_6 = new Class111(6);
	idx_7 = new Class111(7);
	idx_8 = new Class111(8);
	idx_9 = new Class111(9);
	idx_10 = new Class111(10);
	idx_11 = new Class111(11);
	idx_12 = new Class111(12);
	idx_13 = new Class111(13);
	idx_14 = new Class111(14);
	idx_15 = new Class111(15);
	idx_16 = new Class111(16);
	idx_17 = new Class111(17);
	idx_18 = new Class111(18);
	idx_19 = new Class111(19);
	idx_20 = new Class111(20);
	idx_21 = new Class111(21);
	idx_22 = new Class111(22);
	idx_23 = new Class111(23);
	idx_24 = new Class111(24);
	idx_25 = new Class111(25);
	idx_26 = new Class111(26);
	idx_27 = new Class111(27);
	idx_28 = new Class111(28);
	idx_29 = new Class111(29);
	idx_30 = new Class111(30);
	idx_31 = new Class111(31);
	idx_32 = new Class111(32);
	idx_33 = new Class111(33);
	idx_34 = new Class111(34);
	idx_35 = new Class111(35);
	idx_36 = new Class111(36);
	anInt1367 = 1700689323;
    }

    Class111(int i) {
	((Class111) this).anInt1366 = i * 1424986353;
    }

    public int method1233(int i) {
	try {
	    return ((Class111) this).anInt1366 * -1047699439;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("en.f(").append(')').toString());
	}
    }

    static final void method1234(Class403 class403, int i) {
	try {
	    int i_0_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    int i_1_ = pb.GRAND_EXCHANGE_SLOTS[i_0_].method2400(-574288948);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = i_1_ == 5 ? 1 : 0;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("en.ye(").append(')').toString());
	}
    }

    static final void method1235(IComponentDefinition class105, Class403 class403, byte i) {
	try {
	    Class505 class505 = class105.method1113(Class497.aClass197_6105, pb.anInterface10_8700, (byte) 88);
	    int i_2_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    int i_3_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    int i_4_ = class505.method6261(class105.aString1212, class105.anInt1156 * -2093041337, class105.anInt1191 * 418216501, i_3_, i_2_, Class130_Sub2.aClass57Array6959, (byte) -62);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = i_4_;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("en.qg(").append(')').toString());
	}
    }

    public static boolean method1236(int i, int i_5_) {
	try {
	    return (i >= -1976050083 * GameObjectType.T12.type && i <= GameObjectType.T17.type * -1976050083);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("en.d(").append(')').toString());
	}
    }

    static final void method1237(Class403 class403, int i) {
	try {
	    Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub13_7549, (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]), -800925761);
	    Class3.method300(656179282);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("en.aix(").append(')').toString());
	}
    }

    public static Class456[] method1238(Class457 class457, short i) {
	try {
	    int[] is = class457.method5961();
	    Class456[] class456s = new Class456[is.length >> 2];
	    for (int i_6_ = 0; i_6_ < class456s.length; i_6_++) {
		Class456 class456 = new Class456();
		class456s[i_6_] = class456;
		class456.anInt5663 = -1110150949 * is[i_6_ << 2];
		class456.anInt5665 = is[1 + (i_6_ << 2)] * 1756912603;
		class456.anInt5664 = 1912690475 * is[2 + (i_6_ << 2)];
		((Class456) class456).anInt5662 = 2041694879 * is[(i_6_ << 2) + 3];
	    }
	    return class456s;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("en.a(").append(')').toString());
	}
    }
}
