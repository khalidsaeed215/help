/* Class118 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public final class Class118 {
    static String aString1400 = "#";
    static int anInt1401;
    static Class88 aClass88_1402;

    Class118() throws Throwable {
	throw new Error();
    }

    static final void method1286(Class403 class403, int i) {
	try {
	    ((Class403) class403).anInt5239 -= -783761378;
	    if ((((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239]) < (((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239 + 1]))
		((Class403) class403).anInt5259 += (286750741 * (((Class403) class403).anIntArray5257[1883543357 * ((Class403) class403).anInt5259]));
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("eu.ax(").append(')').toString());
	}
    }

    static final void method1287(Class403 class403, int i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class410.method4981(class105, class119, class403, (byte) -2);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("eu.dq(").append(')').toString());
	}
    }

    static final void method1288(IComponentDefinition class105, Class119 class119, Class403 class403, int i) {
	try {
	    String string = (String) (((Class403) class403).anObjectArray5240[(((Class403) class403).anInt5241 -= 969361751) * -203050393]);
	    if (Class298_Sub6.method2863(string, class403, -1678737693) != null)
		string = string.substring(0, string.length() - 1);
	    class105.anObjectArray1240 = Class128_Sub2.method1441(string, class403, -2046058202);
	    class105.aBoolean1238 = true;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("eu.kk(").append(')').toString());
	}
    }

    static final void method1289(Class403 class403, int i) {
	try {
	    ((Class403) class403).anInt5239 -= -783761378;
	    int i_0_ = (((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919]);
	    int i_1_ = (((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919 + 1]);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = i_0_ | i_1_;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("eu.zp(").append(')').toString());
	}
    }

    static final void method1290(Class403 class403, byte i) {
	try {
	    int i_2_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = (Class298_Sub32_Sub14.aClass477_9400.getItemDefinitions(i_2_).anInt5735) * 1671807857;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("eu.aao(").append(')').toString());
	}
    }

    static final void method1291(Class403 class403, byte i) {
	try {
	    Class343_Sub1 class343_sub1 = Class385.method4716((byte) 21);
	    if (class343_sub1 != null) {
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = class343_sub1.anInt7717 * -15394297;
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = -877023375 * class343_sub1.anInt3670;
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = class343_sub1.aString7719;
		Class353 class353 = class343_sub1.method4163(-1326111472);
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = 1675394033 * class353.anInt3820;
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = class353.aString3819;
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = class343_sub1.anInt3666 * -945794709;
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = class343_sub1.anInt7720 * 512449113;
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = class343_sub1.aString7718;
	    } else {
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = -1;
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = "";
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = "";
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = "";
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("eu.alb(").append(')').toString());
	}
    }

    static final void method1292(Class403 class403, byte i) {
	try {
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = (((Class403) class403).aClass162_5252.getMemberID((String) (((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 -= 969361751) * -203050393)]), 131072));
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("eu.xt(").append(')').toString());
	}
    }

    public static void method1293(int i, int i_3_, int i_4_) {
	try {
	    Class301_Sub1.anInt7632 = (i - Class301_Sub1.anInt3245) * -433609607;
	    Class301_Sub1.anInt7627 = (i_3_ - Class301_Sub1.anInt3238) * -789877945;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("eu.ct(").append(')').toString());
	}
    }

    static final void method1294(Class403 class403, int i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class135.method1490(class105, class119, class403, 852607331);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("eu.gq(").append(')').toString());
	}
    }
}
