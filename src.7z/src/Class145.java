/* Class145 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class145 implements Interface5 {
    public int anInt6344;

    public Class146 method49(int i) {
	try {
	    return Class146.aClass146_1569;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("fw.f(").append(')').toString());
	}
    }

    public Class146 method51() {
	return Class146.aClass146_1569;
    }

    public Class146 method50() {
	return Class146.aClass146_1569;
    }

    Class145(int i) {
	anInt6344 = i * 1139226879;
    }

    static final void method1589(Class403 class403, byte i) {
	try {
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = pb.anInt8844 * 827374123;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("fw.ug(").append(')').toString());
	}
    }

    static final void method1590(Class403 class403, int i) {
	try {
	    if (pb.anInt8942 * 1131012101 == 0)
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = -1;
	    else
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = -548972447 * pb.anInt8952;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("fw.wl(").append(')').toString());
	}
    }

    static final void method1591(Class403 class403, int i) {
	try {
	    int i_0_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = (((Class403) class403).myClanChannel.members[i_0_].anInt1682) * -1333059205;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("fw.yb(").append(')').toString());
	}
    }

    static final void method1592(Class403 class403, byte i) {
	try {
	    int i_1_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = (int) (Math.random() * (double) (i_1_ + 1));
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("fw.yg(").append(')').toString());
	}
    }

    static final void method1593(Class403 class403, byte i) {
	try {
	    int i_2_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    Class298_Sub37_Sub8 class298_sub37_sub8 = Toolkit.aClass256_5315.method2441(i_2_, 415666693);
	    if (class298_sub37_sub8.anIntArray9598 == null)
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
	    else
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = class298_sub37_sub8.anIntArray9598.length;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("fw.acm(").append(')').toString());
	}
    }

    static final void method1594(Class403 class403, byte i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class373.method4606(class105, class119, class403, -919451749);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("fw.ej(").append(')').toString());
	}
    }

    static final void method1595(IComponentDefinition class105, Class119 class119, Class403 class403, int i) {
	try {
	    String string = (String) (((Class403) class403).anObjectArray5240[(((Class403) class403).anInt5241 -= 969361751) * -203050393]);
	    int[] is = Class298_Sub6.method2863(string, class403, -1732377635);
	    if (null != is)
		string = string.substring(0, string.length() - 1);
	    class105.anObjectArray1172 = Class128_Sub2.method1441(string, class403, -2046058202);
	    class105.anIntArray1254 = is;
	    class105.aBoolean1238 = true;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("fw.mg(").append(')').toString());
	}
    }

    static final void method1596(Class403 class403, int i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class240_Sub1.method2244(class105, class119, class403, (byte) -89);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("fw.op(").append(')').toString());
	}
    }

    static boolean method1597(Toolkit class_ra, int i, int i_3_) {
	try {
	    Class122.method1319((byte) 1);
	    if (!class_ra.method5041(2085922748))
		return false;
	    int i_4_ = pb.aClass283_8716.method2629(-2086391246);
	    int i_5_ = pb.aClass283_8716.method2630(-867392122);
	    Class244 class244 = pb.aClass283_8716.method2654(-202336440);
	    Class331 class331 = pb.aClass283_8716.method2675(-1611682495);
	    int i_6_ = i_4_ / 2;
	    int i_7_ = 0;
	    int i_8_ = 0;
	    boolean bool = true;
	    for (int i_9_ = i_7_; i_9_ < i_7_ + i_4_; i_9_++) {
		for (int i_10_ = i_8_; i_10_ < i_8_ + i_5_; i_10_++) {
		    for (int i_11_ = i; i_11_ <= 3; i_11_++) {
			if (class244.method2321(i, i_11_, i_9_, i_10_, (byte) -28)) {
			    int i_12_ = i_11_;
			    if (class244.method2320(i_9_, i_10_, -481959702))
				i_12_--;
			    if (i_12_ >= 0)
				bool &= Class271.method2543(i_12_, i_9_, i_10_, -1955757694);
			}
		    }
		}
	    }
	    if (!bool)
		return false;
	    int i_13_ = i_4_ * 4 + 48 + 48;
	    int[] is = new int[i_13_ * i_13_];
	    for (int i_14_ = 0; i_14_ < is.length; i_14_++)
		is[i_14_] = -16777216;
	    Class52_Sub1 class52_sub1 = null;
	    int i_15_ = 0;
	    int i_16_ = 0;
	    if (Class3.aBoolean55) {
		Class384.aClass57_4127 = class_ra.method5029(i_13_, i_13_, false, true);
		class52_sub1 = class_ra.method5094();
		class52_sub1.method563(0, Class384.aClass57_4127.method627());
		Interface8_Impl1_Impl2 interface8_impl1_impl2 = class_ra.method5186(i_13_, i_13_);
		class52_sub1.method558(interface8_impl1_impl2);
		class_ra.method5143(class52_sub1, (byte) 38);
		i_6_ = i_4_;
		i_15_ = 48;
		i_16_ = 48;
		class_ra.ba(1, 0);
	    } else
		Class384.aClass57_4127 = class_ra.method5031(is, 0, i_13_, i_13_, i_13_, -1797507809);
	    pb.aClass283_8716.method2640((byte) 105).method4326((byte) -128);
	    int i_17_ = ~0xffffff | ((238 + (int) (Math.random() * 20.0) - 10 << 16) + (238 + (int) (Math.random() * 20.0) - 10 << 8) + (238 + (int) (Math.random() * 20.0) - 10));
	    int i_18_ = ~0xffffff | 238 + (int) (Math.random() * 20.0) - 10 << 16;
	    int i_19_ = ((int) (Math.random() * 8.0) << 16 | (int) (Math.random() * 8.0) << 8 | (int) (Math.random() * 8.0));
	    boolean[][] bools = new boolean[1 + i_6_ + 2][2 + (i_6_ + 1)];
	    for (int i_20_ = i_7_; i_20_ < i_4_ + i_7_; i_20_ += i_6_) {
		for (int i_21_ = i_8_; i_21_ < i_5_ + i_8_; i_21_ += i_6_) {
		    int i_22_ = i_15_;
		    int i_23_ = i_16_;
		    int i_24_ = i_20_;
		    if (i_24_ > 0) {
			i_24_--;
			i_22_ += 4;
		    }
		    int i_25_ = i_21_;
		    if (i_25_ > 0)
			i_25_--;
		    int i_26_ = i_6_ + i_20_;
		    if (i_26_ < i_4_)
			i_26_++;
		    int i_27_ = i_21_ + i_6_;
		    if (i_27_ < i_5_) {
			i_27_++;
			i_23_ += 4;
		    }
		    if (Class3.aBoolean64)
			class_ra.L();
		    else
			class_ra.r(0, 0, i_6_ * 4 + i_22_, i_23_ + 4 * i_6_);
		    class_ra.ba(3, -16777216);
		    int i_28_ = i_6_;
		    if (i_28_ > i_4_ - 1)
			i_28_ = i_4_ - 1;
		    for (int i_29_ = i; i_29_ <= 3; i_29_++) {
			for (int i_30_ = 0; i_30_ <= i_28_; i_30_++) {
			    for (int i_31_ = 0; i_31_ <= i_28_; i_31_++)
				bools[i_30_][i_31_] = class244.method2321(i, i_29_, i_24_ + i_30_, i_25_ + i_31_, (byte) -51);
			}
			class331.aClass_xaArray3519[i_29_].method6339(i_15_, i_16_, 1024, i_24_, i_25_, i_26_, i_27_, bools);
			if (!Class3.aBoolean65) {
			    for (int i_32_ = -4; i_32_ < i_6_; i_32_++) {
				for (int i_33_ = -4; i_33_ < i_6_; i_33_++) {
				    int i_34_ = i_32_ + i_20_;
				    int i_35_ = i_21_ + i_33_;
				    if (i_34_ >= i_7_ && i_35_ >= i_8_ && class244.method2321(i, i_29_, i_34_, i_35_, (byte) -109)) {
					int i_36_ = i_29_;
					if (class244.method2320(i_34_, i_35_, 1967187214))
					    i_36_--;
					if (i_36_ >= 0)
					    Class70.method802(class_ra, i_36_, i_34_, i_35_, i_32_ * 4 + i_22_, (i_23_ + (i_6_ - i_33_) * 4 - 4), i_17_, i_18_, -2020733164);
				    }
				}
			    }
			}
		    }
		    if (Class3.aBoolean65) {
			Class289 class289 = pb.aClass283_8716.getSceneClipDataPlane(i);
			for (int i_37_ = 0; i_37_ < i_6_; i_37_++) {
			    for (int i_38_ = 0; i_38_ < i_6_; i_38_++) {
				int i_39_ = i_20_ + i_37_;
				int i_40_ = i_21_ + i_38_;
				int i_41_ = (class289.anIntArrayArray3155[i_39_ - (class289.anInt3151 * 1487776559)][i_40_ - (1415525851 * class289.anInt3152)]);
				if (0 != (i_41_ & 0x40240000))
				    class_ra.method5015(4 * i_37_ + i_22_, (i_23_ + 4 * (i_6_ - i_38_) - 4), 4, 4, -1713569622, (byte) 7);
				else if (0 != (i_41_ & 0x800000))
				    class_ra.method4990(i_37_ * 4 + i_22_, (i_23_ + 4 * (i_6_ - i_38_) - 4), 4, -1713569622, -1316601626);
				else if (0 != (i_41_ & 0x2000000))
				    class_ra.method5035(i_37_ * 4 + i_22_ + 3, (i_23_ + (i_6_ - i_38_) * 4 - 4), 4, -1713569622, (short) 18813);
				else if (0 != (i_41_ & 0x8000000))
				    class_ra.method4990(4 * i_37_ + i_22_, (i_23_ + 4 * (i_6_ - i_38_) - 4 + 3), 4, -1713569622, -1813788528);
				else if (0 != (i_41_ & 0x20000000))
				    class_ra.method5035(i_22_ + 4 * i_37_, ((i_6_ - i_38_) * 4 + i_23_ - 4), 4, -1713569622, (short) 29805);
			    }
			}
		    }
		    class_ra.B(i_22_, i_23_, i_6_ * 4, 4 * i_6_, i_19_, 2);
		    if (!Class3.aBoolean55) {
			Class384.aClass57_4127.method675((i_20_ - i_7_) * 4 + 48, 4 * i_5_ + 48 - (i_21_ - i_8_) * 4 - i_6_ * 4, i_6_ * 4, 4 * i_6_, i_22_, i_23_);
			if (Class3.aBoolean64) {
			    Class384.aClass57_4127.method645(256, 0);
			    try {
				class_ra.method4988((byte) -97);
				IPAddress.method6060(2000L);
			    }
			    catch (Exception exception) {
				/* empty */
			    }
			}
		    }
		}
	    }
	    if (Class3.aBoolean55) {
		class_ra.method5005(class52_sub1, (byte) 29);
		if (Class3.aBoolean64) {
		    Class384.aClass57_4127.method645(256, 0);
		    try {
			class_ra.method4988((byte) 39);
			IPAddress.method6060(2000L);
		    }
		    catch (Exception exception) {
			/* empty */
		    }
		}
	    }
	    class_ra.L();
	    class_ra.ba(1, 1);
	    Class360.method4301(-1595877635);
	    Class433 class433 = pb.aClass283_8716.method2641(-106767927);
	    Class3.anInt67 = 0;
	    Class3.aClass453_61.method5943((byte) 1);
	    if (!Class3.aBoolean65) {
		for (int i_42_ = i_7_; i_42_ < i_4_ + i_7_; i_42_++) {
		    for (int i_43_ = i_8_; i_43_ < i_5_ + i_8_; i_43_++) {
			for (int i_44_ = i; i_44_ <= 1 + i && i_44_ <= 3; i_44_++) {
			    if (class244.method2321(i, i_44_, i_42_, i_43_, (byte) -65)) {
				Interface3 interface3 = ((Interface3) class331.method4058(i_44_, i_42_, i_43_, (byte) 117));
				if (interface3 == null)
				    interface3 = ((Interface3) (class331.method4035(i_44_, i_42_, i_43_, pb.anInterface17_8960, -858481229)));
				if (interface3 == null)
				    interface3 = ((Interface3) class331.method4031(i_44_, i_42_, i_43_, 2125922883));
				if (interface3 == null)
				    interface3 = ((Interface3) class331.method4033(i_44_, i_42_, i_43_, 1080081135));
				if (interface3 != null) {
				    ObjectDefinitions class432 = (class433.getObjectDefinitions(interface3.method32((byte) -27)));
				    if (class432.aBoolean5434 && !pb.isMemberWorld) {
					if (i_3_ != 1177065502) {
					    /* empty */
					}
				    } else {
					int i_45_ = -1422593103 * class432.anInt5399;
					if (null != class432.morphisms) {
					    for (int i_46_ = 0; (i_46_ < (class432.morphisms).length); i_46_++) {
						if ((class432.morphisms[i_46_]) != -1) {
						    ObjectDefinitions class432_47_ = (class433.getObjectDefinitions((class432.morphisms[i_46_])));
						    if ((class432_47_.anInt5399 * -1422593103) >= 0)
							i_45_ = (-1422593103 * (class432_47_.anInt5399));
						}
					    }
					}
					if (i_45_ >= 0) {
					    boolean bool_48_ = false;
					    if (i_45_ >= 0) {
						Class352 class352 = (Class363.aClass339_3931.method4116(i_45_, -718907138));
						if (class352 != null && class352.aBoolean3791)
						    bool_48_ = true;
					    }
					    int i_49_ = i_42_;
					    int i_50_ = i_43_;
					    if (bool_48_) {
						int[][] is_51_ = (pb.aClass283_8716.getSceneClipDataPlane(i_44_).anIntArrayArray3155);
						int i_52_ = ((pb.aClass283_8716.getSceneClipDataPlane(i_44_).anInt3151) * 1487776559);
						int i_53_ = ((pb.aClass283_8716.getSceneClipDataPlane(i_44_).anInt3152) * 1415525851);
						for (int i_54_ = 0; i_54_ < 10; i_54_++) {
						    int i_55_ = (int) (Math.random() * 4.0);
						    if (i_55_ == 0 && i_49_ > i_7_ && i_49_ > i_42_ - 3 && 0 == ((is_51_[(i_49_ - 1 - i_52_)][(i_50_ - i_53_)]) & 0x2c0108))
							i_49_--;
						    if (1 == i_55_ && (i_49_ < i_4_ + i_7_ - 1) && i_49_ < i_42_ + 3 && 0 == ((is_51_[(1 + i_49_ - i_52_)][(i_50_ - i_53_)]) & 0x2c0180))
							i_49_++;
						    if (i_55_ == 2 && i_50_ > i_8_ && i_50_ > i_43_ - 3 && 0 == ((is_51_[(i_49_ - i_52_)][(i_50_ - 1 - i_53_)]) & 0x2c0102))
							i_50_--;
						    if (i_55_ == 3 && (i_50_ < i_5_ + i_8_ - 1) && i_50_ < 3 + i_43_ && 0 == ((is_51_[(i_49_ - i_52_)][(1 + i_50_ - i_53_)]) & 0x2c0120))
							i_50_++;
						}
					    }
					    Class3.anIntArray60[(Class3.anInt67 * 1659101557)] = (class432.objectId * 1181652947);
					    Class3.anIntArray58[1659101557 * Class3.anInt67] = i_49_;
					    Class3.anIntArray59[1659101557 * Class3.anInt67] = i_50_;
					    Class3.anInt67 += 1706239709;
					}
				    }
				}
			    }
			}
		    }
		}
		MapKeys class296 = pb.aClass283_8716.method2631(1336735501);
		if (null != class296) {
		    Class363.aClass339_3931.method4119(1024, 64, 1140719584);
		    WorldTile class341 = pb.aClass283_8716.method2628(681479919);
		    for (int i_56_ = 0; i_56_ < class296.anInt3169 * -1407078377; i_56_++) {
			int i_57_ = class296.keyTiles[i_56_];
			if ((Class287.myPlayer.plane) == i_57_ >> 28) {
			    int i_58_ = ((i_57_ >> 14 & 0x3fff) - class341.x * -1760580017);
			    int i_59_ = ((i_57_ & 0x3fff) - class341.y * 283514611);
			    if (i_58_ >= 0 && i_58_ < i_4_ && i_59_ >= 0 && i_59_ < i_5_)
				Class3.aClass453_61.add(new Class298_Sub35(i_56_));
			    else {
				Class352 class352 = (Class363.aClass339_3931.method4116(class296.keyIds[i_56_], -1340224758));
				if (null != class352.anIntArray3803 && (i_58_ + 968926443 * class352.anInt3793 >= 0)) {
				    if (i_58_ + 1281846757 * class352.anInt3804 >= i_4_) {
					if (i_3_ != 1177065502) {
					    /* empty */
					}
				    } else if (i_59_ + (-1294057761 * class352.anInt3807) >= 0) {
					if (i_59_ + (class352.anInt3805 * -1901940595) >= i_5_) {
					    if (i_3_ != 1177065502)
						throw new IllegalStateException();
					} else
					    Class3.aClass453_61.add(new Class298_Sub35(i_56_));
				    }
				}
			    }
			}
		    }
		    Class363.aClass339_3931.method4119(128, 64, 139589541);
		}
	    }
	    return true;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("fw.i(").append(')').toString());
	}
    }
}
