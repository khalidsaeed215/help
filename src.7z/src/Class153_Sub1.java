/* Class153_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class153_Sub1 extends Class153 {
    public void x() {
	/* empty */
    }

    public void b() {
	/* empty */
    }

    public void d() {
	/* empty */
    }

    Class153_Sub1(Class181[] class181s) {
	super(class181s);
    }

    public void u() {
	/* empty */
    }
}
