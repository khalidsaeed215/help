/* Class156 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class156 {
    void method1694() {
	/* empty */
    }

    Class156() throws Throwable {
	throw new Error();
    }
}
