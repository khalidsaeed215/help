/* Class166 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class166 {
    int anInt1701;
    int anInt1702 = 128;
    int anInt1703;
    int anInt1704;
    int anInt1705;
    int anInt1706;

    Class166 method1785() {
	return new Class166(((Class166) this).anInt1703, ((Class166) this).anInt1702, ((Class166) this).anInt1701, ((Class166) this).anInt1704, ((Class166) this).anInt1705, ((Class166) this).anInt1706);
    }

    Class166(int i, int i_0_, int i_1_, int i_2_, int i_3_, int i_4_) {
	((Class166) this).anInt1701 = 128;
	((Class166) this).anInt1703 = i;
	((Class166) this).anInt1702 = i_0_;
	((Class166) this).anInt1701 = i_1_;
	((Class166) this).anInt1704 = i_2_;
	((Class166) this).anInt1705 = i_3_;
	((Class166) this).anInt1706 = i_4_;
    }

    Class166(int i) {
	((Class166) this).anInt1701 = 128;
	((Class166) this).anInt1703 = i;
    }

    void method1786(Class166 class166_5_) {
	((Class166) this).anInt1702 = ((Class166) class166_5_).anInt1702;
	((Class166) this).anInt1701 = ((Class166) class166_5_).anInt1701;
	((Class166) this).anInt1704 = ((Class166) class166_5_).anInt1704;
	((Class166) this).anInt1705 = ((Class166) class166_5_).anInt1705;
	((Class166) this).anInt1703 = ((Class166) class166_5_).anInt1703;
	((Class166) this).anInt1706 = ((Class166) class166_5_).anInt1706;
    }
}
