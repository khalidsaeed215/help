/* Class18 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class18 {
    int anInt244;
    float aFloat245 = 1.0F;
    int anInt246;
    int anInt247;
    float aFloat248 = 1.0F;
    int anInt249;
    float aFloat250;
    int anInt251;
    int anInt252;
    int anInt253;
    int anInt254;
    static int cameraLookViewZ;

    Class18(int i, float f, float f_0_, int i_1_, int i_2_, int i_3_) {
	((Class18) this).anInt254 = i * -564629049;
	((Class18) this).aFloat245 = f;
	((Class18) this).aFloat248 = f_0_;
	((Class18) this).anInt247 = i_1_ * 1747422061;
	((Class18) this).anInt244 = 1370325433 * i_2_;
	((Class18) this).anInt249 = i_3_ * -839233607;
    }

    Class18 method355(int i) {
	try {
	    return new Class18(-1509687305 * ((Class18) this).anInt254, ((Class18) this).aFloat245, ((Class18) this).aFloat248, -1848560027 * ((Class18) this).anInt247, ((Class18) this).anInt244 * -1070844791, ((Class18) this).anInt249 * -988477815);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("as.a(").append(')').toString());
	}
    }

    void method356(Class18 class18_4_, int i) {
	try {
	    ((Class18) this).aFloat245 = ((Class18) class18_4_).aFloat245;
	    ((Class18) this).aFloat248 = ((Class18) class18_4_).aFloat248;
	    ((Class18) this).anInt247 = ((Class18) class18_4_).anInt247 * 1;
	    ((Class18) this).anInt244 = 1 * ((Class18) class18_4_).anInt244;
	    ((Class18) this).anInt254 = 1 * ((Class18) class18_4_).anInt254;
	    ((Class18) this).anInt249 = ((Class18) class18_4_).anInt249 * 1;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("as.f(").append(')').toString());
	}
    }

    Class18(int i) {
	((Class18) this).anInt254 = -564629049 * i;
    }

    static final void method357(Class403 class403, int i) {
	try {
	    ((Class403) class403).anInt5239 -= -783761378;
	    if ((((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919]) <= (((Class403) class403).anIntArray5244[1 + ((Class403) class403).anInt5239 * 681479919]))
		((Class403) class403).anInt5259 += (286750741 * (((Class403) class403).anIntArray5257[((Class403) class403).anInt5259 * 1883543357]));
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("as.ai(").append(')').toString());
	}
    }

    static String method358(int i, int i_5_, byte i_6_) {
	try {
	    int i_7_ = i_5_ - i;
	    if (i_7_ < -9)
		return Class285.method2709(16711680, -1412514938);
	    if (i_7_ < -6)
		return Class285.method2709(16723968, -1450525850);
	    if (i_7_ < -3)
		return Class285.method2709(16740352, -1831141729);
	    if (i_7_ < 0)
		return Class285.method2709(16756736, -1637160945);
	    if (i_7_ > 9)
		return Class285.method2709(65280, -1407228246);
	    if (i_7_ > 6)
		return Class285.method2709(4259584, -1287123002);
	    if (i_7_ > 3)
		return Class285.method2709(8453888, -1329263745);
	    if (i_7_ > 0)
		return Class285.method2709(12648192, -1738690779);
	    return Class285.method2709(16776960, -1985964349);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("as.bg(").append(')').toString());
	}
    }

    public static Class298_Sub36 method359(OutcommingPacket class198, IsaacCipher isaacCipher, byte i) {
	try {
	    Class298_Sub36 class298_sub36 = Class500.method6220((byte) 56);
	    ((Class298_Sub36) class298_sub36).aClass198_7401 = class198;
	    ((Class298_Sub36) class298_sub36).anInt7397 = ((OutcommingPacket) class198).length * -1035235683;
	    if (-1 == ((Class298_Sub36) class298_sub36).anInt7397 * 157188735)
		class298_sub36.aClass298_Sub53_Sub2_7396 = new RsBitsBuffer(260);
	    else if (((Class298_Sub36) class298_sub36).anInt7397 * 157188735 == -2)
		class298_sub36.aClass298_Sub53_Sub2_7396 = new RsBitsBuffer(10000);
	    else if (157188735 * ((Class298_Sub36) class298_sub36).anInt7397 <= 18)
		class298_sub36.aClass298_Sub53_Sub2_7396 = new RsBitsBuffer(20);
	    else if (((Class298_Sub36) class298_sub36).anInt7397 * 157188735 <= 98)
		class298_sub36.aClass298_Sub53_Sub2_7396 = new RsBitsBuffer(100);
	    else
		class298_sub36.aClass298_Sub53_Sub2_7396 = new RsBitsBuffer(260);
	    class298_sub36.aClass298_Sub53_Sub2_7396.method3665(isaacCipher, (byte) 74);
	    class298_sub36.aClass298_Sub53_Sub2_7396.method3668((((OutcommingPacket) ((Class298_Sub36) class298_sub36).aClass198_7401).id) * -1687656101, (byte) -23);
	    class298_sub36.anInt7399 = 0;
	    return class298_sub36;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("as.f(").append(')').toString());
	}
    }

    static final void method360(Class403 class403, int i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class79.method851(class105, class119, class403, -1849275031);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("as.em(").append(')').toString());
	}
    }

    static final void method361(Class403 class403, int i) {
	try {
	    ((Class403) class403).anInt5239 -= -783761378;
	    int i_8_ = (((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919]);
	    int i_9_ = (((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919 + 1]);
	    String string = (String) (((Class403) class403).anObjectArray5240[(((Class403) class403).anInt5241 -= 969361751) * -203050393]);
	    if (99 == i_8_)
		Class255.method2435(string, 1242487535);
	    else if (i_8_ == 98)
		Class422_Sub18.method5694(string, -1177455078);
	    else
		ChecksumTableEntry.method2282(i_8_, i_9_, "", "", "", string, -541387718);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("as.sy(").append(')').toString());
	}
    }

    public static void method362(String string, String string_10_, int i, boolean bool, int i_11_) {
	try {
	    if (pb.anInt8752 * -1233866115 == 8) {
		Class298_Sub36 class298_sub36 = method359(OutcommingPacket.aClass198_2072, pb.aClass25_8693.aClass449_330, (byte) 19);
		class298_sub36.aClass298_Sub53_Sub2_7396.writeShort(0, 16711935);
		int i_12_ = (385051775 * class298_sub36.aClass298_Sub53_Sub2_7396.index);
		class298_sub36.aClass298_Sub53_Sub2_7396.writeString(string, 2138689470);
		class298_sub36.aClass298_Sub53_Sub2_7396.writeString(string_10_, 2115793947);
		class298_sub36.aClass298_Sub53_Sub2_7396.writeByte(i);
		class298_sub36.aClass298_Sub53_Sub2_7396.writeByte(bool ? 1 : 0);
		class298_sub36.aClass298_Sub53_Sub2_7396.index += 814893177;
		class298_sub36.aClass298_Sub53_Sub2_7396.method3611(Class361.anIntArray3913, i_12_, (class298_sub36.aClass298_Sub53_Sub2_7396.index * 385051775), -1325657598);
		class298_sub36.aClass298_Sub53_Sub2_7396.method3593(385051775 * (class298_sub36.aClass298_Sub53_Sub2_7396.index) - i_12_, 1585504133);
		pb.aClass25_8693.method390(class298_sub36, (byte) -20);
		if (i < 13) {
		    pb.aBoolean8680 = true;
		    Class52_Sub1.method566((byte) 12);
		}
		Class357.aClass413_3845 = Class413.aClass413_6576;
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("as.i(").append(')').toString());
	}
    }
}
