/* Class184 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class184 {
    int anInt1892;
    int anInt1893;
    int anInt1894;
    int anInt1895;

    Class184() {
	/* empty */
    }
}
