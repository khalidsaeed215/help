/* Class189 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class189 {
    int anInt1914;
    int anInt1915;
    int anInt1916;

    Class189() {
	/* empty */
    }
}
