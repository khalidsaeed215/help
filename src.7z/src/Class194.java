/* Class194 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class194 {
    public static int anInt1953 = 17;
    public static int anInt1954 = 4;
    public static int anInt1955 = 20;
    public static int anInt1956 = 1;
    public static int anInt1957 = 21;
    public static int anInt1958 = 27;
    public static int anInt1959 = 28;
    public static int anInt1960 = 9;
    public static int anInt1961 = 7;
    public static int anInt1962 = 15;
    public static int anInt1963 = 26;
    public static int anInt1964 = 31;
    public static int anInt1965 = 12;
    public static int anInt1966 = 5;
    public static int anInt1967 = 14;
    public static int anInt1968 = 22;
    public static int anInt1969 = 23;
    public static int anInt1970 = 29;
    public static int anInt1971 = 32;
    public static int anInt1972 = 8;
    public static int anInt1973 = 16;
    public static int anInt1974 = 24;
    public static int anInt1975 = 33;
    public static int anInt1976 = 6;
    public static int anInt1977 = 11;
    public static int anInt1978 = 10;
    public static int anInt1979 = 18;
    public static int anInt1980 = 13;
    public static int anInt1981 = 25;
    public static int anInt1982 = 3;
    public static int anInt1983 = 2;
    public static int anInt1984 = 30;

    Class194() throws Throwable {
	throw new Error();
    }

    static final void method1863(Class403 class403, byte i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    SunDefinition.method1397(class105, class119, class403, 1051610527);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("if.np(").append(')').toString());
	}
    }

    static final void method1864(Class403 class403, int i) {
	try {
	    int i_0_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    IComponentDefinition class105 = Class50.getIComponentDefinitions(i_0_, (byte) 83);
	    Class119 class119 = Class389.aClass119Array4165[i_0_ >> 16];
	    Class324.method3958(class105, class119, class403, -389689371);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("if.oa(").append(')').toString());
	}
    }

    static final void method1865(Class403 class403, int i) {
	try {
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class298_Sub1.anInt7164 * -863531439 == 4 ? 1 : 0;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("if.agy(").append(')').toString());
	}
    }

    static final void method1866(Class403 class403, int i) {
	try {
	    int i_1_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub4_7563, i_1_, 965049953);
	    Class3.method300(656179282);
	    pb.aBoolean8666 = false;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("if.aih(").append(')').toString());
	}
    }

    public static void method1868(int i) {
	try {
	    Class170.method1808(1437455433);
	    Class436.aBoolean5478 = false;
	    Class227.method2112(Class88.anInt806 * -1347746885, Class302_Sub4.anInt7658 * 1089948687, 608683427 * Class134.anInt6343, 1396607435 * Class448.anInt5619, (byte) 2);
	    Class298_Sub45.aClass298_Sub37_Sub15_7522 = null;
	    Class318.aClass298_Sub37_Sub15_3322 = null;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("if.s(").append(')').toString());
	}
    }

    static final void method1869(Class403 class403, byte i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = class105.anInt1166 * 684246511;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("if.pd(").append(')').toString());
	}
    }

    static final void method1870(IComponentDefinition class105, Class119 class119, Class403 class403, byte i) {
	try {
	    class105.anInt1232 = (((Class403) class403).anIntArray5244[(((Class403) class403).anInt5239 -= -391880689) * 681479919]) * -7527659;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("if.jq(").append(')').toString());
	}
    }
}
