/* Class207 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class207 {
    public char aChar2358;
    public int anInt2359 = 0;

    void method1927(RsByteBuffer class298_sub53, int i) {
	try {
	    for (;;) {
		int i_0_ = class298_sub53.readUnsignedByte();
		if (0 == i_0_) {
		    if (i == -1903679241) {
			/* empty */
		    }
		    break;
		}
		method1928(class298_sub53, i_0_, -1399588257);
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("is.a(").append(')').toString());
	}
    }

    void method1928(RsByteBuffer class298_sub53, int i, int i_1_) {
	try {
	    if (1 == i)
		aChar2358 = Class493.method6190(class298_sub53.readByte(), 2055712019);
	    else if (5 == i)
		anInt2359 = class298_sub53.readUnsignedShort() * 1981336427;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("is.f(").append(')').toString());
	}
    }

    Class207() {
	/* empty */
    }

    static final void method1929(Class403 class403, int i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = class105.anInt1154 * -1309843523;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("is.pr(").append(')').toString());
	}
    }

    public static boolean method1930(int i, byte i_2_) {
	try {
	    return (i >= GameObjectType.T18.type * -1976050083 && i <= -1976050083 * GameObjectType.T21.type);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("is.u(").append(')').toString());
	}
    }

    static int method1931(Class343_Sub1 class343_sub1, Class343_Sub1 class343_sub1_3_, int i, boolean bool, int i_4_) {
	try {
	    if (1 == i) {
		int i_5_ = class343_sub1.anInt3666 * -945794709;
		int i_6_ = class343_sub1_3_.anInt3666 * -945794709;
		if (!bool) {
		    if (-1 == i_5_)
			i_5_ = 2001;
		    if (i_6_ == -1)
			i_6_ = 2001;
		}
		return i_5_ - i_6_;
	    }
	    if (i == 2)
		return Class26.method397((class343_sub1.method4163(1486003850).aString3819), (class343_sub1_3_.method4163(1779443598).aString3819), Class321.aClass429_3357, -1018238154);
	    if (3 == i) {
		if (class343_sub1.aString7719.equals("-")) {
		    if (class343_sub1_3_.aString7719.equals("-"))
			return 0;
		    return bool ? -1 : 1;
		}
		if (class343_sub1_3_.aString7719.equals("-"))
		    return bool ? 1 : -1;
		return Class26.method397(class343_sub1.aString7719, class343_sub1_3_.aString7719, Class321.aClass429_3357, -1275230374);
	    }
	    if (i == 4)
		return (class343_sub1.method4157(-963368374) ? class343_sub1_3_.method4157(740881863) ? 0 : 1 : class343_sub1_3_.method4157(229552705) ? -1 : 0);
	    if (i == 5)
		return (class343_sub1.method4155((byte) -26) ? class343_sub1_3_.method4155((byte) 52) ? 0 : 1 : class343_sub1_3_.method4155((byte) -31) ? -1 : 0);
	    if (i == 6)
		return (class343_sub1.method4156(1077942153) ? class343_sub1_3_.method4156(1938157273) ? 0 : 1 : class343_sub1_3_.method4156(807716549) ? -1 : 0);
	    if (i == 7)
		return (class343_sub1.method4158(1154945223) ? class343_sub1_3_.method4158(1235018049) ? 0 : 1 : class343_sub1_3_.method4158(2089010141) ? -1 : 0);
	    if (i == 8) {
		int i_7_ = class343_sub1.anInt7720 * 512449113;
		int i_8_ = 512449113 * class343_sub1_3_.anInt7720;
		if (bool) {
		    if (1000 == i_7_)
			i_7_ = -1;
		    if (1000 == i_8_)
			i_8_ = -1;
		} else {
		    if (i_7_ == -1)
			i_7_ = 1000;
		    if (i_8_ == -1)
			i_8_ = 1000;
		}
		return i_7_ - i_8_;
	    }
	    return (-15394297 * class343_sub1.anInt7717 - -15394297 * class343_sub1_3_.anInt7717);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("is.q(").append(')').toString());
	}
    }

    static final void method1932(Class403 class403, byte i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class148.method1616(class105, class119, class403, -1691554468);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("is.fk(").append(')').toString());
	}
    }

    public static String method1933(Class298_Sub37_Sub15 class298_sub37_sub15, int i) {
	try {
	    if (Class436.aBoolean5478 || null == class298_sub37_sub15)
		return "";
	    int[] is = Class313.method3821(class298_sub37_sub15, (byte) 10);
	    if (is == null)
		return "";
	    return Class216.method1999(is, (byte) 1);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("is.af(").append(')').toString());
	}
    }

    static final void method1934(Class403 class403, short i) {
	try {
	    ((Class403) class403).anInt5239 -= -783761378;
	    int i_9_ = (((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919]);
	    int i_10_ = (((Class403) class403).anIntArray5244[1 + 681479919 * ((Class403) class403).anInt5239]);
	    Class74.method830(i_9_, i_10_ >> 14 & 0x3fff, i_10_ & 0x3fff, true, 1858886715);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("is.aer(").append(')').toString());
	}
    }

    static final void method1935(Class403 class403, byte i) {
	try {
	    if (154600941 * Class12.aClass298_Sub44_9946.anInt7492 < 6)
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
	    else if (6 == 154600941 * Class12.aClass298_Sub44_9946.anInt7492 && (Class12.aClass298_Sub44_9946.anInt7494 * 1324779323 < 10))
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
	    else
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = 1;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("is.afd(").append(')').toString());
	}
    }
}
