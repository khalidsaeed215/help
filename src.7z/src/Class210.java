/* Class210 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class210 {
    static int anInt2396 = 9;
    static int anInt2397 = 2;
    static int anInt2398 = 5;
    static int anInt2399 = 1;
    static int anInt2400 = 4;
    static int anInt2401 = 11;
    static int anInt2402 = 7;
    static int anInt2403 = 3;
    static int anInt2404 = 10;
    static int anInt2405 = 6;
    static int anInt2406 = 8;

    Class210() throws Throwable {
	throw new Error();
    }

    static final void method1942(Class403 class403, int i) {
	try {
	    HashTable class437 = (((Class403) class403).aClass298_Sub37_Sub17_5260.aClass437Array9685[(((Class403) class403).anIntArray5257[1883543357 * ((Class403) class403).anInt5259])]);
	    Class298_Sub35 class298_sub35 = ((Class298_Sub35) class437.get((long) ((Class403) class403).anIntArray5244[(((Class403) class403).anInt5239 -= -391880689) * 681479919]));
	    if (null != class298_sub35)
		((Class403) class403).anInt5259 += -1065839893 * class298_sub35.anInt7394;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("iw.bd(").append(')').toString());
	}
    }

    static final void method1943(Class403 class403, byte i) {
	try {
	    int i_0_ = (((Class403) class403).anIntArray5257[1883543357 * ((Class403) class403).anInt5259]);
	    Long var_long = (((Class403) class403).aClass162_5252.method1766(-937307905 * pb.gametype.gameType << 16 | i_0_, -2092321657));
	    long l;
	    if (null == var_long)
		l = -1L;
	    else
		l = var_long.longValue();
	    ((Class403) class403).aLongArray5251[((((Class403) class403).anInt5245 += -682569305) * 1685767703 - 1)] = l;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("iw.bn(").append(')').toString());
	}
    }

    static final void method1944(Class403 class403, int i) {
	try {
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub22_7586.method5706((byte) -7) == 1 ? 1 : 0;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("iw.aji(").append(')').toString());
	}
    }

    static final void method1945(Class403 class403, int i) {
	try {
	    ((Class403) class403).anInt5239 -= -783761378;
	    int i_1_ = (((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919]);
	    int i_2_ = ((((Class403) class403).anIntArray5244[1 + 681479919 * ((Class403) class403).anInt5239]) - 1);
	    ItemDefinitions class468 = Class298_Sub32_Sub14.aClass477_9400.getItemDefinitions(i_1_);
	    if (i_2_ == 690460599 * class468.anInt5736)
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = -1953923599 * class468.anInt5727;
	    else if (i_2_ == class468.anInt5722 * 1689294225)
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = class468.anInt5728 * -1824861577;
	    else
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = -1;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("iw.aaq(").append(')').toString());
	}
    }
}
