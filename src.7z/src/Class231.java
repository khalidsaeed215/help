/* Class231 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.Frame;

public class Class231 {
    public static int anInt2569 = 5;
    public static int anInt2570 = 6;
    public static int anInt2571 = 7;
    public static int anInt2572 = 19;
    public static int anInt2573 = 1;
    public static int anInt2574 = 4;
    public static int anInt2575 = 13;
    public static int anInt2576 = 17;
    public static int anInt2577 = 15;
    public static int anInt2578 = 18;
    public static int anInt2579 = 10;
    public static int anInt2580 = 0;
    public static int anInt2581 = 3;
    public static int anInt2582 = 14;
    public static int anInt2583 = 16;
    public static int anInt2584 = 11;
    public static int anInt2585 = 12;
    public static int anInt2586 = 2;
    public static int anInt2587 = 8;
    public static int anInt2588 = 9;
    public static Frame aFrame2589;

    Class231() throws Throwable {
	throw new Error();
    }

    static void method2128(Class403 class403, int i) {
	try {
	    ((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919 - 1] = (Class316.aClass362_3318.method4307((((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919 - 1]), 245040087).method4569(Class128.aClass148_6331, -1502876946) ? 1 : 0);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("jt.q(").append(')').toString());
	}
    }

    static final void method2129(Class403 class403, int i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class363.method4314(class105, class119, class403, 542274926);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("jt.ic(").append(')').toString());
	}
    }

    static final void method2130(Class403 class403, byte i) {
	try {
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub8_7566.method5653(-621430736) ? 1 : 0;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("jt.ani(").append(')').toString());
	}
    }

    static final void method2131(IComponentDefinition class105, Class119 class119, Class403 class403, int i) {
	try {
	    String string = (String) (((Class403) class403).anObjectArray5240[(((Class403) class403).anInt5241 -= 969361751) * -203050393]);
	    if (Class298_Sub6.method2863(string, class403, -124648569) != null)
		string = string.substring(0, string.length() - 1);
	    class105.anObjectArray1267 = Class128_Sub2.method1441(string, class403, -2046058202);
	    class105.aBoolean1238 = true;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("jt.mz(").append(')').toString());
	}
    }

    static final void method2132(byte i, int i_0_) {
	try {
	    byte[][][] is = pb.aClass283_8716.method2642(1521051054);
	    if (is == null) {
		is = (new byte[4][pb.aClass283_8716.method2629(-1981468107)][pb.aClass283_8716.method2630(1256544033)]);
		pb.aClass283_8716.method2643(is, 1496940593);
	    }
	    for (int i_1_ = 0; i_1_ < 4; i_1_++) {
		for (int i_2_ = 0; i_2_ < pb.aClass283_8716.method2629(-2064419081); i_2_++) {
		    for (int i_3_ = 0; i_3_ < pb.aClass283_8716.method2630(764955570); i_3_++)
			is[i_1_][i_2_][i_3_] = i;
		}
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("jt.im(").append(')').toString());
	}
    }

    static final void method2133(Class403 class403, int i) {
	try {
	    ((Class403) class403).anInt5239 -= -783761378;
	    int i_4_ = (((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239]);
	    int i_5_ = (((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919 + 1]);
	    if (Class287.myPlayer.aClass366_10209 != null)
		Class287.myPlayer.aClass366_10209.method4539(i_4_, i_5_, (byte) 108);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("jt.co(").append(')').toString());
	}
    }

    static final void method2134(Class403 class403, int i) {
	try {
	    int i_6_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    if (pb.anInt8942 * 1131012101 == 2 && i_6_ < -1054937867 * pb.anInt8941) {
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = pb.aStringArray8704[i_6_];
		if (pb.aStringArray8945[i_6_] != null)
		    ((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = pb.aStringArray8945[i_6_];
		else
		    ((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = "";
	    } else {
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = "";
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = "";
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("jt.vp(").append(')').toString());
	}
    }
}
