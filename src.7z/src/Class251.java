/* Class251 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class251 {
    byte aByte2767;
    public int anInt2768;
    public int anInt2769;
    public int anInt2770;
    public int anInt2771;
    public int anInt2772;
    public static Class524 aClass524_2773;

    public Class251(RsByteBuffer class298_sub53) {
	((Class251) this).aByte2767 = class298_sub53.readByte();
	anInt2768 = class298_sub53.readUnsignedShort() * -1745142161;
	anInt2769 = class298_sub53.readInt((byte) -69) * 1614840625;
	anInt2770 = class298_sub53.readInt((byte) 31) * -720550021;
	anInt2771 = class298_sub53.readInt((byte) 13) * -381867285;
	anInt2772 = class298_sub53.readInt((byte) -44) * 822515113;
    }

    public int method2400(int i) {
	try {
	    return ((Class251) this).aByte2767 & 0x7;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("km.a(").append(')').toString());
	}
    }

    public Class251() {
	/* empty */
    }

    public int method2401(byte i) {
	try {
	    return (((Class251) this).aByte2767 & 0x8) == 8 ? 1 : 0;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("km.f(").append(')').toString());
	}
    }

    public static void method2402(byte i) {
	try {
	    synchronized (Class366.aClass348_3979) {
		Class366.aClass348_3979.method4187();
	    }
	    synchronized (Class366.aClass348_3980) {
		Class366.aClass348_3980.method4187();
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("km.n(").append(')').toString());
	}
    }

    static char method2403(char c, byte i) {
	try {
	    if ('\u00c6' == c)
		return 'E';
	    if (c == '\u00e6')
		return 'e';
	    if (c == '\u00df')
		return 's';
	    if ('\u0152' == c)
		return 'E';
	    if ('\u0153' == c)
		return 'e';
	    return '\0';
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("km.b(").append(')').toString());
	}
    }

    static final void method2404(Class403 class403, int i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    MagnetConfig.method782(class105, class119, class403, -1060016490);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("km.nj(").append(')').toString());
	}
    }

    static final void method2405(Class403 class403, int i) {
	try {
	    ((Class403) class403).anInt5239 -= 1943683162;
	    int i_0_ = (((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239]);
	    if (i_0_ >= 2)
		throw new RuntimeException();
	    pb.anInt8768 = 1723181617 * i_0_;
	    int i_1_ = (((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239 + 1]);
	    if (i_1_ + 1 >= (pb.anIntArrayArrayArray8767[-591434031 * pb.anInt8768]).length >> 1)
		throw new RuntimeException();
	    pb.anInt8770 = i_1_ * -2146952741;
	    pb.anInt8857 = 0;
	    pb.anInt8852 = ((((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239 + 2]) * -2045228877);
	    pb.anInt8774 = (-546154255 * (((Class403) class403).anIntArray5244[3 + 681479919 * ((Class403) class403).anInt5239]));
	    int i_2_ = (((Class403) class403).anIntArray5244[4 + 681479919 * ((Class403) class403).anInt5239]);
	    if (i_2_ >= 2)
		throw new RuntimeException();
	    pb.anInt8769 = -2694169 * i_2_;
	    int i_3_ = (((Class403) class403).anIntArray5244[5 + 681479919 * ((Class403) class403).anInt5239]);
	    if (1 + i_3_ >= (pb.anIntArrayArrayArray8767[-839811113 * pb.anInt8769]).length >> 1)
		throw new RuntimeException();
	    pb.anInt8771 = i_3_ * -274142709;
	    Class298_Sub1.anInt7164 = -734758223;
	    Class418.anInt5339 = -1001372047;
	    Class100.anInt1081 = 178575833;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("km.agi(").append(')').toString());
	}
    }

    static final void method2406(int i, int i_4_, int i_5_, int i_6_, int i_7_) {
	try {
	    int i_8_ = -933698717 * pb.anInt8784;
	    int i_9_ = 1036219865 * pb.anInt8785;
	    if (1 == pb.anInt8748 * -392325587) {
		Sprite class57 = (Class82_Sub11.aClass57Array6861[pb.anInt8786 * 1347929875 / 100]);
		class57.method645(i_8_ - 8, i_9_ - 8);
	    }
	    if (2 == pb.anInt8748 * -392325587) {
		Sprite class57 = (Class82_Sub11.aClass57Array6861[4 + pb.anInt8786 * 1347929875 / 100]);
		class57.method645(i_8_ - 8, i_9_ - 8);
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("km.jr(").append(')').toString());
	}
    }

    static final void method2407(Class403 class403, byte i) {
	try {
	    int i_10_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub16_7557.method5612(i_10_, 1352882135);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("km.aor(").append(')').toString());
	}
    }

    static final void method2408(Class403 class403, int i) {
	try {
	    ((Class403) class403).anInt5239 -= -783761378;
	    Class344.method4165((((Class403) class403).anIntArray5244[(681479919 * ((Class403) class403).anInt5239)]), (((Class403) class403).anIntArray5244[1 + (681479919 * ((Class403) class403).anInt5239)]), 0, -1721946915);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("km.agz(").append(')').toString());
	}
    }
}
