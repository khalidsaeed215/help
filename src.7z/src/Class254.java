/* Class254 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class254 {
    static Class254 aClass254_2786;
    public static Class254 aClass254_2787 = new Class254(0);
    int anInt2788;
    static Class277 aClass277_2789;
    public static boolean[] aBooleanArray2790;

    Class254(int i) {
	((Class254) this).anInt2788 = i * -2064479007;
    }

    static {
	aClass254_2786 = new Class254(1);
    }

    static final void method2423(Class403 class403, short i) {
	try {
	    ((Class403) class403).anInt5239 -= -1175642067;
	    int i_0_ = (((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239]);
	    int i_1_ = (((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919 + 1]);
	    int i_2_ = (((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919 + 2]);
	    if (i_1_ == -1)
		throw new RuntimeException();
	    ClientScriptMap class483 = Class51.aClass475_506.getClientScriptMap(i_1_, 1528209569);
	    if (class483.aChar6037 != i_0_)
		throw new RuntimeException();
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = (class483.method6127(Integer.valueOf(i_2_), (byte) 94) ? 1 : 0);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("kq.vo(").append(')').toString());
	}
    }

    static final void method2424(Class403 class403, short i) {
	try {
	    int i_3_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class364.method4334((char) i_3_, -401787251) ? 1 : 0;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("kq.aaz(").append(')').toString());
	}
    }

    static final void method2425(Class403 class403, int i) {
	try {
	    ((Class403) class403).anInt5241 -= -1386882043;
	    Class23.method377((String) (((Class403) class403).anObjectArray5240[((Class403) class403).anInt5241 * -203050393]), (String) (((Class403) class403).anObjectArray5240[1 + -203050393 * ((Class403) class403).anInt5241]), (String) (((Class403) class403).anObjectArray5240[-203050393 * ((Class403) class403).anInt5241 + 2]), (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]) == 1, true, (byte) -43);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("kq.afy(").append(')').toString());
	}
    }

    static final void method2426(Class403 class403, byte i) {
	try {
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class459.method5977((byte) 79).getType(694163818);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("kq.ahl(").append(')').toString());
	}
    }

    static boolean method2427(String string, int i, byte i_4_) {
	try {
	    return Class65.method762(string, i, "openjs", -2106380529);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("kq.b(").append(')').toString());
	}
    }

    static final void method2428(Class403 class403, int i) {
	try {
	    Class320.method3910(-174138334);
	    pb.aClass283_8716.method2667(1331773815);
	    Class3.method300(656179282);
	    pb.aBoolean8666 = false;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("kq.anq(").append(')').toString());
	}
    }
}
