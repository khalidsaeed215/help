/* Class257 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class257 {
    static int anInt2802;
    int anInt2803;
    int anInt2804;
    int[][] anIntArrayArray2805;
    static Class298_Sub39 aClass298_Sub39_2806 = new Class298_Sub39(0, 0);
    int anInt2807;
    int anInt2808 = 0;
    Class458 aClass458_2809;
    public boolean aBoolean2810;
    Class298_Sub39[] aClass298_Sub39Array2811;

    final void method2447(int i) {
	try {
	    for (int i_0_ = 0; i_0_ < ((Class257) this).anInt2804 * -1845310689; i_0_++)
		((Class257) this).anIntArrayArray2805[i_0_] = null;
	    ((Class257) this).aClass298_Sub39Array2811 = null;
	    ((Class257) this).anIntArrayArray2805 = null;
	    ((Class257) this).aClass458_2809.method5972(-1936025325);
	    ((Class257) this).aClass458_2809 = null;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("kt.a(").append(')').toString());
	}
    }

    public final int[] method2448(int i, int i_1_) {
	try {
	    if (((Class257) this).anInt2804 * -1845310689 != ((Class257) this).anInt2803 * 1036538653) {
		if (((Class257) this).anInt2804 * -1845310689 != 1) {
		    Class298_Sub39 class298_sub39 = ((Class257) this).aClass298_Sub39Array2811[i];
		    if (class298_sub39 == null) {
			aBoolean2810 = true;
			if (((Class257) this).anInt2808 * 851327335 >= -1845310689 * ((Class257) this).anInt2804) {
			    Class298_Sub39 class298_sub39_2_ = ((Class298_Sub39) ((Class257) this).aClass458_2809.method5964(975410288));
			    class298_sub39 = new Class298_Sub39(i, ((((Class298_Sub39) class298_sub39_2_).anInt7419) * -1113693749));
			    ((Class257) this).aClass298_Sub39Array2811[1544880463 * ((Class298_Sub39) class298_sub39_2_).anInt7418] = null;
			    class298_sub39_2_.method2839(-1460969981);
			} else {
			    class298_sub39 = new Class298_Sub39(i, (((Class257) this).anInt2808) * 851327335);
			    ((Class257) this).anInt2808 += -1189293481;
			}
			((Class257) this).aClass298_Sub39Array2811[i] = class298_sub39;
		    } else
			aBoolean2810 = false;
		    ((Class257) this).aClass458_2809.method5965(class298_sub39, 943102582);
		    return (((Class257) this).anIntArrayArray2805[(-1113693749 * ((Class298_Sub39) class298_sub39).anInt7419)]);
		}
		aBoolean2810 = i != ((Class257) this).anInt2807 * -101586551;
		((Class257) this).anInt2807 = i * 2063162553;
		return ((Class257) this).anIntArrayArray2805[0];
	    }
	    aBoolean2810 = null == ((Class257) this).aClass298_Sub39Array2811[i];
	    ((Class257) this).aClass298_Sub39Array2811[i] = aClass298_Sub39_2806;
	    return ((Class257) this).anIntArrayArray2805[i];
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("kt.f(").append(')').toString());
	}
    }

    public final int[][] method2449(int i) {
	try {
	    if (1036538653 * ((Class257) this).anInt2803 != -1845310689 * ((Class257) this).anInt2804)
		throw new RuntimeException();
	    for (int i_3_ = 0; i_3_ < -1845310689 * ((Class257) this).anInt2804; i_3_++)
		((Class257) this).aClass298_Sub39Array2811[i_3_] = aClass298_Sub39_2806;
	    return ((Class257) this).anIntArrayArray2805;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("kt.b(").append(')').toString());
	}
    }

    Class257(int i, int i_4_, int i_5_) {
	((Class257) this).anInt2807 = -2063162553;
	((Class257) this).aClass458_2809 = new Class458();
	aBoolean2810 = false;
	((Class257) this).anInt2803 = i_4_ * -1955264715;
	((Class257) this).anInt2804 = i * -1906511649;
	((Class257) this).anIntArrayArray2805 = new int[-1845310689 * ((Class257) this).anInt2804][i_5_];
	((Class257) this).aClass298_Sub39Array2811 = new Class298_Sub39[((Class257) this).anInt2803 * 1036538653];
    }

    static void method2450(Class403 class403, short i) {
	try {
	    ((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393 - 1)] = (Class316.aClass362_3318.method4307((((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919 - 2]), 245040087).aStringArray4026[(((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239 - 1])]);
	    ((Class403) class403).anInt5239 -= -783761378;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("kt.e(").append(')').toString());
	}
    }

    static final void method2451(IComponentDefinition class105, Class119 class119, Class403 class403, int i) {
	try {
	    String string = (String) (((Class403) class403).anObjectArray5240[(((Class403) class403).anInt5241 -= 969361751) * -203050393]);
	    if (Class298_Sub6.method2863(string, class403, -1163069607) != null)
		string = string.substring(0, string.length() - 1);
	    class105.anObjectArray1271 = Class128_Sub2.method1441(string, class403, -2046058202);
	    class105.aBoolean1238 = true;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("kt.ob(").append(')').toString());
	}
    }

    static final void method2452(Class403 class403, int i) {
	try {
	    int i_6_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    ItemDefinitions class468 = Class298_Sub32_Sub14.aClass477_9400.getItemDefinitions(i_6_);
	    if (-1673957995 * class468.anInt5755 >= 0 && 809765849 * class468.anInt5709 >= 0)
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = class468.anInt5709 * 809765849;
	    else
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = i_6_;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("kt.aag(").append(')').toString());
	}
    }

    static final void method2453(boolean bool, byte i) {
	try {
	    Class95.method1033(pb.WINDOW_PANE_ID * -257444687, -2110394505 * Class462.anInt5683, Class298_Sub40_Sub9.anInt9716 * -1111710645, bool, 1828905535);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("kt.kg(").append(')').toString());
	}
    }

    static final void method2454(Class403 class403, int i) {
	try {
	    int i_7_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    MapDetails class298_sub37_sub13 = Class298_Sub7.method2864(-1164141102);
	    if (null != class298_sub37_sub13) {
		boolean bool = class298_sub37_sub13.method3453(i_7_ >> 28 & 0x3, i_7_ >> 14 & 0x3fff, i_7_ & 0x3fff, Class388.anIntArray4156, 1911692873);
		if (bool) {
		    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = Class388.anIntArray4156[1];
		    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = Class388.anIntArray4156[2];
		} else {
		    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = -1;
		    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = -1;
		}
	    } else {
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = -1;
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = -1;
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("kt.aep(").append(')').toString());
	}
    }
}
