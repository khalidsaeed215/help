/* Class258 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import jaggl.OpenGL;

public class Class258 implements Interface8_Impl1_Impl1_Impl3 {
    Class263_Sub4 aClass263_Sub4_10176;
    int anInt10177;

    public void method167(int i) {
	OpenGL.glFramebufferTexture2DEXT(36160, i, (((Class263_Sub4) ((Class258) this).aClass263_Sub4_10176).anInt6415), (((Class263_Sub4) ((Class258) this).aClass263_Sub4_10176).anInt6417), ((Class258) this).anInt10177);
    }

    public int a() {
	return ((Class258) this).aClass263_Sub4_10176.method92();
    }

    public int f() {
	return ((Class258) this).aClass263_Sub4_10176.method76();
    }

    public void x() {
	/* empty */
    }

    public void b() {
	/* empty */
    }

    public int p() {
	return ((Class258) this).aClass263_Sub4_10176.method92();
    }

    public int i() {
	return ((Class258) this).aClass263_Sub4_10176.method92();
    }

    public void method165(int i) {
	OpenGL.glFramebufferTexture2DEXT(36160, i, (((Class263_Sub4) ((Class258) this).aClass263_Sub4_10176).anInt6415), (((Class263_Sub4) ((Class258) this).aClass263_Sub4_10176).anInt6417), ((Class258) this).anInt10177);
    }

    public int k() {
	return ((Class258) this).aClass263_Sub4_10176.method76();
    }

    public void u() {
	/* empty */
    }

    public void d() {
	/* empty */
    }

    Class258(Class263_Sub4 class263_sub4, int i) {
	((Class258) this).anInt10177 = i;
	((Class258) this).aClass263_Sub4_10176 = class263_sub4;
    }

    public void method166(int i) {
	OpenGL.glFramebufferTexture2DEXT(36160, i, (((Class263_Sub4) ((Class258) this).aClass263_Sub4_10176).anInt6415), (((Class263_Sub4) ((Class258) this).aClass263_Sub4_10176).anInt6417), ((Class258) this).anInt10177);
    }

    public void method168(int i) {
	OpenGL.glFramebufferTexture2DEXT(36160, i, (((Class263_Sub4) ((Class258) this).aClass263_Sub4_10176).anInt6415), (((Class263_Sub4) ((Class258) this).aClass263_Sub4_10176).anInt6417), ((Class258) this).anInt10177);
    }

    public void method164(int i) {
	OpenGL.glFramebufferTexture2DEXT(36160, i, (((Class263_Sub4) ((Class258) this).aClass263_Sub4_10176).anInt6415), (((Class263_Sub4) ((Class258) this).aClass263_Sub4_10176).anInt6417), ((Class258) this).anInt10177);
    }
}
