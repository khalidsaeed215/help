/* Class298_Sub32_Sub4 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub32_Sub4 extends Class298_Sub32 {
    int anInt9332;
    static int anInt9333 = 0;
    static int anInt9334 = 0;
    int anInt9335 = 0;
    int anInt9336 = 0;
    int anInt9337 = 0;
    static int anInt9338 = 0;
    int anInt9339;
    int anInt9340;
    int anInt9341;
    int anInt9342;
    int anInt9343;

    int[][] method3161(int i) {
	int[][] is = aClass239_7380.method2205(i, (byte) 114);
	if (aClass239_7380.aBoolean2607) {
	    int[][] is_0_ = method3134(0, i, (byte) 8);
	    int[] is_1_ = is_0_[0];
	    int[] is_2_ = is_0_[1];
	    int[] is_3_ = is_0_[2];
	    int[] is_4_ = is[0];
	    int[] is_5_ = is[1];
	    int[] is_6_ = is[2];
	    for (int i_7_ = 0; i_7_ < Class250.anInt2755 * -1474554145; i_7_++) {
		method3165(is_1_[i_7_], is_2_[i_7_], is_3_[i_7_], -128256883);
		((Class298_Sub32_Sub4) this).anInt9340 += ((Class298_Sub32_Sub4) this).anInt9335 * -480504993;
		((Class298_Sub32_Sub4) this).anInt9339 += 1401525773 * ((Class298_Sub32_Sub4) this).anInt9336;
		((Class298_Sub32_Sub4) this).anInt9332 += -1298028627 * ((Class298_Sub32_Sub4) this).anInt9337;
		for (/**/; ((Class298_Sub32_Sub4) this).anInt9340 * 1081228573 < 0; ((Class298_Sub32_Sub4) this).anInt9340 += 1188253696) {
		    /* empty */
		}
		for (/**/; (1081228573 * ((Class298_Sub32_Sub4) this).anInt9340 > 4096); ((Class298_Sub32_Sub4) this).anInt9340 -= 1188253696) {
		    /* empty */
		}
		if (((Class298_Sub32_Sub4) this).anInt9339 * -736197367 < 0)
		    ((Class298_Sub32_Sub4) this).anInt9339 = 0;
		if (-736197367 * ((Class298_Sub32_Sub4) this).anInt9339 > 4096)
		    ((Class298_Sub32_Sub4) this).anInt9339 = 697536512;
		if (-469731721 * ((Class298_Sub32_Sub4) this).anInt9332 < 0)
		    ((Class298_Sub32_Sub4) this).anInt9332 = 0;
		if (-469731721 * ((Class298_Sub32_Sub4) this).anInt9332 > 4096)
		    ((Class298_Sub32_Sub4) this).anInt9332 = 607416320;
		method3162(1081228573 * ((Class298_Sub32_Sub4) this).anInt9340, -736197367 * ((Class298_Sub32_Sub4) this).anInt9339, -469731721 * ((Class298_Sub32_Sub4) this).anInt9332, 182018145);
		is_4_[i_7_] = -1916696729 * ((Class298_Sub32_Sub4) this).anInt9341;
		is_5_[i_7_] = ((Class298_Sub32_Sub4) this).anInt9342 * 995837071;
		is_6_[i_7_] = 826309923 * ((Class298_Sub32_Sub4) this).anInt9343;
	    }
	}
	return is;
    }

    int[][] method3132(int i, byte i_8_) {
	try {
	    int[][] is = aClass239_7380.method2205(i, (byte) 87);
	    if (aClass239_7380.aBoolean2607) {
		int[][] is_9_ = method3134(0, i, (byte) 8);
		int[] is_10_ = is_9_[0];
		int[] is_11_ = is_9_[1];
		int[] is_12_ = is_9_[2];
		int[] is_13_ = is[0];
		int[] is_14_ = is[1];
		int[] is_15_ = is[2];
		for (int i_16_ = 0; i_16_ < Class250.anInt2755 * -1474554145; i_16_++) {
		    method3165(is_10_[i_16_], is_11_[i_16_], is_12_[i_16_], -128256883);
		    ((Class298_Sub32_Sub4) this).anInt9340 += ((Class298_Sub32_Sub4) this).anInt9335 * -480504993;
		    ((Class298_Sub32_Sub4) this).anInt9339 += 1401525773 * ((Class298_Sub32_Sub4) this).anInt9336;
		    ((Class298_Sub32_Sub4) this).anInt9332 += (-1298028627 * ((Class298_Sub32_Sub4) this).anInt9337);
		    for (/**/; (((Class298_Sub32_Sub4) this).anInt9340 * 1081228573 < 0); ((Class298_Sub32_Sub4) this).anInt9340 += 1188253696) {
			/* empty */
		    }
		    for (/**/; (1081228573 * ((Class298_Sub32_Sub4) this).anInt9340 > 4096); ((Class298_Sub32_Sub4) this).anInt9340 -= 1188253696) {
			/* empty */
		    }
		    if (((Class298_Sub32_Sub4) this).anInt9339 * -736197367 < 0)
			((Class298_Sub32_Sub4) this).anInt9339 = 0;
		    if (-736197367 * ((Class298_Sub32_Sub4) this).anInt9339 > 4096)
			((Class298_Sub32_Sub4) this).anInt9339 = 697536512;
		    if (-469731721 * ((Class298_Sub32_Sub4) this).anInt9332 < 0)
			((Class298_Sub32_Sub4) this).anInt9332 = 0;
		    if (-469731721 * ((Class298_Sub32_Sub4) this).anInt9332 > 4096)
			((Class298_Sub32_Sub4) this).anInt9332 = 607416320;
		    method3162(1081228573 * ((Class298_Sub32_Sub4) this).anInt9340, -736197367 * ((Class298_Sub32_Sub4) this).anInt9339, -469731721 * ((Class298_Sub32_Sub4) this).anInt9332, -1235292265);
		    is_13_[i_16_] = -1916696729 * ((Class298_Sub32_Sub4) this).anInt9341;
		    is_14_[i_16_] = ((Class298_Sub32_Sub4) this).anInt9342 * 995837071;
		    is_15_[i_16_] = 826309923 * ((Class298_Sub32_Sub4) this).anInt9343;
		}
	    }
	    return is;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("agg.k(").append(')').toString());
	}
    }

    void method3162(int i, int i_17_, int i_18_, int i_19_) {
	try {
	    int i_20_ = (i_18_ <= 2048 ? i_18_ * (4096 + i_17_) >> 12 : i_18_ + i_17_ - (i_17_ * i_18_ >> 12));
	    if (i_20_ > 0) {
		i *= 6;
		int i_21_ = i_18_ + i_18_ - i_20_;
		int i_22_ = (i_20_ - i_21_ << 12) / i_20_;
		int i_23_ = i >> 12;
		int i_24_ = i - (i_23_ << 12);
		int i_25_ = i_20_;
		i_25_ = i_25_ * i_22_ >> 12;
		i_25_ = i_24_ * i_25_ >> 12;
		int i_26_ = i_21_ + i_25_;
		int i_27_ = i_20_ - i_25_;
		switch (i_23_) {
		    case 0:
			((Class298_Sub32_Sub4) this).anInt9341 = -1501846441 * i_20_;
			((Class298_Sub32_Sub4) this).anInt9342 = i_26_ * -721593745;
			((Class298_Sub32_Sub4) this).anInt9343 = i_21_ * 1447533195;
			break;
		    case 5:
			((Class298_Sub32_Sub4) this).anInt9341 = -1501846441 * i_20_;
			((Class298_Sub32_Sub4) this).anInt9342 = i_21_ * -721593745;
			((Class298_Sub32_Sub4) this).anInt9343 = i_27_ * 1447533195;
			break;
		    case 3:
			((Class298_Sub32_Sub4) this).anInt9341 = -1501846441 * i_21_;
			((Class298_Sub32_Sub4) this).anInt9342 = i_27_ * -721593745;
			((Class298_Sub32_Sub4) this).anInt9343 = 1447533195 * i_20_;
			break;
		    case 1:
			((Class298_Sub32_Sub4) this).anInt9341 = i_27_ * -1501846441;
			((Class298_Sub32_Sub4) this).anInt9342 = -721593745 * i_20_;
			((Class298_Sub32_Sub4) this).anInt9343 = i_21_ * 1447533195;
			break;
		    case 4:
			((Class298_Sub32_Sub4) this).anInt9341 = i_26_ * -1501846441;
			((Class298_Sub32_Sub4) this).anInt9342 = -721593745 * i_21_;
			((Class298_Sub32_Sub4) this).anInt9343 = i_20_ * 1447533195;
			break;
		    case 2:
			((Class298_Sub32_Sub4) this).anInt9341 = i_21_ * -1501846441;
			((Class298_Sub32_Sub4) this).anInt9342 = -721593745 * i_20_;
			((Class298_Sub32_Sub4) this).anInt9343 = i_26_ * 1447533195;
		}
	    } else
		((Class298_Sub32_Sub4) this).anInt9341 = (((Class298_Sub32_Sub4) this).anInt9342 = (((Class298_Sub32_Sub4) this).anInt9343 = i_18_ * 1447533195) * -1366585299) * 1319430297;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("agg.am(").append(')').toString());
	}
    }

    void method3163(int i, RsByteBuffer class298_sub53) {
	switch (i) {
	    case 0:
		((Class298_Sub32_Sub4) this).anInt9335 = class298_sub53.readShort(1756517638) * -479167509;
		break;
	    case 2:
		((Class298_Sub32_Sub4) this).anInt9337 = ((class298_sub53.readByte() << 12) / 100 * -91159229);
		break;
	    case 1:
		((Class298_Sub32_Sub4) this).anInt9336 = ((class298_sub53.readByte() << 12) / 100 * 634933469);
		break;
	}
    }

    void method3164(int i, RsByteBuffer class298_sub53) {
	switch (i) {
	    case 0:
		((Class298_Sub32_Sub4) this).anInt9335 = class298_sub53.readShort(1627728425) * -479167509;
		break;
	    case 2:
		((Class298_Sub32_Sub4) this).anInt9337 = ((class298_sub53.readByte() << 12) / 100 * -91159229);
		break;
	    case 1:
		((Class298_Sub32_Sub4) this).anInt9336 = ((class298_sub53.readByte() << 12) / 100 * 634933469);
		break;
	}
    }

    void method3165(int i, int i_28_, int i_29_, int i_30_) {
	try {
	    int i_31_ = i > i_28_ ? i : i_28_;
	    i_31_ = i_29_ > i_31_ ? i_29_ : i_31_;
	    int i_32_ = i < i_28_ ? i : i_28_;
	    i_32_ = i_29_ < i_32_ ? i_29_ : i_32_;
	    int i_33_ = i_31_ - i_32_;
	    ((Class298_Sub32_Sub4) this).anInt9332 = -745389241 * ((i_31_ + i_32_) / 2);
	    if (((Class298_Sub32_Sub4) this).anInt9332 * -469731721 > 0 && -469731721 * ((Class298_Sub32_Sub4) this).anInt9332 < 4096)
		((Class298_Sub32_Sub4) this).anInt9339 = (-1734174407 * ((i_33_ << 12) / ((((Class298_Sub32_Sub4) this).anInt9332 * -469731721) <= 2048 ? (((Class298_Sub32_Sub4) this).anInt9332 * -939463442) : 8192 - (((Class298_Sub32_Sub4) this).anInt9332 * -939463442))));
	    else
		((Class298_Sub32_Sub4) this).anInt9339 = 0;
	    if (i_33_ > 0) {
		int i_34_ = (i_31_ - i << 12) / i_33_;
		int i_35_ = (i_31_ - i_28_ << 12) / i_33_;
		int i_36_ = (i_31_ - i_29_ << 12) / i_33_;
		if (i == i_31_)
		    ((Class298_Sub32_Sub4) this).anInt9340 = -1453036235 * (i_28_ == i_32_ ? i_36_ + 20480 : 4096 - i_35_);
		else if (i_28_ == i_31_)
		    ((Class298_Sub32_Sub4) this).anInt9340 = ((i_29_ == i_32_ ? i_34_ + 4096 : 12288 - i_36_) * -1453036235);
		else
		    ((Class298_Sub32_Sub4) this).anInt9340 = -1453036235 * (i_32_ == i ? i_35_ + 12288 : 20480 - i_34_);
		((Class298_Sub32_Sub4) this).anInt9340 = (((Class298_Sub32_Sub4) this).anInt9340 * 1081228573 / 6 * -1453036235);
	    } else
		((Class298_Sub32_Sub4) this).anInt9340 = 0;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("agg.ac(").append(')').toString());
	}
    }

    int[][] method3166(int i) {
	int[][] is = aClass239_7380.method2205(i, (byte) 106);
	if (aClass239_7380.aBoolean2607) {
	    int[][] is_37_ = method3134(0, i, (byte) 8);
	    int[] is_38_ = is_37_[0];
	    int[] is_39_ = is_37_[1];
	    int[] is_40_ = is_37_[2];
	    int[] is_41_ = is[0];
	    int[] is_42_ = is[1];
	    int[] is_43_ = is[2];
	    for (int i_44_ = 0; i_44_ < Class250.anInt2755 * -1474554145; i_44_++) {
		method3165(is_38_[i_44_], is_39_[i_44_], is_40_[i_44_], -128256883);
		((Class298_Sub32_Sub4) this).anInt9340 += ((Class298_Sub32_Sub4) this).anInt9335 * -480504993;
		((Class298_Sub32_Sub4) this).anInt9339 += 1401525773 * ((Class298_Sub32_Sub4) this).anInt9336;
		((Class298_Sub32_Sub4) this).anInt9332 += -1298028627 * ((Class298_Sub32_Sub4) this).anInt9337;
		for (/**/; ((Class298_Sub32_Sub4) this).anInt9340 * 1081228573 < 0; ((Class298_Sub32_Sub4) this).anInt9340 += 1188253696) {
		    /* empty */
		}
		for (/**/; (1081228573 * ((Class298_Sub32_Sub4) this).anInt9340 > 4096); ((Class298_Sub32_Sub4) this).anInt9340 -= 1188253696) {
		    /* empty */
		}
		if (((Class298_Sub32_Sub4) this).anInt9339 * -736197367 < 0)
		    ((Class298_Sub32_Sub4) this).anInt9339 = 0;
		if (-736197367 * ((Class298_Sub32_Sub4) this).anInt9339 > 4096)
		    ((Class298_Sub32_Sub4) this).anInt9339 = 697536512;
		if (-469731721 * ((Class298_Sub32_Sub4) this).anInt9332 < 0)
		    ((Class298_Sub32_Sub4) this).anInt9332 = 0;
		if (-469731721 * ((Class298_Sub32_Sub4) this).anInt9332 > 4096)
		    ((Class298_Sub32_Sub4) this).anInt9332 = 607416320;
		method3162(1081228573 * ((Class298_Sub32_Sub4) this).anInt9340, -736197367 * ((Class298_Sub32_Sub4) this).anInt9339, -469731721 * ((Class298_Sub32_Sub4) this).anInt9332, -2007691649);
		is_41_[i_44_] = -1916696729 * ((Class298_Sub32_Sub4) this).anInt9341;
		is_42_[i_44_] = ((Class298_Sub32_Sub4) this).anInt9342 * 995837071;
		is_43_[i_44_] = 826309923 * ((Class298_Sub32_Sub4) this).anInt9343;
	    }
	}
	return is;
    }

    public Class298_Sub32_Sub4() {
	super(1, false);
    }

    void method3137(int i, RsByteBuffer class298_sub53, byte i_45_) {
	try {
	    switch (i) {
		case 0:
		    ((Class298_Sub32_Sub4) this).anInt9335 = class298_sub53.readShort(1909722828) * -479167509;
		    break;
		case 2:
		    ((Class298_Sub32_Sub4) this).anInt9337 = ((class298_sub53.readByte() << 12) / 100 * -91159229);
		    break;
		case 1:
		    ((Class298_Sub32_Sub4) this).anInt9336 = ((class298_sub53.readByte() << 12) / 100 * 634933469);
		    break;
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("agg.r(").append(')').toString());
	}
    }
}
