/* Class298_Sub37_Sub11 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub37_Sub11 extends Class298_Sub37 {
    byte[] aByteArray9606;

    Class298_Sub37_Sub11(byte[] is) {
	((Class298_Sub37_Sub11) this).aByteArray9606 = is;
    }
}
