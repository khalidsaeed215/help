/* Class298_Sub37_Sub16 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class298_Sub37_Sub16 extends Class298_Sub37 {
    volatile boolean aBoolean9670 = true;
    boolean aBoolean9671;
    boolean aBoolean9672;

    abstract byte[] method3465(short i);

    Class298_Sub37_Sub16() {
	/* empty */
    }

    abstract byte[] method3466();

    abstract byte[] method3467();

    abstract int method3468(int i);

    abstract byte[] method3469();

    abstract int method3470();

    abstract int method3471();

    abstract int method3472();
}
