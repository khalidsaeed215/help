/* Class298_Sub37_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub37_Sub2 extends Class298_Sub37 {
    Class365_Sub1_Sub1_Sub1 aClass365_Sub1_Sub1_Sub1_9577;

    public Class298_Sub37_Sub2(Class365_Sub1_Sub1_Sub1 class365_sub1_sub1_sub1) {
	((Class298_Sub37_Sub2) this).aClass365_Sub1_Sub1_Sub1_9577 = class365_sub1_sub1_sub1;
    }

    static final void method3411(Class403 class403, byte i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class240.method2230(class105, class119, class403, -1468199503);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aid.jy(").append(')').toString());
	}
    }
}
