/* Class298_Sub50_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public final class Class298_Sub50_Sub1 extends Class298_Sub50 {
    static int anInt9733;
    static int anInt9734;
    static Class298_Sub50_Sub1[] aClass298_Sub50_Sub1Array9735 = new Class298_Sub50_Sub1[0];
    int anInt9736;
    int anInt9737;
    int anInt9738;
    long aLong9739;
    int anInt9740;

    public int method3546(int i) {
	try {
	    return ((Class298_Sub50_Sub1) this).anInt9736 * -959647937;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ajn.a(").append(')').toString());
	}
    }

    public int method3547(byte i) {
	try {
	    return ((Class298_Sub50_Sub1) this).anInt9737 * 658623775;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ajn.f(").append(')').toString());
	}
    }

    public int method3560(int i) {
	try {
	    return -660333015 * ((Class298_Sub50_Sub1) this).anInt9738;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ajn.b(").append(')').toString());
	}
    }

    public long method3549(byte i) {
	try {
	    return (((Class298_Sub50_Sub1) this).aLong9739 * 3438655524500841893L);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ajn.i(").append(')').toString());
	}
    }

    public long method3559() {
	return ((Class298_Sub50_Sub1) this).aLong9739 * 3438655524500841893L;
    }

    public void method3550(int i) {
	try {
	    synchronized (aClass298_Sub50_Sub1Array9735) {
		if (2017906303 * anInt9733 < anInt9734 * 2020209463 - 1)
		    aClass298_Sub50_Sub1Array9735[(anInt9733 += 1787228543) * 2017906303 - 1] = this;
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ajn.d(").append(')').toString());
	}
    }

    public int method3548(int i) {
	try {
	    return -1495835541 * ((Class298_Sub50_Sub1) this).anInt9740;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ajn.p(").append(')').toString());
	}
    }

    public int method3553() {
	return ((Class298_Sub50_Sub1) this).anInt9737 * 658623775;
    }

    public int method3557() {
	return ((Class298_Sub50_Sub1) this).anInt9736 * -959647937;
    }

    Class298_Sub50_Sub1() {
	/* empty */
    }

    public int method3554() {
	return ((Class298_Sub50_Sub1) this).anInt9737 * 658623775;
    }

    public int method3562() {
	return -660333015 * ((Class298_Sub50_Sub1) this).anInt9738;
    }

    public int method3565() {
	return -660333015 * ((Class298_Sub50_Sub1) this).anInt9738;
    }

    public int method3551() {
	return ((Class298_Sub50_Sub1) this).anInt9736 * -959647937;
    }

    public long method3552() {
	return ((Class298_Sub50_Sub1) this).aLong9739 * 3438655524500841893L;
    }

    public long method3558() {
	return ((Class298_Sub50_Sub1) this).aLong9739 * 3438655524500841893L;
    }

    public long method3556() {
	return ((Class298_Sub50_Sub1) this).aLong9739 * 3438655524500841893L;
    }

    public int method3564() {
	return -1495835541 * ((Class298_Sub50_Sub1) this).anInt9740;
    }

    public int method3561() {
	return -1495835541 * ((Class298_Sub50_Sub1) this).anInt9740;
    }

    public void method3555() {
	synchronized (aClass298_Sub50_Sub1Array9735) {
	    if (2017906303 * anInt9733 < anInt9734 * 2020209463 - 1)
		aClass298_Sub50_Sub1Array9735[(anInt9733 += 1787228543) * 2017906303 - 1] = this;
	}
    }

    public void method3563() {
	synchronized (aClass298_Sub50_Sub1Array9735) {
	    if (2017906303 * anInt9733 < anInt9734 * 2020209463 - 1)
		aClass298_Sub50_Sub1Array9735[(anInt9733 += 1787228543) * 2017906303 - 1] = this;
	}
    }
}
