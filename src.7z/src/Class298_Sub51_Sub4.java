/* Class298_Sub51_Sub4 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class298_Sub51_Sub4 extends Interface {
    Class400 aClass400_9779;

    public boolean method3580() {
	Class365_Sub1_Sub4_Sub1 class365_sub1_sub4_sub1 = ((Class298_Sub51_Sub4) this).aClass400_9779.method4927((byte) -26);
	if (class365_sub1_sub4_sub1 != null) {
	    Class98_Sub2.method1064(Class502.aClass502_6731, -1617025021 * interfaceId, -1, (((Class298_Sub51_Sub4) this).aClass400_9779), class365_sub1_sub4_sub1, -391880689);
	    return true;
	}
	return false;
    }

    public boolean method3573(int i) {
	try {
	    Class365_Sub1_Sub4_Sub1 class365_sub1_sub4_sub1 = ((Class298_Sub51_Sub4) this).aClass400_9779.method4927((byte) -81);
	    if (class365_sub1_sub4_sub1 != null) {
		Class98_Sub2.method1064(Class502.aClass502_6731, -1617025021 * interfaceId, -1, (((Class298_Sub51_Sub4) this).aClass400_9779), class365_sub1_sub4_sub1, -391880689);
		return true;
	    }
	    return false;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ajs.a(").append(')').toString());
	}
    }

    public Class298_Sub51_Sub4(int i, int i_0_, Class400 class400) {
	super(i, i_0_);
	((Class298_Sub51_Sub4) this).aClass400_9779 = class400;
    }
}
