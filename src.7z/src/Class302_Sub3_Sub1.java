/* Class302_Sub3_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class302_Sub3_Sub1 extends Class302_Sub3 {
    public int x;
    public static int anInt9786 = 12;
    public boolean aBoolean9787;
    public static int anInt9788 = 8191;
    public int y;
    public int z;
    public int size;
    public int colour;
    public byte aByte9793 = 5;
    public int anInt9794;

    Class302_Sub3_Sub1() {
	/* empty */
    }
}
