/* Class302_Sub4 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class302_Sub4 extends Class302 {
    int anInt7651;
    int anInt7652;
    int anInt7653;
    int anInt7654;
    int anInt7655;
    int anInt7656;
    String aString7657;
    static int anInt7658;

    Class302_Sub4() {
	/* empty */
    }

    static final void method3729(Class403 class403, int i) {
	try {
	    String string = (String) (((Class403) class403).anObjectArray5240[(((Class403) class403).anInt5241 -= 969361751) * -203050393]);
	    int i_0_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    Class505 class505 = Class322.method3931(BillBoardDefinitions.idx29, i_0_, 0, (byte) 11);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = class505.method6254(string, Class130_Sub2.aClass57Array6959, 1319235613);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aav.aap(").append(')').toString());
	}
    }

    static final void method3730(Class403 class403, int i) {
	try {
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = BillBoardDefinitions.aByte1759;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aav.wf(").append(')').toString());
	}
    }

    public static void method3731(int i, byte i_1_) {
	try {
	    Class298_Sub37_Sub12 class298_sub37_sub12 = Class410.method4985(3, (long) i);
	    class298_sub37_sub12.method3445(-813557087);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aav.k(").append(')').toString());
	}
    }
}
