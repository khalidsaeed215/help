
/* Class354 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import jaclib.ping.Ping;

public final class Class354 {
	Class298_Sub37 aClass298_Sub37_3821 = new Class298_Sub37();
	int anInt3822;
	int anInt3823;
	HashTable aClass437_3824;
	Class461 aClass461_3825 = new Class461();
	public static JS5 idx16;

	public Class298_Sub37 method4253(long l) {
		try {
			Class298_Sub37 class298_sub37 = ((Class298_Sub37) ((Class354) this).aClass437_3824.get(l));
			if (null != class298_sub37)
				((Class354) this).aClass461_3825.add(class298_sub37, (byte) -98);
			return class298_sub37;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ot.a(").append(')').toString());
		}
	}

	public Class354(int i) {
		((Class354) this).anInt3822 = i * -1251678705;
		((Class354) this).anInt3823 = i * -1442966963;
		int i_0_;
		for (i_0_ = 1; i_0_ + i_0_ < i; i_0_ += i_0_) {
			/* empty */
		}
		((Class354) this).aClass437_3824 = new HashTable(i_0_);
	}

	public void method4254(int i) {
		try {
			((Class354) this).aClass461_3825.method5988(-710330872);
			((Class354) this).aClass437_3824.method5811((byte) -28);
			((Class354) this).aClass298_Sub37_3821 = new Class298_Sub37();
			((Class354) this).anInt3823 = -964444701 * ((Class354) this).anInt3822;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ot.b(").append(')').toString());
		}
	}

	public void method4255(Class298_Sub37 class298_sub37, long l) {
		try {
			if (0 == ((Class354) this).anInt3823 * -78285179) {
				Class298_Sub37 class298_sub37_1_ = ((Class354) this).aClass461_3825.method5983(-2130705221);
				class298_sub37_1_.method2839(-1460969981);
				class298_sub37_1_.method3402(1224116599);
				if (class298_sub37_1_ == ((Class354) this).aClass298_Sub37_3821) {
					class298_sub37_1_ = ((Class354) this).aClass461_3825.method5983(-2124650372);
					class298_sub37_1_.method2839(-1460969981);
					class298_sub37_1_.method3402(-1522621021);
				}
			} else
				((Class354) this).anInt3823 -= -1442966963;
			((Class354) this).aClass437_3824.method5817(class298_sub37, l);
			((Class354) this).aClass461_3825.add(class298_sub37, (byte) -113);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ot.f(").append(')').toString());
		}
	}

	static final void method4256(Class403 class403, int i) {
		try {
			int i_2_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689)
					* 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_2_, (byte) -49);
			((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = pb
					.method2801(class105).method3497((byte) 14);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ot.sr(").append(')').toString());
		}
	}

	static final void method4257(Class403 class403, int i) {
		try {
			((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919
					- 1)] = Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub23_7576.method5709(-1715403508);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ot.anm(").append(')').toString());
		}
	}

	static final void method4258(Class403 class403, int i) {
		try {
			int i_3_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689)
					* 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_3_, (byte) 9);
			Class119 class119 = Class389.aClass119Array4165[i_3_ >> 16];
			Class52_Sub1_Sub1.method568(class105, class119, class403, (byte) 88);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ot.dt(").append(')').toString());
		}
	}

	public static int method4259(int i) {
		try {
			if (0 == Class234.anInt2596 * 363912581) {
				Class479.jaclibt.method6102(new Class221("jaclib"), 1596959683);
				if (Class479.jaclibt.method6101(-1994130525).method256(1033369240) != 100)
					return 1;
				if (!((Class221) Class479.jaclibt.method6101(-1994130525)).method2050(-88973782)) {
					Class385.aClient4141.method2766(1045646617);
					Class221.method2053(1815020733);
					try {
						Ping.init();
					} catch (Throwable throwable) {
						/* empty */
					}
				}
				Class234.anInt2596 = -28142771;
			}
			if (363912581 * Class234.anInt2596 == 1) {
				RuntimeException_Sub3.aClass479Array6311 = Class479.method6104(498211090);
				Class479.idx28t.method6102(new Class223(Class399.idx28), 1886459423);
				Class479.jagglt.method6102(new Class221("jaggl"), 35492934);
				Class479.jagdxt.method6102(new Class221("jagdx"), 901862397);
				Class479.sw3dt.method6102(new Class221("sw3d"), 894420181);
				Class479.hw3dt.method6102(new Class221("hw3d"), 484486949);
				Class479.jagtheorat.method6102(new Class221("jagtheora"), 1559153600);
				Class479.idx31t.method6102(new Class223(Class82_Sub6.idx31), 63607433);
				Class479.idx26t.method6102(new Class223(Class451.idx26), 1106252958);
				Class479.idx2t.method6102(new Class223(Class284_Sub1.idx2), -82697463);
				Class479.idx16t.method6102(new Class223(idx16), -43844989);
				Class479.idx17t.method6102(new Class223(Class521.idx17), 664247222);
				Class479.idx18t.method6102(new Class223(Class133.idx18), 1643462211);
				Class479.idx19t.method6102(new Class223(Class92.idx19), 1475366772);
				Class479.idx20t.method6102(new Class223(Class260.idx20), 2057866589);
				Class479.idx21t.method6102(new Class223(Class23.idx21), 1522498653);
				Class479.idx22t.method6102(new Class223(Class499.idx22), 2023502986);
				Class479.idx24t.method6102(new Class223(Class497.idx24), 1517464080);
				Class479.idx25t.method6102(new Class223(Class266.idx25), 1685456867);
				// Class479.idx9t.method6102(new Class223(Class127.idx9),
				// 1053166996);
				Class479.idx27t.method6102(new Class223(Class51.idx27), 1037096117);
				Class479.idx29t.method6102(new Class223(Class277.idx29), 4556211);
				Class479.idx10huffmant.method6102(new Class237(Class122.idx10, "huffman"), 827266290);
				Class479.idx3.method6102(new Class223(Class160.idx3), 650895714);
				Class479.idx12.method6102(new Class223(Class377.idx12), 199698192);
				Class479.idx13tPROB.method6102(new Class223(BillBoardDefinitions.idx29), 70682511);
				Class479.idx23detailst.method6102(new Class216(Class_v.idx23, "details"), -221178534);
				for (int i_4_ = 0; i_4_ < RuntimeException_Sub3.aClass479Array6311.length; i_4_++) {
					if (RuntimeException_Sub3.aClass479Array6311[i_4_].method6101(-1994130525) == null)
						throw new RuntimeException();
				}
				int i_5_ = 0;
				Class479[] class479s = RuntimeException_Sub3.aClass479Array6311;
				for (int i_6_ = 0; i_6_ < class479s.length; i_6_++) {
					Class479 class479 = class479s[i_6_];
					int i_7_ = class479.method6100(-1839796424);
					int i_8_ = class479.method6101(-1994130525).method256(1033369240);
					i_5_ += i_7_ * i_8_ / 100;
				}
				Class234.anInt2597 = 1385369023 * i_5_;
				Class234.anInt2596 = -56285542;
			}
			if (RuntimeException_Sub3.aClass479Array6311 == null)
				return 100;
			int i_9_ = 0;
			int i_10_ = 0;
			boolean bool = true;
			Class479[] class479s = RuntimeException_Sub3.aClass479Array6311;
			for (int i_11_ = 0; i_11_ < class479s.length; i_11_++) {
				Class479 class479 = class479s[i_11_];
				int i_12_ = class479.method6100(212846361);
				int i_13_ = class479.method6101(-1994130525).method256(1033369240);
				if (i_13_ < 100)
					bool = false;
				i_9_ += i_12_;
				i_10_ += i_12_ * i_13_ / 100;
			}
			if (bool) {
				if (!((Class221) Class479.jagtheorat.method6101(-1994130525)).method2050(104668639))
					pb.aBoolean8806 = Class385.aClient4141.method2767(-2027084439);
				RuntimeException_Sub3.aClass479Array6311 = null;
			}
			i_10_ -= -913055169 * Class234.anInt2597;
			i_9_ -= -913055169 * Class234.anInt2597;
			int i_14_ = i_9_ > 0 ? 100 * i_10_ / i_9_ : 100;
			if (!bool && i_14_ > 99)
				i_14_ = 99;
			return i_14_;
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ot.a(").append(')').toString());
		}
	}

	static final void method4260(Class403 class403, int i) {
		try {
			int i_15_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689)
					* 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_15_, (byte) -46);
			Class422_Sub27.method5722(class105, class403, 1480483039);
		} catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ot.qs(").append(')').toString());
		}
	}
}
