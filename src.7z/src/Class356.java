/* Class356 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class356 {
    public static int anInt3827 = 48;
    public static int anInt3828 = -3;
    public static int anInt3829 = -4;
    public static int anInt3830 = 3;
    public static int anInt3831 = 1;
    public static int anInt3832 = 7;
    public static int anInt3833 = -2;
    public static int anInt3834 = 6;
    public static int anInt3835 = 2;
    public static int anInt3836 = 35;
    public static int anInt3837 = 15;
    public static int anInt3838 = 21;
    public static int anInt3839 = 45;
    public static int anInt3840 = 29;
    public static int anInt3841 = 23;
    public static int anInt3842 = 42;
    public static int anInt3843 = -5;
    public static int anInt3844 = 9;

    Class356() throws Throwable {
	throw new Error();
    }

    static final void method4266(Class403 class403, int i) {
	try {
	    int i_0_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    IComponentDefinition class105 = Class50.getIComponentDefinitions(i_0_, (byte) 2);
	    Class119 class119 = Class389.aClass119Array4165[i_0_ >> 16];
	    Class241.method2248(class105, class119, class403, -16777216);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ow.kf(").append(')').toString());
	}
    }

    static final void method4267(Class403 class403, int i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class288.method2728(class105, class119, class403, 896700904);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ow.ey(").append(')').toString());
	}
    }

    public static int method4268(int i) {
	try {
	    if (588194557 * Class111.anInt1367 == -1) {
		Class111[] class111s = SunDefinition.method1399((byte) -111);
		for (int i_1_ = 0; i_1_ < class111s.length; i_1_++) {
		    Class111 class111 = class111s[i_1_];
		    if (((Class111) class111).anInt1366 * -1047699439 > 588194557 * Class111.anInt1367)
			Class111.anInt1367 = 510332837 * ((Class111) class111).anInt1366;
		}
		Class111.anInt1367 += -1700689323;
	    }
	    return 588194557 * Class111.anInt1367;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ow.b(").append(')').toString());
	}
    }

    static final void method4269(Class403 class403, int i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    int i_2_ = -1;
	    int i_3_ = -1;
	    Class117 class117 = class105.method1116(Class373.activeToolkit, 193353438);
	    if (class117 != null) {
		i_2_ = class117.anInt1393 * 1633695381;
		i_3_ = class117.anInt1394 * -60174999;
	    }
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = i_2_;
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = i_3_;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ow.py(").append(')').toString());
	}
    }

    static final void method4270(IComponentDefinition class105, Class119 class119, Class403 class403, int i) {
	try {
	    String string = (String) (((Class403) class403).anObjectArray5240[(((Class403) class403).anInt5241 -= 969361751) * -203050393]);
	    int[] is = Class298_Sub6.method2863(string, class403, -1668247696);
	    if (null != is)
		string = string.substring(0, string.length() - 1);
	    class105.anObjectArray1177 = Class128_Sub2.method1441(string, class403, -2046058202);
	    class105.anIntArray1188 = is;
	    class105.aBoolean1238 = true;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ow.lm(").append(')').toString());
	}
    }

    public static final int method4271(int i, int i_4_, int i_5_, int i_6_) {
	try {
	    if (pb.aClass283_8716.method2675(-1611682495) == null)
		return 0;
	    int i_7_ = i >> 9;
	    int i_8_ = i_4_ >> 9;
	    if (i_7_ < 0 || i_8_ < 0 || i_7_ > pb.aClass283_8716.method2629(-1956967905) - 1 || i_8_ > pb.aClass283_8716.method2630(1920772834) - 1)
		return 0;
	    int i_9_ = i_5_;
	    if (i_9_ < 3 && ((pb.aClass283_8716.method2654(2001279106).aByteArrayArrayArray2731[1][i_7_][i_8_]) & 0x2) != 0)
		i_9_++;
	    return pb.aClass283_8716.method2675(-1611682495).aClass_xaArray3517[i_9_].averageHeight(i, i_4_, -1909964281);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ow.jx(").append(')').toString());
	}
    }

    static final void method4272(Class403 class403, int i) {
	try {
	    int i_10_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    IComponentDefinition class105 = Class50.getIComponentDefinitions(i_10_, (byte) 0);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = class105.anInt1248 * -1523987341;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ow.rg(").append(')').toString());
	}
    }

    static final void method4273(Class403 class403, int i) {
	try {
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = pb.aBoolean8643 ? 1 : 0;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ow.uk(").append(')').toString());
	}
    }
}
