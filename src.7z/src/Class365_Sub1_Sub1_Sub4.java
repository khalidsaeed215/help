/* Class365_Sub1_Sub1_Sub4 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class365_Sub1_Sub1_Sub4 extends Class365_Sub1_Sub1 {
    Class299 aClass299_10140;
    Model aClass387_10141;

    public Class334 method4358(Toolkit class_ra, byte i) {
	try {
	    return null;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("akx.bc(").append(')').toString());
	}
    }

    boolean method4350(Toolkit class_ra, int i, int i_0_, byte i_1_) {
	try {
	    return false;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("akx.bu(").append(')').toString());
	}
    }

    boolean method4366(int i) {
	try {
	    return false;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("akx.bw(").append(')').toString());
	}
    }

    boolean method4399(byte i) {
	try {
	    if (((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 != null)
		return !((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.u();
	    return true;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("akx.bf(").append(')').toString());
	}
    }

    void method4377() {
	/* empty */
    }

    void method4355(Toolkit class_ra, Class365_Sub1 class365_sub1, int i, int i_2_, int i_3_, boolean bool, int i_4_) {
	try {
	    /* empty */
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("akx.bk(").append(')').toString());
	}
    }

    boolean method4384() {
	return false;
    }

    Class335 method4370(Toolkit class_ra) {
	if (null == ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141)
	    ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 = ((Class365_Sub1_Sub1_Sub4) this).aClass299_10140.method3679(class_ra, 222993997);
	if (null != ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141) {
	    Class222 class222 = class_ra.method5178();
	    Class222 class222_5_ = method4347();
	    Class235 class235 = method4337();
	    class222.method2070(class222_5_);
	    Class326 class326 = (aClass331_7722.aClass326ArrayArrayArray3516[plane][(int) class235.aClass217_2599.aFloat2451 >> 9][(int) class235.aClass217_2599.aFloat2454 >> 9]);
	    if (null != class326 && class326.aClass365_Sub1_Sub2_3461 != null)
		class222.method2064(0.0F, (float) -(class326.aClass365_Sub1_Sub2_3461.aShort9801), 0.0F);
	    ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.method4739(class222, null, 0);
	}
	return null;
    }

    void method4357(Toolkit class_ra, int i) {
	try {
	    /* empty */
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("akx.bb(").append(')').toString());
	}
    }

    boolean method4372(Toolkit class_ra, int i, int i_6_) {
	return false;
    }

    public int method4361(int i) {
	try {
	    return (null != ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 ? ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.YA() : 0);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("akx.bm(").append(')').toString());
	}
    }

    boolean method4353() {
	if (((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 != null)
	    return !((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.u();
	return true;
    }

    boolean method4365() {
	if (((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 != null)
	    return !((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.u();
	return true;
    }

    public Class334 method4367(Toolkit class_ra) {
	return null;
    }

    void method4371(Toolkit class_ra) {
	/* empty */
    }

    public int method4379() {
	return (null != ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 ? ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.YA() : 0);
    }

    public Class334 method4368(Toolkit class_ra) {
	return null;
    }

    void method4398(byte i) {
	try {
	    /* empty */
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("akx.bq(").append(')').toString());
	}
    }

    void method4373(Toolkit class_ra) {
	/* empty */
    }

    Class335 method4394(Toolkit class_ra, int i) {
	try {
	    if (null == ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141)
		((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 = ((Class365_Sub1_Sub1_Sub4) this).aClass299_10140.method3679(class_ra, 809073544);
	    if (null != ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141) {
		Class222 class222 = class_ra.method5178();
		Class222 class222_7_ = method4347();
		Class235 class235 = method4337();
		class222.method2070(class222_7_);
		Class326 class326 = (aClass331_7722.aClass326ArrayArrayArray3516[plane][(int) class235.aClass217_2599.aFloat2451 >> 9][(int) class235.aClass217_2599.aFloat2454 >> 9]);
		if (null != class326 && class326.aClass365_Sub1_Sub2_3461 != null)
		    class222.method2064(0.0F, (float) -(class326.aClass365_Sub1_Sub2_3461.aShort9801), 0.0F);
		((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.method4739(class222, null, 0);
	    }
	    return null;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("akx.bo(").append(')').toString());
	}
    }

    Class365_Sub1_Sub1_Sub4(Class331 class331, Class299 class299, int i, int i_8_, int i_9_, int i_10_, int i_11_) {
	super(class331, i, i_8_, i_9_, i_10_, i_11_, i_9_ >> 9, i_9_ >> 9, i_11_ >> 9, i_11_ >> 9, false, (byte) 0);
	((Class365_Sub1_Sub1_Sub4) this).aClass299_10140 = class299;
    }

    boolean method4352(Toolkit class_ra, int i, int i_12_) {
	return false;
    }

    void method4375(Toolkit class_ra, Class365_Sub1 class365_sub1, int i, int i_13_, int i_14_, boolean bool) {
	/* empty */
    }

    void method4388(Toolkit class_ra, Class365_Sub1 class365_sub1, int i, int i_15_, int i_16_, boolean bool) {
	/* empty */
    }

    boolean method4386() {
	return false;
    }

    void method4378() {
	/* empty */
    }

    boolean method4374() {
	if (((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 != null)
	    return !((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.u();
	return true;
    }

    public int method4380() {
	return (null != ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 ? ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.YA() : 0);
    }

    public int method4381() {
	return (null != ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 ? ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.YA() : 0);
    }

    boolean method4369() {
	if (((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 != null)
	    return ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.i();
	return false;
    }

    boolean method4382() {
	if (((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 != null)
	    return ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.i();
	return false;
    }

    boolean method4349() {
	if (((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 != null)
	    return ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.i();
	return false;
    }

    boolean method4383() {
	if (((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 != null)
	    return ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.i();
	return false;
    }

    boolean method4351() {
	if (((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 != null)
	    return ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.i();
	return false;
    }

    boolean method4385(Toolkit class_ra, int i, int i_17_) {
	return false;
    }

    boolean method4400() {
	return false;
    }

    boolean method4376(short i) {
	try {
	    if (((Class365_Sub1_Sub1_Sub4) this).aClass387_10141 != null)
		return ((Class365_Sub1_Sub1_Sub4) this).aClass387_10141.i();
	    return false;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("akx.be(").append(')').toString());
	}
    }

    boolean method4387() {
	return false;
    }
}
