/* Class365_Sub1_Sub3 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class365_Sub1_Sub3 extends Class365_Sub1 {
    protected short aShort9802;
    protected short aShort9803;
    public static Class255 aClass255_9804;

    final boolean method4384() {
	return false;
    }

    int method4354(Class298_Sub10[] class298_sub10s, int i) {
	try {
	    Class217 class217 = method4337().aClass217_2599;
	    return method4392(((int) class217.aFloat2451 >> -1688804109 * aClass331_7722.anInt3504), ((int) class217.aFloat2454 >> -1688804109 * aClass331_7722.anInt3504), class298_sub10s, 1820308449);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aji.dg(").append(')').toString());
	}
    }

    final void method4378() {
	throw new IllegalStateException();
    }

    final boolean method4400() {
	return false;
    }

    final boolean method4366(int i) {
	try {
	    return false;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aji.bw(").append(')').toString());
	}
    }

    final void method4388(Toolkit class_ra, Class365_Sub1 class365_sub1, int i, int i_0_, int i_1_, boolean bool) {
	throw new IllegalStateException();
    }

    final void method4398(byte i) {
	try {
	    throw new IllegalStateException();
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aji.bq(").append(')').toString());
	}
    }

    final void method4375(Toolkit class_ra, Class365_Sub1 class365_sub1, int i, int i_2_, int i_3_, boolean bool) {
	throw new IllegalStateException();
    }

    int method4390(Class298_Sub10[] class298_sub10s) {
	Class217 class217 = method4337().aClass217_2599;
	return method4392(((int) class217.aFloat2451 >> -1688804109 * aClass331_7722.anInt3504), ((int) class217.aFloat2454 >> -1688804109 * aClass331_7722.anInt3504), class298_sub10s, 2077103831);
    }

    final void method4377() {
	throw new IllegalStateException();
    }

    Class365_Sub1_Sub3(Class331 class331, int i, int i_4_, int i_5_, int i_6_, int i_7_, int i_8_, int i_9_) {
	super(class331);
	plane = (byte) i_6_;
	aByte7724 = (byte) i_7_;
	aShort9802 = (short) i_8_;
	aShort9803 = (short) i_9_;
	method4340(new Class217((float) i, (float) i_4_, (float) i_5_));
    }

    boolean method4359(Toolkit class_ra) {
	Class217 class217 = method4337().aClass217_2599;
	return (aClass331_7722.aClass333_3512.method4073(aByte7724, ((int) class217.aFloat2451 >> aClass331_7722.anInt3504 * -1688804109), ((int) class217.aFloat2454 >> aClass331_7722.anInt3504 * -1688804109), method4361(1951240662)));
    }

    final void method4355(Toolkit class_ra, Class365_Sub1 class365_sub1, int i, int i_10_, int i_11_, boolean bool, int i_12_) {
	try {
	    throw new IllegalStateException();
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aji.bk(").append(')').toString());
	}
    }

    final boolean method4386() {
	return false;
    }

    final boolean method4387() {
	return false;
    }

    boolean method4364(Toolkit class_ra, byte i) {
	try {
	    Class217 class217 = method4337().aClass217_2599;
	    return (aClass331_7722.aClass333_3512.method4073(aByte7724, ((int) class217.aFloat2451 >> aClass331_7722.anInt3504 * -1688804109), ((int) class217.aFloat2454 >> aClass331_7722.anInt3504 * -1688804109), method4361(1951240662)));
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aji.dl(").append(')').toString());
	}
    }

    boolean method4391(Toolkit class_ra) {
	Class217 class217 = method4337().aClass217_2599;
	return (aClass331_7722.aClass333_3512.method4073(aByte7724, ((int) class217.aFloat2451 >> aClass331_7722.anInt3504 * -1688804109), ((int) class217.aFloat2454 >> aClass331_7722.anInt3504 * -1688804109), method4361(1951240662)));
    }

    boolean method4397() {
	Class217 class217 = method4337().aClass217_2599;
	return (((Class331) aClass331_7722).aBooleanArrayArray3563[(583010427 * ((Class331) aClass331_7722).anInt3538 + (((int) class217.aFloat2451 >> -1688804109 * aClass331_7722.anInt3504) - -804213305 * ((Class331) aClass331_7722).anInt3553))][(((int) class217.aFloat2454 >> -1688804109 * aClass331_7722.anInt3504) - ((Class331) aClass331_7722).anInt3513 * 465603579 + 583010427 * ((Class331) aClass331_7722).anInt3538)]);
    }

    boolean method4393(Toolkit class_ra) {
	Class217 class217 = method4337().aClass217_2599;
	return (aClass331_7722.aClass333_3512.method4073(aByte7724, ((int) class217.aFloat2451 >> aClass331_7722.anInt3504 * -1688804109), ((int) class217.aFloat2454 >> aClass331_7722.anInt3504 * -1688804109), method4361(1951240662)));
    }

    boolean method4389(Toolkit class_ra) {
	Class217 class217 = method4337().aClass217_2599;
	return (aClass331_7722.aClass333_3512.method4073(aByte7724, ((int) class217.aFloat2451 >> aClass331_7722.anInt3504 * -1688804109), ((int) class217.aFloat2454 >> aClass331_7722.anInt3504 * -1688804109), method4361(1951240662)));
    }

    boolean method4395() {
	Class217 class217 = method4337().aClass217_2599;
	return (((Class331) aClass331_7722).aBooleanArrayArray3563[(583010427 * ((Class331) aClass331_7722).anInt3538 + (((int) class217.aFloat2451 >> -1688804109 * aClass331_7722.anInt3504) - -804213305 * ((Class331) aClass331_7722).anInt3553))][(((int) class217.aFloat2454 >> -1688804109 * aClass331_7722.anInt3504) - ((Class331) aClass331_7722).anInt3513 * 465603579 + 583010427 * ((Class331) aClass331_7722).anInt3538)]);
    }

    boolean method4396() {
	Class217 class217 = method4337().aClass217_2599;
	return (((Class331) aClass331_7722).aBooleanArrayArray3563[(583010427 * ((Class331) aClass331_7722).anInt3538 + (((int) class217.aFloat2451 >> -1688804109 * aClass331_7722.anInt3504) - -804213305 * ((Class331) aClass331_7722).anInt3553))][(((int) class217.aFloat2454 >> -1688804109 * aClass331_7722.anInt3504) - ((Class331) aClass331_7722).anInt3513 * 465603579 + 583010427 * ((Class331) aClass331_7722).anInt3538)]);
    }

    boolean method4360(int i) {
	try {
	    Class217 class217 = method4337().aClass217_2599;
	    return (((Class331) aClass331_7722).aBooleanArrayArray3563[(583010427 * ((Class331) aClass331_7722).anInt3538 + (((int) class217.aFloat2451 >> -1688804109 * aClass331_7722.anInt3504) - (-804213305 * ((Class331) aClass331_7722).anInt3553)))][(((int) class217.aFloat2454 >> -1688804109 * aClass331_7722.anInt3504) - ((Class331) aClass331_7722).anInt3513 * 465603579 + 583010427 * ((Class331) aClass331_7722).anInt3538)]);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aji.dq(").append(')').toString());
	}
    }
}
