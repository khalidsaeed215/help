/* Class37 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class37 {
    int anInt425;
    int anInt426;
    int anInt427;

    Class37() {
	/* empty */
    }
}
