/* Class372_Sub2_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class372_Sub2_Sub1 extends Class372_Sub2 {
    Class372_Sub2_Sub1() throws Throwable {
	throw new Error();
    }
}
