/* Class378 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class378 {
    public static int anInt4093 = 6;
    static Class428 aClass428_4094;

    Class378() throws Throwable {
	throw new Error();
    }

    static final void method4669(Class403 class403, byte i) {
	try {
	    ((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393 - 1)] = (((Class403) class403).anObjectArray5234[(((Class403) class403).anIntArray5257[1883543357 * ((Class403) class403).anInt5259])]);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ps.ap(").append(')').toString());
	}
    }

    public static short[] method4670(short[] is, byte i) {
	try {
	    if (null == is)
		return null;
	    short[] is_0_ = new short[is.length];
	    System.arraycopy(is, 0, is_0_, 0, is.length);
	    return is_0_;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ps.f(").append(')').toString());
	}
    }

    public static boolean method4671(int i, int[] is, int i_1_) {
	try {
	    if (Class441.aBooleanArray5590[i])
		return true;
	    Class389.aClass119Array4165[i] = Class338.method4115(i, is, Class389.aClass119Array4165[i], false, (byte) 3);
	    if (null == Class389.aClass119Array4165[i])
		return false;
	    Class441.aBooleanArray5590[i] = true;
	    return true;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ps.i(").append(')').toString());
	}
    }
}
