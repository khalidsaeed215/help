/* Class379 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class379 {
    static int anInt4095;
    public static int[] anIntArray4096;
    static int anInt4097 = 0;
    public static int[] anIntArray4098;
    static int anInt4099;

    static {
	anInt4095 = 0;
    }

    Class379() throws Throwable {
	throw new Error();
    }

    static final void method4672(Class403 class403, byte i) {
	try {
	    int i_0_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    Class102 class102 = Class298_Sub40_Sub13.method3517(i_0_, 1063164911);
	    String string = "";
	    if (class102 != null && null != class102.aString1094)
		string = class102.aString1094;
	    ((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393 - 1)] = string;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("pt.abe(").append(')').toString());
	}
    }

    public static void method4673(JS5 class243, int i) {
	try {
	    Class74.anInt692 = class243.getArchiveId("hitbar_default") * 2112064137;
	    Class74.anInt694 = class243.getArchiveId("timerbar_default") * 1617597269;
	    Class143.anInt1558 = class243.getArchiveId("headicons_pk") * 1432033185;
	    Class400.anInt5223 = class243.getArchiveId("headicons_prayer") * -1214334111;
	    Class74.anInt693 = class243.getArchiveId("hint_headicons") * 250641705;
	    Class74.anInt696 = class243.getArchiveId("hint_mapmarkers") * 1711228595;
	    Class298_Sub36.anInt7398 = class243.getArchiveId("mapflag") * 1542214111;
	    Class82_Sub6.anInt6842 = class243.getArchiveId("cross") * -626988461;
	    Class494.anInt6092 = class243.getArchiveId("mapdots") * -1409898789;
	    Class74.anInt697 = class243.getArchiveId("name_icons") * 1606490933;
	    Class257.anInt2802 = (class243.getArchiveId("floorshadows") * -1276802557);
	    Class237.anInt6667 = class243.getArchiveId("compass") * 1540144067;
	    Class128_Sub1.anInt8557 = class243.getArchiveId("otherlevel") * -233695275;
	    Class298_Sub24_Sub1.anInt9281 = class243.getArchiveId("hint_mapedge") * 902133497;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("pt.f(").append(')').toString());
	}
    }

    static final void method4674(int i) {
	try {
	    int i_1_ = 0;
	    Class331 class331 = pb.aClass283_8716.method2675(-1611682495);
	    for (int i_2_ = 0; i_2_ < pb.aClass283_8716.method2629(-2029823795); i_2_++) {
		for (int i_3_ = 0; i_3_ < pb.aClass283_8716.method2630(-105400653); i_3_++) {
		    if (Class143.method1577((class331.aClass326ArrayArrayArray3516), i_1_, i_2_, i_3_, true, -777988087))
			i_1_++;
		    if (i_1_ >= 512)
			return;
		}
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("pt.iu(").append(')').toString());
	}
    }

    static final void method4675(Class403 class403, byte i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = 2053897963 * class105.anInt1169;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("pt.pg(").append(')').toString());
	}
    }
}
