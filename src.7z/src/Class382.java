/* Class382 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

final class Class382 implements Interface22 {
    public void method248(boolean bool) {
	/* empty */
    }

    public void method247(boolean bool, byte i) {
	try {
	    /* empty */
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("pw.a(").append(')').toString());
	}
    }

    public void method245(int i, int i_0_, int i_1_, short i_2_) {
	try {
	    int i_3_ = i >> 16;
	    int i_4_ = i & 0xffff;
	    synchronized (ClientScriptsExecutor.aQueue4124) {
		ClientScriptsExecutor.aQueue4124.add(MagnetConfig.method785(i_3_, i_4_, i_0_, i_1_, (byte) 15));
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("pw.f(").append(')').toString());
	}
    }

    public void method246(int i, int i_5_, int i_6_) {
	int i_7_ = i >> 16;
	int i_8_ = i & 0xffff;
	synchronized (ClientScriptsExecutor.aQueue4124) {
	    ClientScriptsExecutor.aQueue4124.add(MagnetConfig.method785(i_7_, i_8_, i_5_, i_6_, (byte) 15));
	}
    }

    public static void method4685(int[][] is, byte i) {
	try {
	    Class372.anIntArrayArray4047 = is;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("pw.a(").append(')').toString());
	}
    }

    static final long method4686(int i) {
	try {
	    return ((long) ((Class388.anInt4151 += -1596186261) * 1924989763 - 1) << 32 | 0xffffffffL);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("pw.qb(").append(')').toString());
	}
    }

    static final void method4687(Class403 class403, int i) {
	try {
	    ((Class403) class403).anInt5239 -= -407600972;
	    Class194.method1868(2025307040);
	    Class365_Sub1_Sub3_Sub2.method4512(313309588);
	    IPAddress.anInt5958 = 1806117321 * (((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919]);
	    Class82_Sub4.anInt6833 = (-1838335691 * (((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239 + 1]));
	    Class313.anInt3297 = (389597853 * (((Class403) class403).anIntArray5244[2 + 681479919 * ((Class403) class403).anInt5239]));
	    Class436.anInt5484 = ((((Class403) class403).anIntArray5244[3 + 681479919 * ((Class403) class403).anInt5239]) * -1589801219);
	    Class362.anInt3918 = (-666665017 * (((Class403) class403).anIntArray5244[4 + ((Class403) class403).anInt5239 * 681479919]));
	    Class422_Sub14.anInt8400 = ((((Class403) class403).anIntArray5244[5 + ((Class403) class403).anInt5239 * 681479919]) * 207797751);
	    ClanSettings.anInt1680 = ((((Class403) class403).anIntArray5244[6 + 681479919 * ((Class403) class403).anInt5239]) * -741526353);
	    Class361.anInt3914 = ((((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239 + 7]) * -221610643);
	    Class260.anInt2820 = ((((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239 + 8]) * 1226151685);
	    Class343.anInt3674 = (-994575607 * (((Class403) class403).anIntArray5244[9 + ((Class403) class403).anInt5239 * 681479919]));
	    Class298_Sub40_Sub2.anInt9693 = (-1941123577 * (((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239 + 10]));
	    Class242.anInt2710 = ((((Class403) class403).anIntArray5244[11 + ((Class403) class403).anInt5239 * 681479919]) * -1418353209);
	    Class158.idx8.fileLoaded(Class362.anInt3918 * 142643703, -457216440);
	    Class158.idx8.fileLoaded(Class422_Sub14.anInt8400 * 1757615047, -457216440);
	    Class158.idx8.fileLoaded(1049272911 * ClanSettings.anInt1680, -457216440);
	    Class158.idx8.fileLoaded(-745532315 * Class361.anInt3914, -457216440);
	    Class158.idx8.fileLoaded(Class260.anInt2820 * -684155443, -457216440);
	    Class158.idx8.fileLoaded(Class242.anInt2710 * -2085188617, -457216440);
	    BillBoardDefinitions.idx29.fileLoaded(-2085188617 * Class242.anInt2710, -457216440);
	    Class486.aClass57_6062 = null;
	    Class373.aClass57_4070 = null;
	    Class367.aClass57_4001 = null;
	    Class74.aClass57_700 = null;
	    Class423.aClass57_5356 = null;
	    Class313.aClass57_3299 = null;
	    Class82_Sub8.aClass57_6855 = null;
	    Class501.aClass57_6123 = null;
	    Class436.aBoolean5496 = true;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("pw.afr(").append(')').toString());
	}
    }

    static final void method4688(Class403 class403, int i) {
	try {
	    ((Class403) class403).anInt5239 -= -783761378;
	    int i_9_ = (((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239]);
	    int i_10_ = (((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239 + 1]);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = i_9_ > i_10_ ? i_9_ : i_10_;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("pw.zw(").append(')').toString());
	}
    }

    static final void method4689(Class403 class403, int i) {
	try {
	    String string = (String) (((Class403) class403).anObjectArray5240[(((Class403) class403).anInt5241 -= 969361751) * -203050393]);
	    int i_11_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    ((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393 - 1)] = new StringBuilder().append(string).append(i_11_).toString();
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("pw.zi(").append(')').toString());
	}
    }
}
