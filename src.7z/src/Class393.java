/* Class393 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.Canvas;

final class Class393 implements Runnable {
    public void run() {
	try {
	    try {
		IcmpService_Sub1.anIcmpService_Sub1_8551.run();
	    }
	    catch (Throwable throwable) {
		/* empty */
	    }
	    IcmpService_Sub1.anIcmpService_Sub1_8551 = null;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("qg.run(").append(')').toString());
	}
    }

    static final void method4890(Class403 class403, int i) {
	try {
	    Class343_Sub1 class343_sub1 = Class365_Sub1_Sub5_Sub2.method4537(-1844616011);
	    if (class343_sub1 != null) {
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = class343_sub1.anInt7717 * -15394297;
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = -877023375 * class343_sub1.anInt3670;
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = class343_sub1.aString7719;
		Class353 class353 = class343_sub1.method4163(275518730);
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = class353.anInt3820 * 1675394033;
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = class353.aString3819;
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = class343_sub1.anInt3666 * -945794709;
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = class343_sub1.anInt7720 * 512449113;
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = class343_sub1.aString7718;
	    } else {
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = -1;
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = "";
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = "";
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
		((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393) - 1] = "";
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("qg.alh(").append(')').toString());
	}
    }

    static final void method4891(IComponentDefinition class105, Class119 class119, Class403 class403, byte i) {
	try {
	    class105.anInt1184 = 1234689410;
	    class105.aClass498_1307 = null;
	    class105.anInt1151 = (((Class403) class403).anIntArray5244[(((Class403) class403).anInt5239 -= -391880689) * 681479919]) * -1825442367;
	    if (class105.anInt1154 * -1309843523 == -1 && !class119.aBoolean1403)
		Class422.method5623(class105.ihash * -440872681, 2026838544);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("qg.hx(").append(')').toString());
	}
    }

    static synchronized Toolkit method4892(int i, Canvas canvas, Interface_ma interface_ma, JS5 class243, int i_0_, int i_1_, int i_2_, int i_3_) {
	try {
	    if (i == 0)
		return Class141.method1562(canvas, interface_ma, i_1_, i_2_, (byte) 88);
	    if (i == 2)
		return Class273.method2563(canvas, interface_ma, i_1_, i_2_, (byte) -28);
	    if (1 == i)
		return Class59.method696(canvas, interface_ma, i_0_);
	    if (5 == i)
		return Class259.method2456(canvas, interface_ma, class243, i_0_);
	    if (3 == i)
		return Class204.method1912(canvas, interface_ma, class243, i_0_);
	    throw new IllegalArgumentException("");
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("qg.f(").append(')').toString());
	}
    }

    static final void method4893(Class403 class403, byte i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = class105.anInt1297 * -407676483;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("qg.pl(").append(')').toString());
	}
    }

    static final void method4894(Class403 class403, int i) {
	try {
	    ((Class403) class403).anInt5239 -= -783761378;
	    int i_4_ = (((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239]);
	    int i_5_ = (((Class403) class403).anIntArray5244[((Class403) class403).anInt5239 * 681479919 + 1]);
	    if (0 == i_4_)
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = 0;
	    else
		((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919) - 1] = (int) Math.pow((double) i_4_, (double) i_5_);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("qg.zb(").append(')').toString());
	}
    }

    static final void method4895(Class403 class403, int i) {
	try {
	    int i_6_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    IComponentDefinition class105 = Class50.getIComponentDefinitions(i_6_, (byte) -21);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = 684246511 * class105.anInt1166;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("qg.rn(").append(')').toString());
	}
    }

    public static Class165 method4896(RsByteBuffer class298_sub53, byte i) {
	try {
	    int i_7_ = class298_sub53.readBigSmart(1235052657);
	    return new Class165(i_7_);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("qg.a(").append(')').toString());
	}
    }
}
