/* Class40_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import jaclib.memory.Buffer;

public class Class40_Sub2 extends Class40 implements Interface1 {
    int anInt6319;

    public long method16() {
	return 0L;
    }

    Class40_Sub2(GLToolkit class_ra_sub2, int i, Buffer buffer, int i_0_, boolean bool) {
	super(class_ra_sub2, 34962, buffer, i_0_, bool);
	((Class40_Sub2) this).anInt6319 = i;
    }

    public int method10() {
	return ((Class40_Sub2) this).anInt436;
    }

    Class40_Sub2(GLToolkit class_ra_sub2, int i, byte[] is, int i_1_, boolean bool) {
	super(class_ra_sub2, 34962, is, i_1_, bool);
	((Class40_Sub2) this).anInt6319 = i;
    }

    public int method12() {
	return ((Class40_Sub2) this).anInt436;
    }

    public long method7() {
	return 0L;
    }

    public int method15() {
	return ((Class40_Sub2) this).anInt6319;
    }

    public int method9() {
	return ((Class40_Sub2) this).anInt436;
    }

    public int method6() {
	return ((Class40_Sub2) this).anInt436;
    }

    public int method11() {
	return ((Class40_Sub2) this).anInt436;
    }

    void method478() {
	((Class40_Sub2) this).aClass_ra_Sub2_437.method5246(this);
    }

    public int method13() {
	return ((Class40_Sub2) this).anInt6319;
    }

    public int method14() {
	return ((Class40_Sub2) this).anInt6319;
    }

    public void method8(int i, byte[] is, int i_2_) {
	method479(is, i_2_);
	((Class40_Sub2) this).anInt6319 = i;
    }

    public long method5() {
	return 0L;
    }

    void method480() {
	((Class40_Sub2) this).aClass_ra_Sub2_437.method5246(this);
    }

    public void method17(int i, byte[] is, int i_3_) {
	method479(is, i_3_);
	((Class40_Sub2) this).anInt6319 = i;
    }
}
