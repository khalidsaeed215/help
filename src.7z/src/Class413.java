/* Class413 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class413 implements Interface21 {
    static Class413 aClass413_6575;
    public static Class413 aClass413_6576;
    static Class413 aClass413_6577;
    static Class413 aClass413_6578;
    static Class413 aClass413_6579;
    static Class413 aClass413_6580;
    static Class413 aClass413_6581;
    static Class413 aClass413_6582;
    static Class413 aClass413_6583;
    public static Class413 aClass413_6584 = new Class413(-2);
    static Class413 aClass413_6585;
    static Class413 aClass413_6586;
    public static Class413 aClass413_6587;
    static Class413 aClass413_6588;
    int anInt6589;
    public static int anInt6590;

    Class413(int i) {
	((Class413) this).anInt6589 = i * -548304903;
    }

    public int getType(int i) {
	try {
	    return 1997834825 * ((Class413) this).anInt6589;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("rd.f(").append(')').toString());
	}
    }

    static {
	aClass413_6576 = new Class413(-3);
	aClass413_6577 = new Class413(2);
	aClass413_6587 = new Class413(3);
	aClass413_6579 = new Class413(9);
	aClass413_6580 = new Class413(10);
	aClass413_6581 = new Class413(20);
	aClass413_6578 = new Class413(21);
	aClass413_6588 = new Class413(30);
	aClass413_6575 = new Class413(31);
	aClass413_6585 = new Class413(32);
	aClass413_6583 = new Class413(33);
	aClass413_6586 = new Class413(34);
	aClass413_6582 = new Class413(38);
    }

    public int method243() {
	return 1997834825 * ((Class413) this).anInt6589;
    }

    public int method244() {
	return 1997834825 * ((Class413) this).anInt6589;
    }

    static void method5582(Class403 class403, int i) {
	try {
	    Class369 class369 = Class316.aClass362_3318.method4307((((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]), 245040087);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = (class369.anIntArray4019 == null ? 0 : class369.anIntArray4019.length);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("rd.t(").append(')').toString());
	}
    }

    public static void method5583(int i, short i_0_) {
	try {
	    Class298_Sub37_Sub12 class298_sub37_sub12 = Class410.method4985(7, (long) i);
	    class298_sub37_sub12.method3445(-1807179158);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("rd.q(").append(')').toString());
	}
    }

    public static boolean method5584(int i, int i_1_) {
	try {
	    return (19 == i || 1 == i || 4 == i || i == 3 || i == 8 || 2 == i || i == 9);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("rd.fo(").append(')').toString());
	}
    }
}
