/* Class414 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class414 {
    static Class4 aClass4_5326;

    Class414() throws Throwable {
	throw new Error();
    }

    static final void method5585(Class403 class403, int i) {
	try {
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = ((Class403) class403).aClass162_5252.aByte1659;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("re.xf(").append(')').toString());
	}
    }
}
