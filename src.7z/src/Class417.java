/* Class417 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class417 {
    int anInt5335;
    int anInt5336;
    static Class298_Sub13 aClass298_Sub13_5337;
    boolean aBoolean5338;

    Class417(int i, int i_0_, boolean bool) {
	((Class417) this).anInt5335 = 752250551 * i;
	((Class417) this).anInt5336 = i_0_ * 1840099775;
	((Class417) this).aBoolean5338 = bool;
    }

    public int method5592(int i) {
	try {
	    return 839597631 * ((Class417) this).anInt5336;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("rh.f(").append(')').toString());
	}
    }

    public boolean method5593(int i) {
	try {
	    return ((Class417) this).aBoolean5338;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("rh.b(").append(')').toString());
	}
    }

    public int method5594(int i) {
	try {
	    return -1521758457 * ((Class417) this).anInt5335;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("rh.a(").append(')').toString());
	}
    }

    static final void method5595(Class403 class403, int i) {
	try {
	    String string = (String) (((Class403) class403).anObjectArray5240[(((Class403) class403).anInt5241 -= 969361751) * -203050393]);
	    if (string.startsWith(Class247.method2368(0, -278777595)) || string.startsWith(Class247.method2368(1, -278777595)))
		string = string.substring(7);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class287.method2722(string, -1704738682) ? 1 : 0;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("rh.wo(").append(')').toString());
	}
    }
}
