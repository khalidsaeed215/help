/* Class421 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class421 {
    Class421() throws Throwable {
	throw new Error();
    }

    static final void method5609(Class403 class403, byte i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    JS5.method2317(class105, class119, class403, -166663467);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("rl.nn(").append(')').toString());
	}
    }
}
