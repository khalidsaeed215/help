/* Class422_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class422_Sub1 extends Class422 {
    int method5612(int i, int i_0_) {
	try {
	    return 1;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ada.f(").append(')').toString());
	}
    }

    void method5614(int i, int i_1_) {
	try {
	    anInt5350 = 1886334997 * i;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ada.p(").append(')').toString());
	}
    }

    public void method5624(byte i) {
	try {
	    if (anInt5350 * -1598873795 < 0 || anInt5350 * -1598873795 > 4)
		anInt5350 = method5611(-1354867045) * 1886334997;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ada.s(").append(')').toString());
	}
    }

    int method5611(int i) {
	try {
	    return 3;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ada.a(").append(')').toString());
	}
    }

    public int method5625(int i) {
	try {
	    return -1598873795 * anInt5350;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ada.z(").append(')').toString());
	}
    }

    public Class422_Sub1(Class298_Sub48 class298_sub48) {
	super(class298_sub48);
    }

    int method5615() {
	return 3;
    }

    int method5616(int i) {
	return 1;
    }

    void method5610(int i) {
	anInt5350 = 1886334997 * i;
    }

    public Class422_Sub1(int i, Class298_Sub48 class298_sub48) {
	super(i, class298_sub48);
    }

    static void method5626(int i) {
	try {
	    /* empty */
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ada.a(").append(')').toString());
	}
    }
}
