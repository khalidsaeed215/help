/* Class422_Sub13 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class422_Sub13 extends Class422 {
    public static int anInt8396 = 0;
    static int anInt8397 = 2;

    public Class422_Sub13(int i, Class298_Sub48 class298_sub48) {
	super(i, class298_sub48);
    }

    public void method5673(byte i) {
	try {
	    if (aClass298_Sub48_5346.aClass422_Sub14_7571.method5679(16711680) && !Class261.method2465(aClass298_Sub48_5346.aClass422_Sub14_7571.method5677(-1298559578), 1142209695))
		anInt5350 = 0;
	    if (anInt5350 * -1598873795 < 0 || anInt5350 * -1598873795 > 2)
		anInt5350 = method5611(-1016152227) * 1886334997;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ado.s(").append(')').toString());
	}
    }

    public Class422_Sub13(Class298_Sub48 class298_sub48) {
	super(class298_sub48);
    }

    public boolean method5674(int i) {
	try {
	    if (!Class261.method2465(aClass298_Sub48_5346.aClass422_Sub14_7571.method5677(-541516290), 718607573))
		return false;
	    return true;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ado.z(").append(')').toString());
	}
    }

    int method5611(int i) {
	try {
	    return 0;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ado.a(").append(')').toString());
	}
    }

    void method5614(int i, int i_0_) {
	try {
	    anInt5350 = i * 1886334997;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ado.p(").append(')').toString());
	}
    }

    public int method5675(int i) {
	try {
	    return anInt5350 * -1598873795;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ado.y(").append(')').toString());
	}
    }

    int method5615() {
	return 0;
    }

    public int method5616(int i) {
	if (!Class261.method2465(aClass298_Sub48_5346.aClass422_Sub14_7571.method5677(-2048845946), -31427967))
	    return 3;
	return 1;
    }

    void method5610(int i) {
	anInt5350 = i * 1886334997;
    }

    public int method5612(int i, int i_1_) {
	try {
	    if (!Class261.method2465(aClass298_Sub48_5346.aClass422_Sub14_7571.method5677(-1771476690), -1583872086))
		return 3;
	    return 1;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ado.f(").append(')').toString());
	}
    }

    static void method5676(int i, int i_2_, int i_3_, int i_4_, int i_5_, int i_6_, int i_7_, int i_8_) {
	try {
	    int i_9_ = 0;
	    int i_10_ = i_4_;
	    int i_11_ = 0;
	    int i_12_ = i_3_ - i_7_;
	    int i_13_ = i_4_ - i_7_;
	    int i_14_ = i_3_ * i_3_;
	    int i_15_ = i_4_ * i_4_;
	    int i_16_ = i_12_ * i_12_;
	    int i_17_ = i_13_ * i_13_;
	    int i_18_ = i_15_ << 1;
	    int i_19_ = i_14_ << 1;
	    int i_20_ = i_17_ << 1;
	    int i_21_ = i_16_ << 1;
	    int i_22_ = i_4_ << 1;
	    int i_23_ = i_13_ << 1;
	    int i_24_ = (1 - i_22_) * i_14_ + i_18_;
	    int i_25_ = i_15_ - i_19_ * (i_22_ - 1);
	    int i_26_ = i_20_ + i_16_ * (1 - i_23_);
	    int i_27_ = i_17_ - (i_23_ - 1) * i_21_;
	    int i_28_ = i_14_ << 2;
	    int i_29_ = i_15_ << 2;
	    int i_30_ = i_16_ << 2;
	    int i_31_ = i_17_ << 2;
	    int i_32_ = 3 * i_18_;
	    int i_33_ = i_19_ * (i_22_ - 3);
	    int i_34_ = i_20_ * 3;
	    int i_35_ = (i_23_ - 3) * i_21_;
	    int i_36_ = i_29_;
	    int i_37_ = i_28_ * (i_4_ - 1);
	    int i_38_ = i_31_;
	    int i_39_ = (i_13_ - 1) * i_30_;
	    if (i_2_ >= 1155384281 * Class372_Sub1_Sub1.anInt4049 && i_2_ <= Class372_Sub1_Sub1.anInt4050 * -1062447355) {
		int[] is = Class372_Sub1_Sub1.anIntArrayArray4047[i_2_];
		int i_40_ = Class463.method6012(i - i_3_, (Class372_Sub1_Sub1.anInt4051 * -1424479739), (Class372_Sub1_Sub1.anInt4048 * 1135094847), -1212608691);
		int i_41_ = Class463.method6012(i + i_3_, (-1424479739 * Class372_Sub1_Sub1.anInt4051), (Class372_Sub1_Sub1.anInt4048 * 1135094847), -1212608691);
		int i_42_ = Class463.method6012(i - i_12_, (Class372_Sub1_Sub1.anInt4051 * -1424479739), (1135094847 * Class372_Sub1_Sub1.anInt4048), -1212608691);
		int i_43_ = Class463.method6012(i_12_ + i, (Class372_Sub1_Sub1.anInt4051 * -1424479739), (Class372_Sub1_Sub1.anInt4048 * 1135094847), -1212608691);
		Class82_Sub22.method940(is, i_40_, i_42_, i_6_, 1844098272);
		Class82_Sub22.method940(is, i_42_, i_43_, i_5_, -739253867);
		Class82_Sub22.method940(is, i_43_, i_41_, i_6_, 133831113);
	    }
	    while (i_10_ > 0) {
		boolean bool = i_10_ <= i_13_;
		if (bool) {
		    if (i_26_ < 0) {
			while (i_26_ < 0) {
			    i_26_ += i_34_;
			    i_27_ += i_38_;
			    i_34_ += i_31_;
			    i_38_ += i_31_;
			    i_11_++;
			}
		    }
		    if (i_27_ < 0) {
			i_26_ += i_34_;
			i_27_ += i_38_;
			i_34_ += i_31_;
			i_38_ += i_31_;
			i_11_++;
		    }
		    i_26_ += -i_39_;
		    i_27_ += -i_35_;
		    i_35_ -= i_30_;
		    i_39_ -= i_30_;
		}
		if (i_24_ < 0) {
		    while (i_24_ < 0) {
			i_24_ += i_32_;
			i_25_ += i_36_;
			i_32_ += i_29_;
			i_36_ += i_29_;
			i_9_++;
		    }
		}
		if (i_25_ < 0) {
		    i_24_ += i_32_;
		    i_25_ += i_36_;
		    i_32_ += i_29_;
		    i_36_ += i_29_;
		    i_9_++;
		}
		i_24_ += -i_37_;
		i_25_ += -i_33_;
		i_33_ -= i_28_;
		i_37_ -= i_28_;
		i_10_--;
		int i_44_ = i_2_ - i_10_;
		int i_45_ = i_10_ + i_2_;
		if (i_45_ >= Class372_Sub1_Sub1.anInt4049 * 1155384281 && i_44_ <= -1062447355 * Class372_Sub1_Sub1.anInt4050) {
		    int i_46_ = Class463.method6012(i + i_9_, (Class372_Sub1_Sub1.anInt4051 * -1424479739), (1135094847 * Class372_Sub1_Sub1.anInt4048), -1212608691);
		    int i_47_ = Class463.method6012(i - i_9_, (-1424479739 * Class372_Sub1_Sub1.anInt4051), (Class372_Sub1_Sub1.anInt4048 * 1135094847), -1212608691);
		    if (bool) {
			int i_48_ = (Class463.method6012(i + i_11_, -1424479739 * Class372_Sub1_Sub1.anInt4051, Class372_Sub1_Sub1.anInt4048 * 1135094847, -1212608691));
			int i_49_ = (Class463.method6012(i - i_11_, Class372_Sub1_Sub1.anInt4051 * -1424479739, 1135094847 * Class372_Sub1_Sub1.anInt4048, -1212608691));
			if (i_44_ >= 1155384281 * Class372_Sub1_Sub1.anInt4049) {
			    int[] is = (Class372_Sub1_Sub1.anIntArrayArray4047[i_44_]);
			    Class82_Sub22.method940(is, i_47_, i_49_, i_6_, -1776826233);
			    Class82_Sub22.method940(is, i_49_, i_48_, i_5_, 651762139);
			    Class82_Sub22.method940(is, i_48_, i_46_, i_6_, 1941324857);
			}
			if (i_45_ <= Class372_Sub1_Sub1.anInt4050 * -1062447355) {
			    int[] is = (Class372_Sub1_Sub1.anIntArrayArray4047[i_45_]);
			    Class82_Sub22.method940(is, i_47_, i_49_, i_6_, -1085147179);
			    Class82_Sub22.method940(is, i_49_, i_48_, i_5_, -2113781639);
			    Class82_Sub22.method940(is, i_48_, i_46_, i_6_, 154634107);
			}
		    } else {
			if (i_44_ >= 1155384281 * Class372_Sub1_Sub1.anInt4049)
			    Class82_Sub22.method940((Class372_Sub1_Sub1.anIntArrayArray4047[i_44_]), i_47_, i_46_, i_6_, -1094701951);
			if (i_45_ <= Class372_Sub1_Sub1.anInt4050 * -1062447355)
			    Class82_Sub22.method940((Class372_Sub1_Sub1.anIntArrayArray4047[i_45_]), i_47_, i_46_, i_6_, 1089051807);
		    }
		}
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ado.av(").append(')').toString());
	}
    }
}
