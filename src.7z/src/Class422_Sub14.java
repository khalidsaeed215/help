/* Class422_Sub14 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class422_Sub14 extends Class422 {
    public boolean aBoolean8398;
    boolean aBoolean8399 = true;
    public static int anInt8400;

    void method5610(int i) {
	aBoolean8398 = false;
	anInt5350 = i * 1886334997;
    }

    public Class422_Sub14(int i, Class298_Sub48 class298_sub48) {
	super(i, class298_sub48);
	aBoolean8398 = false;
    }

    int method5611(int i) {
	try {
	    aBoolean8398 = true;
	    return 2;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adq.a(").append(')').toString());
	}
    }

    public int method5677(int i) {
	try {
	    return anInt5350 * -1598873795;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adq.y(").append(')').toString());
	}
    }

    public int method5612(int i, int i_0_) {
	try {
	    if (i == 3 && !EmitterConfig.method955(399394159).method263("jagdx", 953164074))
		return 3;
	    return 2;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adq.f(").append(')').toString());
	}
    }

    void method5614(int i, int i_1_) {
	try {
	    aBoolean8398 = false;
	    anInt5350 = i * 1886334997;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adq.p(").append(')').toString());
	}
    }

    public void method5678(byte i) {
	try {
	    if (anInt5350 * -1598873795 < 0 || -1598873795 * anInt5350 > 5)
		anInt5350 = method5611(1207214365) * 1886334997;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adq.s(").append(')').toString());
	}
    }

    boolean method5679(int i) {
	try {
	    return ((Class422_Sub14) this).aBoolean8399;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adq.t(").append(')').toString());
	}
    }

    public void method5680(boolean bool, int i) {
	try {
	    ((Class422_Sub14) this).aBoolean8399 = bool;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adq.h(").append(')').toString());
	}
    }

    public int method5616(int i) {
	if (i == 3 && !EmitterConfig.method955(-91945670).method263("jagdx", 323040100))
	    return 3;
	return 2;
    }

    public Class422_Sub14(Class298_Sub48 class298_sub48) {
	super(class298_sub48);
	aBoolean8398 = false;
    }

    int method5615() {
	aBoolean8398 = true;
	return 2;
    }

    public boolean method5681(int i) {
	try {
	    return true;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adq.z(").append(')').toString());
	}
    }

    public static void method5682(int i, int i_2_) {
	try {
	    Class298_Sub37_Sub12 class298_sub37_sub12 = Class410.method4985(12, (long) i);
	    class298_sub37_sub12.method3445(-1192057817);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adq.j(").append(')').toString());
	}
    }
}
