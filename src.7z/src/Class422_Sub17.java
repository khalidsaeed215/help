/* Class422_Sub17 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class422_Sub17 extends Class422 {
    public static int anInt8405 = 2;
    public static int anInt8406 = 1;
    public static int anInt8407 = 0;

    int method5616(int i) {
	return 1;
    }

    public Class422_Sub17(int i, Class298_Sub48 class298_sub48) {
	super(i, class298_sub48);
    }

    public void method5688(int i) {
	try {
	    if (aClass298_Sub48_5346.aClass422_Sub10_7548.method5661((byte) 108) == 2 && -1598873795 * anInt5350 == 2)
		anInt5350 = 1886334997;
	    if (anInt5350 * -1598873795 < 0 || anInt5350 * -1598873795 > 2)
		anInt5350 = method5611(-1426202830) * 1886334997;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adw.s(").append(')').toString());
	}
    }

    void method5614(int i, int i_0_) {
	try {
	    anInt5350 = 1886334997 * i;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adw.p(").append(')').toString());
	}
    }

    public int method5689(int i) {
	try {
	    return anInt5350 * -1598873795;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adw.z(").append(')').toString());
	}
    }

    int method5615() {
	return 2;
    }

    int method5611(int i) {
	try {
	    return 2;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adw.a(").append(')').toString());
	}
    }

    public Class422_Sub17(Class298_Sub48 class298_sub48) {
	super(class298_sub48);
    }

    void method5610(int i) {
	anInt5350 = 1886334997 * i;
    }

    int method5612(int i, int i_1_) {
	try {
	    return 1;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adw.f(").append(')').toString());
	}
    }

    static final void method5690(Class403 class403, int i) {
	try {
	    String string = (String) (((Class403) class403).anObjectArray5240[(((Class403) class403).anInt5241 -= 969361751) * -203050393]);
	    ((Class403) class403).aClass214_5256 = new Class214(string, true);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adw.ago(").append(')').toString());
	}
    }
}
