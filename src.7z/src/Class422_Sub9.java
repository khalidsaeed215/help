/* Class422_Sub9 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.util.Date;

public class Class422_Sub9 extends Class422 {
    public static int anInt8389 = 1;
    public static int anInt8390 = 0;

    int method5616(int i) {
	return 1;
    }

    public Class422_Sub9(Class298_Sub48 class298_sub48) {
	super(class298_sub48);
    }

    void method5610(int i) {
	anInt5350 = i * 1886334997;
    }

    int method5612(int i, int i_0_) {
	try {
	    return 1;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adk.f(").append(')').toString());
	}
    }

    void method5614(int i, int i_1_) {
	try {
	    anInt5350 = i * 1886334997;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adk.p(").append(')').toString());
	}
    }

    public int method5655(int i) {
	try {
	    return -1598873795 * anInt5350;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adk.z(").append(')').toString());
	}
    }

    int method5615() {
	return 1;
    }

    public void method5656(int i) {
	try {
	    if (1 != -1598873795 * anInt5350 && -1598873795 * anInt5350 != 0)
		anInt5350 = method5611(763127121) * 1886334997;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adk.s(").append(')').toString());
	}
    }

    public Class422_Sub9(int i, Class298_Sub48 class298_sub48) {
	super(i, class298_sub48);
    }

    int method5611(int i) {
	try {
	    return 1;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adk.a(").append(')').toString());
	}
    }

    static final void method5657(Class403 class403, int i) {
	try {
	    Class317.method3853(1630934312);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adk.agb(").append(')').toString());
	}
    }

    static void method5658(long l) {
	try {
	    Class490.aCalendar6073.setTime(new Date(l));
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("adk.d(").append(')').toString());
	}
    }
}
