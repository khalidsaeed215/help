/* Class428 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class428 implements Interface21 {
    static Class428 aClass428_6616;
    static Class428 aClass428_6617;
    public static Class428 aClass428_6618 = new Class428(-2);
    public static Class428 aClass428_6619;
    public static Class428 aClass428_6620 = new Class428(-3);
    static Class428 aClass428_6621 = new Class428(2);
    int anInt6622;
    static int anInt6623;

    public int method244() {
	return ((Class428) this).anInt6622 * -1057257489;
    }

    public int getType(int i) {
	try {
	    return ((Class428) this).anInt6622 * -1057257489;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("rs.f(").append(')').toString());
	}
    }

    static {
	aClass428_6619 = new Class428(3);
	aClass428_6616 = new Class428(21);
	aClass428_6617 = new Class428(20);
    }

    public int method243() {
	return ((Class428) this).anInt6622 * -1057257489;
    }

    Class428(int i) {
	((Class428) this).anInt6622 = -928217329 * i;
    }

    static final void method5752(Class403 class403, byte i) {
	try {
	    Class108.method1150(true, (byte) 97);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("rs.sl(").append(')').toString());
	}
    }
}
