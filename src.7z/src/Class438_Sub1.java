/* Class438_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class438_Sub1 extends Class438 {
    void method5837(AnimationDefinition class391, int i, byte i_0_) {
	try {
	    Class228.method2119(class391, i, -646004957);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aem.l(").append(')').toString());
	}
    }

    public Class438_Sub1() {
	super(true);
    }

    void method5847(AnimationDefinition class391, int i) {
	Class228.method2119(class391, i, -1673739713);
    }
}
