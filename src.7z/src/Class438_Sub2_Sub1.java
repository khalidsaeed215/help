/* Class438_Sub2_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class438_Sub2_Sub1 extends Class438_Sub2 {
    public int anInt9874;

    public Class438_Sub2_Sub1(Class365_Sub1 class365_sub1) {
	super(class365_sub1, false);
    }
}
