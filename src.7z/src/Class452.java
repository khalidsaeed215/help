/* Class452 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public final class Class452 {
    public static boolean aBoolean5642 = true;

    Class452() throws Throwable {
	throw new Error();
    }
}
