/* Class456 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class456 {
    int anInt5662;
    public int anInt5663;
    public int anInt5664;
    public int anInt5665;

    Class456() {
	/* empty */
    }

    static final void method5959(Class403 class403, int i) {
	try {
	    int i_0_ = Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub17_7564.method5689(-2013953489);
	    Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub17_7565, (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]) == 1 ? 0 : i_0_, -1763382439);
	    Class475.method6075((short) -2481);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("su.aij(").append(')').toString());
	}
    }
}
