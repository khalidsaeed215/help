/* Class463 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class463 {
    public static Class463 aClass463_5684;
    public static Class463 aClass463_5685;
    public static Class463 aClass463_5686;
    public static Class463 aClass463_5687 = new Class463();
    public static JS5 idx11;
    public static Class433 aClass433_5689;

    static final void method6008(Class403 class403, byte i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class225.method2102(class105, class119, class403, (short) -9329);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("tc.jk(").append(')').toString());
	}
    }

    static {
	aClass463_5684 = new Class463();
	aClass463_5686 = new Class463();
	aClass463_5685 = new Class463();
    }

    Class463() {
	/* empty */
    }

    public static void method6009(int i, int i_0_, int i_1_, int i_2_, int i_3_) {
	try {
	    Class372.anInt4051 = i * 1418334925;
	    Class372.anInt4048 = 728613823 * i_1_;
	    Class372.anInt4049 = i_0_ * 1131449449;
	    Class372.anInt4050 = i_2_ * -879501875;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("tc.f(").append(')').toString());
	}
    }

    static final void method6010(Class403 class403, int i) {
	try {
	    int i_4_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    IComponentDefinition class105 = Class50.getIComponentDefinitions(i_4_, (byte) -30);
	    Class119 class119 = Class389.aClass119Array4165[i_4_ >> 16];
	    Class73.method821(class105, class119, class403, (short) 255);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("tc.ew(").append(')').toString());
	}
    }

    static void method6011(Toolkit class_ra, int i) {
	try {
	    if (!Class436.aBoolean5496)
		Class310.method3810(class_ra, -1625873215);
	    else
		Class82_Sub11.method907(class_ra, -618250178);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("tc.aj(").append(')').toString());
	}
    }

    static final int method6012(int i, int i_5_, int i_6_, int i_7_) {
	try {
	    return i < i_5_ ? i_5_ : i > i_6_ ? i_6_ : i;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("tc.p(").append(')').toString());
	}
    }

    static void method6013(Toolkit class_ra, byte i) {
	try {
	    if (Class436.aBoolean5478)
		method6011(class_ra, -2009290337);
	    else
		Class7.method314(class_ra, 1272900210);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("tc.l(").append(')').toString());
	}
    }

    static void method6014(int i, int i_8_, int i_9_, int i_10_) {
	try {
	    if (1008 == i)
		Class126.method1405(Class502.aClass502_6715, i_8_, i_9_, 67564061);
	    else if (i == 1009)
		Class126.method1405(Class502.aClass502_6717, i_8_, i_9_, -679680198);
	    else if (i == 1010)
		Class126.method1405(Class502.aClass502_6714, i_8_, i_9_, -1335757742);
	    else if (1011 == i)
		Class126.method1405(Class502.aClass502_6726, i_8_, i_9_, -1097682484);
	    else if (i == 1012)
		Class126.method1405(Class502.aClass502_6729, i_8_, i_9_, -1428410660);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("tc.cm(").append(')').toString());
	}
    }
}
