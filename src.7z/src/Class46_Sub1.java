/* Class46_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class46_Sub1 extends Class46 implements Interface2 {
    public void method18(int i, byte[] is, int i_0_) {
	method499(is, i_0_);
    }

    public int method26() {
	return 0;
    }

    public long method20() {
	return ((Class46_Sub1) this).aBuffer489.f();
    }

    public void method19(int i, byte[] is, int i_1_) {
	method499(is, i_1_);
    }

    public int method21() {
	return 0;
    }

    Class46_Sub1(GLToolkit class_ra_sub2, int i, byte[] is, int i_2_) {
	super(class_ra_sub2, is, i_2_);
    }

    public long method23() {
	return ((Class46_Sub1) this).aBuffer489.f();
    }

    public long method24() {
	return ((Class46_Sub1) this).aBuffer489.f();
    }

    public void method25(int i, byte[] is, int i_3_) {
	method499(is, i_3_);
    }

    public int method22() {
	return 0;
    }

    public void method27(int i, byte[] is, int i_4_) {
	method499(is, i_4_);
    }
}
