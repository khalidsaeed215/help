/* Class474 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class474 {
    public static boolean aBoolean5970;
    static int anInt5971;
    public static IPAddress aClass471_5972;
    public static boolean aBoolean5973;
    public static boolean aBoolean5974 = false;
    static Class343_Sub1[] aClass343_Sub1Array5975 = new Class343_Sub1[0];
    public static IPAddress aClass471_5976;
    static int anInt5977 = 1105886704;
    static Class396 aClass396_5978;
    public static IPAddress aClass471_5979;
    public static int anInt5980;

    static {
	anInt5971 = 0;
	aClass396_5978 = null;
	aBoolean5970 = false;
    }

    Class474() throws Throwable {
	throw new Error();
    }

    static final void method6071(Class403 class403, int i) {
	try {
	    String string = (String) (((Class403) class403).anObjectArray5240[(((Class403) class403).anInt5241 -= 969361751) * -203050393]);
	    Class12.method338(string, false, (short) 32562);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("tn.vi(").append(')').toString());
	}
    }

    static final void method6072(int i, int i_0_, int i_1_, int i_2_, int i_3_) {
	try {
	    if (i > i_0_)
		Class82_Sub22.method940((Class372_Sub2.anIntArrayArray4047[i_1_]), i_0_, i, i_2_, 1232193960);
	    else
		Class82_Sub22.method940((Class372_Sub2.anIntArrayArray4047[i_1_]), i, i_0_, i_2_, 583868785);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("tn.n(").append(')').toString());
	}
    }

    static final void method6073(Class403 class403, short i) {
	try {
	    Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub29_7553, (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]), -877652668);
	    Class3.method300(656179282);
	    pb.aBoolean8666 = false;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("tn.ais(").append(')').toString());
	}
    }
}
