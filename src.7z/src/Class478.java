/* Class478 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class478 {
    static Class453 aClass453_6002 = new Class453();

    Class478() throws Throwable {
	throw new Error();
    }

    static final void method6097(IComponentDefinition class105, Class119 class119, Class403 class403, int i) {
	try {
	    int i_0_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    if (i_0_ == 270446479 * IComponentDefinition.anInt1266 || -1179480373 * IComponentDefinition.anInt1119 == i_0_ || 1432814379 * IComponentDefinition.anInt1206 == i_0_)
		class105.anInt1236 = i_0_ * 2138287179;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ts.id(").append(')').toString());
	}
    }

    public static final int method6098(String string, int i) {
	try {
	    if (null == string)
		return -1;
	    for (int i_1_ = 0; i_1_ < -1054937867 * pb.anInt8941; i_1_++) {
		if (string.equalsIgnoreCase(pb.aStringArray8704[i_1_]))
		    return i_1_;
	    }
	    return -1;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ts.lg(").append(')').toString());
	}
    }

    static void method6099(JS5 class243, int i, int i_2_, int i_3_, boolean bool, long l) {
	try {
	    WorldTile.method4143(class243, i, i_2_, i_3_, bool, l, 0, -1584646162);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("ts.p(").append(')').toString());
	}
    }
}
