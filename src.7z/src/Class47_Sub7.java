/* Class47_Sub7 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import jaggl.OpenGL;

public class Class47_Sub7 extends Class47 {
    static char aChar6794 = '\001';
    boolean aBoolean6795 = false;
    Class28 aClass28_6796;
    static char aChar6797 = '\0';

    void method508(boolean bool) {
	((Class47_Sub7) this).aClass_ra_Sub2_491.method5258(8448, 7681);
    }

    boolean method501() {
	return true;
    }

    void method505(boolean bool) {
	Class30_Sub1 class30_sub1 = ((Class47_Sub7) this).aClass_ra_Sub2_491.method5280();
	if (((Class47_Sub7) this).aClass28_6796 != null && class30_sub1 != null && bool) {
	    ((Class47_Sub7) this).aClass28_6796.method404('\0');
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(1);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5256(class30_sub1);
	    OpenGL.glMatrixMode(5890);
	    OpenGL.glLoadMatrixf((((GLToolkit) ((Class47_Sub7) this).aClass_ra_Sub2_491).aClass233_8089.method2160(((GLToolkit) ((Class47_Sub7) this).aClass_ra_Sub2_491).aFloatArray8106)), 0);
	    OpenGL.glMatrixMode(5888);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(0);
	    ((Class47_Sub7) this).aBoolean6795 = true;
	} else
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5286(0, 34168, 770);
    }

    void method518(boolean bool) {
	((Class47_Sub7) this).aClass_ra_Sub2_491.method5258(8448, 7681);
    }

    void method509(boolean bool) {
	((Class47_Sub7) this).aClass_ra_Sub2_491.method5258(8448, 7681);
    }

    void method503(int i, int i_0_) {
	/* empty */
    }

    void method500(Class30 class30, int i) {
	((Class47_Sub7) this).aClass_ra_Sub2_491.method5256(class30);
	((Class47_Sub7) this).aClass_ra_Sub2_491.method5243(i);
    }

    void method506(boolean bool) {
	Class30_Sub1 class30_sub1 = ((Class47_Sub7) this).aClass_ra_Sub2_491.method5280();
	if (((Class47_Sub7) this).aClass28_6796 != null && class30_sub1 != null && bool) {
	    ((Class47_Sub7) this).aClass28_6796.method404('\0');
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(1);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5256(class30_sub1);
	    OpenGL.glMatrixMode(5890);
	    OpenGL.glLoadMatrixf((((GLToolkit) ((Class47_Sub7) this).aClass_ra_Sub2_491).aClass233_8089.method2160(((GLToolkit) ((Class47_Sub7) this).aClass_ra_Sub2_491).aFloatArray8106)), 0);
	    OpenGL.glMatrixMode(5888);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(0);
	    ((Class47_Sub7) this).aBoolean6795 = true;
	} else
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5286(0, 34168, 770);
    }

    void method510(boolean bool) {
	((Class47_Sub7) this).aClass_ra_Sub2_491.method5258(8448, 7681);
    }

    void method516(int i, int i_1_) {
	/* empty */
    }

    void method507(boolean bool) {
	Class30_Sub1 class30_sub1 = ((Class47_Sub7) this).aClass_ra_Sub2_491.method5280();
	if (((Class47_Sub7) this).aClass28_6796 != null && class30_sub1 != null && bool) {
	    ((Class47_Sub7) this).aClass28_6796.method404('\0');
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(1);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5256(class30_sub1);
	    OpenGL.glMatrixMode(5890);
	    OpenGL.glLoadMatrixf((((GLToolkit) ((Class47_Sub7) this).aClass_ra_Sub2_491).aClass233_8089.method2160(((GLToolkit) ((Class47_Sub7) this).aClass_ra_Sub2_491).aFloatArray8106)), 0);
	    OpenGL.glMatrixMode(5888);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(0);
	    ((Class47_Sub7) this).aBoolean6795 = true;
	} else
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5286(0, 34168, 770);
    }

    Class47_Sub7(GLToolkit class_ra_sub2) {
	super(class_ra_sub2);
	if (((GLToolkit) class_ra_sub2).aBoolean8178) {
	    ((Class47_Sub7) this).aClass28_6796 = new Class28(class_ra_sub2, 2);
	    ((Class47_Sub7) this).aClass28_6796.method405(0);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(1);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5258(34165, 7681);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5259(2, 34168, 770);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5286(0, 34167, 770);
	    OpenGL.glTexGeni(8192, 9472, 34066);
	    OpenGL.glTexGeni(8193, 9472, 34066);
	    OpenGL.glTexGeni(8194, 9472, 34066);
	    OpenGL.glEnable(3168);
	    OpenGL.glEnable(3169);
	    OpenGL.glEnable(3170);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(0);
	    ((Class47_Sub7) this).aClass28_6796.method403();
	    ((Class47_Sub7) this).aClass28_6796.method405(1);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(1);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5258(8448, 8448);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5259(2, 34166, 770);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5286(0, 5890, 770);
	    OpenGL.glDisable(3168);
	    OpenGL.glDisable(3169);
	    OpenGL.glDisable(3170);
	    OpenGL.glMatrixMode(5890);
	    OpenGL.glLoadIdentity();
	    OpenGL.glMatrixMode(5888);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(0);
	    ((Class47_Sub7) this).aClass28_6796.method403();
	}
    }

    void method511() {
	if (((Class47_Sub7) this).aBoolean6795) {
	    ((Class47_Sub7) this).aClass28_6796.method404('\001');
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(1);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5256(null);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(0);
	} else
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5286(0, 5890, 770);
	((Class47_Sub7) this).aClass_ra_Sub2_491.method5258(8448, 8448);
	((Class47_Sub7) this).aBoolean6795 = false;
    }

    void method512() {
	if (((Class47_Sub7) this).aBoolean6795) {
	    ((Class47_Sub7) this).aClass28_6796.method404('\001');
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(1);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5256(null);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(0);
	} else
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5286(0, 5890, 770);
	((Class47_Sub7) this).aClass_ra_Sub2_491.method5258(8448, 8448);
	((Class47_Sub7) this).aBoolean6795 = false;
    }

    void method513(int i, int i_2_) {
	/* empty */
    }

    void method504() {
	if (((Class47_Sub7) this).aBoolean6795) {
	    ((Class47_Sub7) this).aClass28_6796.method404('\001');
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(1);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5256(null);
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5255(0);
	} else
	    ((Class47_Sub7) this).aClass_ra_Sub2_491.method5286(0, 5890, 770);
	((Class47_Sub7) this).aClass_ra_Sub2_491.method5258(8448, 8448);
	((Class47_Sub7) this).aBoolean6795 = false;
    }

    void method515(int i, int i_3_) {
	/* empty */
    }

    void method502(int i, int i_4_) {
	/* empty */
    }

    void method517(int i, int i_5_) {
	/* empty */
    }

    void method514(Class30 class30, int i) {
	((Class47_Sub7) this).aClass_ra_Sub2_491.method5256(class30);
	((Class47_Sub7) this).aClass_ra_Sub2_491.method5243(i);
    }

    void method519(Class30 class30, int i) {
	((Class47_Sub7) this).aClass_ra_Sub2_491.method5256(class30);
	((Class47_Sub7) this).aClass_ra_Sub2_491.method5243(i);
    }

    boolean method520() {
	return true;
    }
}
