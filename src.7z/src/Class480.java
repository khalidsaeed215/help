/* Class480 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class480 {
    public long method6108(int i) {
	try {
	    return System.nanoTime();
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("tu.a(").append(')').toString());
	}
    }

    public Class480() {
	System.nanoTime();
    }

    static final void method6109(Class403 class403, byte i) {
	try {
	    int i_0_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    IComponentDefinition class105 = Class50.getIComponentDefinitions(i_0_, (byte) -112);
	    Class523.method6329(class105, class403, -2096631087);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("tu.qc(").append(')').toString());
	}
    }
}
