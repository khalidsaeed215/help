/* Class522 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class522 {
    static Class453 aClass453_6283 = new Class453();
    static Class264 aClass264_6284;
    static Toolkit aClass_ra6285;

    Class522() throws Throwable {
	throw new Error();
    }

    static int method6324(int i) {
	try {
	    int i_0_ = Class82_Sub6.aClass227_6843.anInt2548 * -861845079;
	    if (i_0_ < Class230.aClass227Array2561.length - 1)
		Class82_Sub6.aClass227_6843 = Class230.aClass227Array2561[i_0_ + 1];
	    return 100;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("w.k(").append(')').toString());
	}
    }

    public static Class282[] method6325(byte i) {
	try {
	    return (new Class282[] { Class282.aClass282_6540, Class282.aClass282_6543, Class282.aClass282_6541, Class282.aClass282_6545 });
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("w.a(").append(')').toString());
	}
    }

    static final void method6326(IComponentDefinition class105, Class119 class119, Class403 class403, int i) {
	try {
	    class105.anInt1184 = -590899066;
	    class105.aClass498_1307 = null;
	    class105.anInt1151 = (((Class403) class403).anIntArray5244[(((Class403) class403).anInt5239 -= -391880689) * 681479919]) * -1825442367;
	    if (-1 == -1309843523 * class105.anInt1154 && !class119.aBoolean1403)
		Class422.method5623(-440872681 * class105.ihash, 1613777968);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("w.hw(").append(')').toString());
	}
    }

    static final void method6327(Class403 class403, int i) {
	try {
	    if (pb.aBoolean8638)
		Class212.aClass212_2421.method1952(-1732158505);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("w.anx(").append(')').toString());
	}
    }

    public static Class343_Sub1 method6328(byte i) {
	try {
	    return Class226.method2105((1606920449 * Class474.aClass471_5979.worldId), (byte) 52);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("w.d(").append(')').toString());
	}
    }
}
