/* Class52_Sub1_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class52_Sub1_Sub1 extends Class52_Sub1 {
    SafeModeToolkit aClass_ra_Sub1_9052;
    Class12 aClass12_9053;
    Class24 aClass24_9054;
    int anInt9055;
    int anInt9056 = 0;

    public void method563(int i, Interface8_Impl1_Impl1 interface8_impl1_impl1) {
	try {
	    Class24 class24 = (Class24) interface8_impl1_impl1;
	    if (null != ((Class52_Sub1_Sub1) this).aClass12_9053 && class24 != null && ((((Class24) class24).anInt9947 * 215983317 != (((Class12) ((Class52_Sub1_Sub1) this).aClass12_9053).anInt9943) * 1026825677) || (1671547161 * ((Class12) (((Class52_Sub1_Sub1) this).aClass12_9053)).anInt9944 != 467687639 * ((Class24) class24).anInt9948)))
		throw new RuntimeException();
	    ((Class52_Sub1_Sub1) this).aClass24_9054 = class24;
	    if (null != class24) {
		((Class52_Sub1_Sub1) this).anInt9056 = 1103799935 * ((Class24) class24).anInt9947;
		((Class52_Sub1_Sub1) this).anInt9055 = ((Class24) class24).anInt9948 * 1322627015;
	    } else if (((Class52_Sub1_Sub1) this).aClass12_9053 == null) {
		((Class52_Sub1_Sub1) this).anInt9056 = 0;
		((Class52_Sub1_Sub1) this).anInt9055 = 0;
	    }
	    if (this == ((Class52_Sub1_Sub1) this).aClass_ra_Sub1_9052.method4992((short) 7140))
		method136();
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aeu.z(").append(')').toString());
	}
    }

    public int method545() {
	try {
	    return ((Class52_Sub1_Sub1) this).anInt9056 * 494047915;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aeu.a(").append(')').toString());
	}
    }

    public int method547() {
	return ((Class52_Sub1_Sub1) this).anInt9056 * 494047915;
    }

    public int method549() {
	return ((Class52_Sub1_Sub1) this).anInt9056 * 494047915;
    }

    Class52_Sub1_Sub1(SafeModeToolkit class_ra_sub1) {
	((Class52_Sub1_Sub1) this).anInt9055 = 0;
	((Class52_Sub1_Sub1) this).aClass_ra_Sub1_9052 = class_ra_sub1;
    }

    public boolean method560() {
	try {
	    return true;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aeu.h(").append(')').toString());
	}
    }

    public void method558(Interface8_Impl1_Impl2 interface8_impl1_impl2) {
	try {
	    Class12 class12 = (Class12) interface8_impl1_impl2;
	    if (((Class52_Sub1_Sub1) this).aClass24_9054 != null && class12 != null && ((((Class12) class12).anInt9943 * 1026825677 != (((Class24) ((Class52_Sub1_Sub1) this).aClass24_9054).anInt9947) * 215983317) || ((((Class24) ((Class52_Sub1_Sub1) this).aClass24_9054).anInt9948) * 467687639 != 1671547161 * ((Class12) class12).anInt9944)))
		throw new RuntimeException();
	    ((Class52_Sub1_Sub1) this).aClass12_9053 = class12;
	    if (class12 != null) {
		((Class52_Sub1_Sub1) this).anInt9056 = ((Class12) class12).anInt9943 * 1931039079;
		((Class52_Sub1_Sub1) this).anInt9055 = ((Class12) class12).anInt9944 * 1986423081;
	    } else if (null == ((Class52_Sub1_Sub1) this).aClass24_9054) {
		((Class52_Sub1_Sub1) this).anInt9056 = 0;
		((Class52_Sub1_Sub1) this).anInt9055 = 0;
	    }
	    if (this == ((Class52_Sub1_Sub1) this).aClass_ra_Sub1_9052.method4992((short) -7778))
		method136();
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aeu.n(").append(')').toString());
	}
    }

    public int method552() {
	try {
	    return -1236783503 * ((Class52_Sub1_Sub1) this).anInt9055;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aeu.f(").append(')').toString());
	}
    }

    public void method135() {
	try {
	    /* empty */
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aeu.b(").append(')').toString());
	}
    }

    public int method544() {
	return -1236783503 * ((Class52_Sub1_Sub1) this).anInt9055;
    }

    public void method561(int i, Interface8_Impl1_Impl1 interface8_impl1_impl1) {
	Class24 class24 = (Class24) interface8_impl1_impl1;
	if (null != ((Class52_Sub1_Sub1) this).aClass12_9053 && class24 != null && ((((Class24) class24).anInt9947 * 215983317 != (((Class12) ((Class52_Sub1_Sub1) this).aClass12_9053).anInt9943) * 1026825677) || (1671547161 * ((Class12) (((Class52_Sub1_Sub1) this).aClass12_9053)).anInt9944 != 467687639 * ((Class24) class24).anInt9948)))
	    throw new RuntimeException();
	((Class52_Sub1_Sub1) this).aClass24_9054 = class24;
	if (null != class24) {
	    ((Class52_Sub1_Sub1) this).anInt9056 = 1103799935 * ((Class24) class24).anInt9947;
	    ((Class52_Sub1_Sub1) this).anInt9055 = ((Class24) class24).anInt9948 * 1322627015;
	} else if (((Class52_Sub1_Sub1) this).aClass12_9053 == null) {
	    ((Class52_Sub1_Sub1) this).anInt9056 = 0;
	    ((Class52_Sub1_Sub1) this).anInt9055 = 0;
	}
	if (this == ((Class52_Sub1_Sub1) this).aClass_ra_Sub1_9052.method4992((short) 22848))
	    method136();
    }

    public void method562(int i, Interface8_Impl1_Impl1 interface8_impl1_impl1) {
	Class24 class24 = (Class24) interface8_impl1_impl1;
	if (null != ((Class52_Sub1_Sub1) this).aClass12_9053 && class24 != null && ((((Class24) class24).anInt9947 * 215983317 != (((Class12) ((Class52_Sub1_Sub1) this).aClass12_9053).anInt9943) * 1026825677) || (1671547161 * ((Class12) (((Class52_Sub1_Sub1) this).aClass12_9053)).anInt9944 != 467687639 * ((Class24) class24).anInt9948)))
	    throw new RuntimeException();
	((Class52_Sub1_Sub1) this).aClass24_9054 = class24;
	if (null != class24) {
	    ((Class52_Sub1_Sub1) this).anInt9056 = 1103799935 * ((Class24) class24).anInt9947;
	    ((Class52_Sub1_Sub1) this).anInt9055 = ((Class24) class24).anInt9948 * 1322627015;
	} else if (((Class52_Sub1_Sub1) this).aClass12_9053 == null) {
	    ((Class52_Sub1_Sub1) this).anInt9056 = 0;
	    ((Class52_Sub1_Sub1) this).anInt9055 = 0;
	}
	if (this == ((Class52_Sub1_Sub1) this).aClass_ra_Sub1_9052.method4992((short) 5099))
	    method136();
    }

    public void method564(Interface8_Impl1_Impl2 interface8_impl1_impl2) {
	Class12 class12 = (Class12) interface8_impl1_impl2;
	if (((Class52_Sub1_Sub1) this).aClass24_9054 != null && class12 != null && ((((Class12) class12).anInt9943 * 1026825677 != (((Class24) ((Class52_Sub1_Sub1) this).aClass24_9054).anInt9947) * 215983317) || ((((Class24) ((Class52_Sub1_Sub1) this).aClass24_9054).anInt9948) * 467687639 != 1671547161 * ((Class12) class12).anInt9944)))
	    throw new RuntimeException();
	((Class52_Sub1_Sub1) this).aClass12_9053 = class12;
	if (class12 != null) {
	    ((Class52_Sub1_Sub1) this).anInt9056 = ((Class12) class12).anInt9943 * 1931039079;
	    ((Class52_Sub1_Sub1) this).anInt9055 = ((Class12) class12).anInt9944 * 1986423081;
	} else if (null == ((Class52_Sub1_Sub1) this).aClass24_9054) {
	    ((Class52_Sub1_Sub1) this).anInt9056 = 0;
	    ((Class52_Sub1_Sub1) this).anInt9055 = 0;
	}
	if (this == ((Class52_Sub1_Sub1) this).aClass_ra_Sub1_9052.method4992((short) -335))
	    method136();
    }

    public boolean method557() {
	return true;
    }

    public boolean method559() {
	return true;
    }

    public boolean method565() {
	return true;
    }

    boolean method134() {
	((Class52_Sub1_Sub1) this).aClass_ra_Sub1_9052.method5207(494047915 * ((Class52_Sub1_Sub1) this).anInt9056, -1236783503 * ((Class52_Sub1_Sub1) this).anInt9055, (((Class52_Sub1_Sub1) this).aClass24_9054 == null ? null : (((Class24) ((Class52_Sub1_Sub1) this).aClass24_9054).anIntArray9949)), (((Class52_Sub1_Sub1) this).aClass12_9053 == null ? null : (((Class12) ((Class52_Sub1_Sub1) this).aClass12_9053).aFloatArray9945)));
	return true;
    }

    boolean method136() {
	try {
	    ((Class52_Sub1_Sub1) this).aClass_ra_Sub1_9052.method5207(494047915 * ((Class52_Sub1_Sub1) this).anInt9056, -1236783503 * ((Class52_Sub1_Sub1) this).anInt9055, (((Class52_Sub1_Sub1) this).aClass24_9054 == null ? null : (((Class24) ((Class52_Sub1_Sub1) this).aClass24_9054).anIntArray9949)), (((Class52_Sub1_Sub1) this).aClass12_9053 == null ? null : (((Class12) ((Class52_Sub1_Sub1) this).aClass12_9053).aFloatArray9945)));
	    return true;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aeu.p(").append(')').toString());
	}
    }

    public void method137() {
	/* empty */
    }

    public void method138() {
	/* empty */
    }

    boolean method546() {
	try {
	    return true;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aeu.i(").append(')').toString());
	}
    }

    public int method550() {
	return ((Class52_Sub1_Sub1) this).anInt9056 * 494047915;
    }

    public int method551() {
	return ((Class52_Sub1_Sub1) this).anInt9056 * 494047915;
    }

    boolean method548() {
	return true;
    }

    static final void method568(IComponentDefinition class105, Class119 class119, Class403 class403, byte i) {
	try {
	    class105.aBoolean1196 = (((Class403) class403).anIntArray5244[(((Class403) class403).anInt5239 -= -391880689) * 681479919]) == 1;
	    Tradution.method6054(class105, -1121165811);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aeu.dz(").append(')').toString());
	}
    }
}
