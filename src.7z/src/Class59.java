/* Class59 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.Canvas;

public class Class59 {
    public static Toolkit method696(Canvas canvas, Interface_ma interface_ma, int i) {
	return new GLToolkit(canvas, interface_ma, i);
    }

    Class59() throws Throwable {
	throw new Error();
    }
}
