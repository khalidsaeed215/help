/* Class63 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class63 {
    Class63() throws Throwable {
	throw new Error();
    }

    static final void method733(Class403 class403, int i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class422_Sub11.method5668(class105, class119, class403, 540861135);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("co.me(").append(')').toString());
	}
    }

    static final void method734(Class403 class403, byte i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class298_Sub14.method2907(class105, class119, class403, 39715579);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("co.oe(").append(')').toString());
	}
    }

    static final void method735(Class403 class403, int i) {
	try {
	    int i_0_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    ((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393 - 1)] = ((Class403) class403).aClass162_5252.membersDisplayNames[i_0_];
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("co.xk(").append(')').toString());
	}
    }

    static final void method736(Class403 class403, int i) {
	try {
	    String string;
	    if (Class287.myPlayer != null && null != (Class287.myPlayer.aString10200))
		string = Class287.myPlayer.method4470(true, -1868785236);
	    else
		string = "";
	    ((Class403) class403).anObjectArray5240[((((Class403) class403).anInt5241 += 969361751) * -203050393 - 1)] = string;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("co.aca(").append(')').toString());
	}
    }

    static final void method737(Class403 class403, byte i) {
	try {
	    int i_1_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = (int) (Class411.method5574(i_1_, 251900723) / 60000L);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("co.ake(").append(')').toString());
	}
    }

    static void method738(int i, int i_2_, int i_3_) {
	try {
	    if (-1909773881 * Class436.anInt5476 == 1)
		Class401.method4939(Class411.aClass298_Sub37_Sub15_5324, i, i_2_, (short) 916);
	    else if (2 == Class436.anInt5476 * -1909773881)
		Class110.method1226(i, i_2_, (byte) 20);
	    Class436.anInt5476 = 0;
	    Class411.aClass298_Sub37_Sub15_5324 = null;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("co.u(").append(')').toString());
	}
    }

    public static void method739(int i) {
	try {
	    if (Class360.anInt3896 * -707576455 == 100)
		Class360.anInt3896 = 928688093;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("co.d(").append(')').toString());
	}
    }

    static boolean method740(int i) {
	try {
	    return Class436.anInt5506 * -278777595 > 0;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("co.o(").append(')').toString());
	}
    }

    public static void method741(String string, String string_4_, int i) {
	try {
	    if (string.length() <= 320 && Class400.method4931((byte) 36)) {
		EmitterConfig.method957(1405885355);
		Class360.username = string;
		Class360.password = string_4_;
		Class439.method5851(3, 907269288);
	    }
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("co.u(").append(')').toString());
	}
    }

    public static void method742(Class298_Sub37 class298_sub37, Class298_Sub37 class298_sub37_5_, byte i) {
	try {
	    if (null != class298_sub37.aClass298_Sub37_7404)
		class298_sub37.method3402(-1977881593);
	    class298_sub37.aClass298_Sub37_7404 = class298_sub37_5_.aClass298_Sub37_7404;
	    class298_sub37.aClass298_Sub37_7405 = class298_sub37_5_;
	    class298_sub37.aClass298_Sub37_7404.aClass298_Sub37_7405 = class298_sub37;
	    class298_sub37.aClass298_Sub37_7405.aClass298_Sub37_7404 = class298_sub37;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("co.b(").append(')').toString());
	}
    }
}
