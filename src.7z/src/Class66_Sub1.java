/* Class66_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public abstract class Class66_Sub1 extends Class66 {
    Class66_Sub1() {
	/* empty */
    }

    abstract Class30_Sub1 method769();

    abstract Class30_Sub1 method770();
}
