/* Class72 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import jaggl.OpenGL;

public class Class72 implements Interface8_Impl1_Impl1_Impl2 {
    int anInt10164;
    Class30_Sub2 aClass30_Sub2_10165;

    public void u() {
	/* empty */
    }

    public int a() {
	return ((Class30_Sub2) ((Class72) this).aClass30_Sub2_10165).anInt6746;
    }

    public int f() {
	return ((Class30_Sub2) ((Class72) this).aClass30_Sub2_10165).anInt6747;
    }

    public void method3(int i) {
	OpenGL.glFramebufferTexture2DEXT(36160, i, ((Class30_Sub2) ((Class72) this).aClass30_Sub2_10165).anInt372, ((Class30_Sub2) ((Class72) this).aClass30_Sub2_10165).anInt376, ((Class72) this).anInt10164);
    }

    public void b() {
	/* empty */
    }

    public int p() {
	return ((Class30_Sub2) ((Class72) this).aClass30_Sub2_10165).anInt6746;
    }

    public int i() {
	return ((Class30_Sub2) ((Class72) this).aClass30_Sub2_10165).anInt6746;
    }

    public int k() {
	return ((Class30_Sub2) ((Class72) this).aClass30_Sub2_10165).anInt6747;
    }

    public void d() {
	/* empty */
    }

    public void x() {
	/* empty */
    }

    public void method2(int i) {
	OpenGL.glFramebufferTexture2DEXT(36160, i, ((Class30_Sub2) ((Class72) this).aClass30_Sub2_10165).anInt372, ((Class30_Sub2) ((Class72) this).aClass30_Sub2_10165).anInt376, ((Class72) this).anInt10164);
    }

    public void method1(int i) {
	OpenGL.glFramebufferTexture2DEXT(36160, i, ((Class30_Sub2) ((Class72) this).aClass30_Sub2_10165).anInt372, ((Class30_Sub2) ((Class72) this).aClass30_Sub2_10165).anInt376, ((Class72) this).anInt10164);
    }

    Class72(Class30_Sub2 class30_sub2, int i) {
	((Class72) this).anInt10164 = i;
	((Class72) this).aClass30_Sub2_10165 = class30_sub2;
    }

    public void method4(int i) {
	OpenGL.glFramebufferTexture2DEXT(36160, i, ((Class30_Sub2) ((Class72) this).aClass30_Sub2_10165).anInt372, ((Class30_Sub2) ((Class72) this).aClass30_Sub2_10165).anInt376, ((Class72) this).anInt10164);
    }
}
