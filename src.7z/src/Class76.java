/* Class76 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class76 {
    public int[] anIntArray709;
    public int[] anIntArray710;
    public float[][] aFloatArrayArray711;
    Model aClass387_712;
    public int[] anIntArray713;

    Class76(Model class387, int[] is, int[] is_0_, int[] is_1_, float[][] fs) {
	super();
	((Class76) this).aClass387_712 = class387;
	anIntArray713 = is;
	anIntArray710 = is_0_;
	anIntArray709 = is_1_;
	aFloatArrayArray711 = fs;
    }
}
