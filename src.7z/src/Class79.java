/* Class79 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Class79 {
	static int anInt734 = 0;
	static JS5 aClass243_735;
	static JS5 aClass243_736;
	static Class298_Sub19_Sub1 aClass298_Sub19_Sub1_737;
	static Class284 aClass284_738;
	static int anInt739;
	static int anInt740 = 1;
	static int anInt741 = 2;
	static int anInt742 = 3;
	static int anInt743 = 0;
	static JS5 aClass243_744;
	static int anInt745;
	static int anInt746;
	static JS5 aClass243_747;
	static Class298_Sub19_Sub1 aClass298_Sub19_Sub1_748;

	Class79() throws Throwable {
		throw new Error();
	}

	public static String method847(long l, int i, int i_0_) {
		try {
			Class422_Sub9.method5658(l);
			int i_1_ = Class490.aCalendar6073.get(5);
			int i_2_ = Class490.aCalendar6073.get(2);
			int i_3_ = Class490.aCalendar6073.get(1);
			if (3 == i)
				return Class357.method4275(l, i, (short) -6140);
			return new StringBuilder().append(Integer.toString(i_1_ / 10)).append(i_1_ % 10).append("-").append(Class490.aStringArrayArray6074[i][i_2_]).append("-").append(i_3_).toString();
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("de.a(").append(')').toString());
		}
	}

	static byte method848(int i, int i_4_, byte i_5_) {
		try {
			if (-1976050083 * GameObjectType.T9.type != i)
				return (byte) 0;
			if ((i_4_ & 0x1) == 0)
				return (byte) 1;
			return (byte) 2;
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("de.by(").append(')').toString());
		}
	}

	static final void method849(IComponentDefinition class105, Class119 class119, Class403 class403, int i) {
		try {
			class105.anInt1235 = (((Class403) class403).anIntArray5244[(((Class403) class403).anInt5239 -= -391880689) * 681479919]) * -978869921;
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("de.jm(").append(')').toString());
		}
	}


	static final void method851(IComponentDefinition class105, Class119 class119, Class403 class403, int i) {
		try {
			class403.anInt5239 -= -1567522756;
			class105.anInt1278 = 730470451 * class403.anIntArray5244[class403.anInt5239 * 681479919];
			class105.anInt1207 = class403.anIntArray5244[1 + class403.anInt5239 * 681479919] * 792598437;
			class105.anInt1208 = 1652793977 * class403.anIntArray5244[2 + 681479919 * class403.anInt5239];
			class105.anInt1197 = class403.anIntArray5244[681479919 * class403.anInt5239 + 3] * 1502440771;
			Tradution.method6054(class105, -540239013);
		}
		catch (RuntimeException var5) {
			throw Class346.method4175(var5, "de.ex(" + ')');
		}
	}

	public static final void method850(Class365_Sub1 class365_sub1, int i, byte i_6_) {
		try {
			Class82_Sub21.method936(class365_sub1, i, true, 229741614);
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("de.jj(").append(')').toString());
		}
	}
}
