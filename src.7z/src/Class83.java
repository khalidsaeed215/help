/* Class83 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public final class Class83 {
    static long aLong762;
    static long aLong763;
    static IComponentDefinition[] aClass105Array764;
    static String aString765;

    Class83() throws Throwable {
	throw new Error();
    }

    static final void method942(Class403 class403, byte i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class257.method2451(class105, class119, class403, -1057885619);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("dj.on(").append(')').toString());
	}
    }

    static final void method943(Class403 class403, int i) {
	try {
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = ((Class403) class403).aClass162_5252.clanLeaderID * -2079715533;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("dj.xz(").append(')').toString());
	}
    }

    public static void method944(int i, int i_0_) {
	try {
	    Class301_Sub1.anInt7633 = -2138103821;
	    Class301_Sub1.anInt7630 = i * 1998014133;
	    Class137_Sub1.anInt6991 = -189172599;
	    Class88.anInt810 = -338630500;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("dj.cg(").append(')').toString());
	}
    }
}
