/* Class_v_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import jaclib.memory.heap.NativeHeap;

public class Class_v_Sub2 extends Class_v {
    NativeHeap aNativeHeap9784;

    void method3675() {
	((Class_v_Sub2) this).aNativeHeap9784.b();
    }

    Class_v_Sub2(int i) {
	((Class_v_Sub2) this).aNativeHeap9784 = new NativeHeap(i);
    }
}
