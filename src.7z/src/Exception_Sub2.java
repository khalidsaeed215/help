/* Exception_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Exception_Sub2 extends Exception {
    public Exception_Sub2(String string) {
	super(string);
    }

    public static int method274(byte i) {
	try {
	    return Class118.anInt1401 * 332512427;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aet.s(").append(')').toString());
	}
    }
}
