/* Exception_Sub2_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Exception_Sub2_Sub1 extends Exception_Sub2 {
    Exception_Sub2_Sub1(String string, boolean bool) {
	super(string);
    }

    Exception_Sub2_Sub1(String string) {
	this(string, false);
    }
}
