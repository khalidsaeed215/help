/* Exception_Sub2_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Exception_Sub2_Sub2 extends Exception_Sub2 {
    Exception_Sub2_Sub2(String string) {
	super(string);
    }
}
