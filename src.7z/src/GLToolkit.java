
/* Class_ra_Sub2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.awt.Canvas;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import jaclib.memory.Buffer;
import jaclib.memory.Stream;
import jaclib.memory.heap.NativeHeap;
import jaggl.OpenGL;

public class GLToolkit extends Toolkit {
	int anInt8007;
	static float aFloat8008 = 0.35F;
	static int anInt8009 = 0;
	int anInt8010;
	static int anInt8011 = 1;
	static int anInt8012 = 4;
	static int anInt8013 = 8;
	static int anInt8014 = 16;
	static int anInt8015 = 32;
	static int anInt8016 = 32993;
	static float[] aFloatArray8017;
	static int anInt8018 = 5123;
	static int anInt8019 = 5126;
	static int anInt8020 = 4;
	static int anInt8021 = 7;
	String aString8022;
	static int anInt8023 = -1;
	int anInt8024;
	static int anInt8025 = 7681;
	int anInt8026;
	boolean aBoolean8027;
	static int anInt8028 = 34023;
	static int anInt8029 = 34165;
	Class233 aClass233_8030;
	boolean aBoolean8031;
	static int anInt8032 = 34479;
	int anInt8033;
	static int anInt8034 = 34166;
	static int anInt8035 = 770;
	static int anInt8036 = 768;
	Interface1 anInterface1_8037;
	boolean aBoolean8038;
	boolean aBoolean8039;
	static int anInt8040 = 0;
	Class233 aClass233_8041;
	static int anInt8042 = 2;
	static int anInt8043 = 3;
	static int anInt8044 = 1;
	static int anInt8045 = 2;
	static int anInt8046 = 34167;
	static int anInt8047 = 8;
	static int anInt8048 = 55;
	static int anInt8049 = 7;
	boolean aBoolean8050;
	int anInt8051;
	Class61 aClass61_8052;
	static int anInt8053 = 8448;
	Class27 aClass27_8054;
	Class42 aClass42_8055;
	Class298_Sub8_Sub1 aClass298_Sub8_Sub1_8056;
	Class34 aClass34_8057;
	Class233 aClass233_8058;
	int anInt8059;
	Class222 aClass222_8060;
	Class49 aClass49_8061;
	int anInt8062;
	int anInt8063;
	int anInt8064;
	boolean aBoolean8065;
	int anInt8066;
	Class458 aClass458_8067;
	Class458 deleteFrameBuffers;
	Class233 aClass233_8069;
	int anInt8070;
	Class458 deleteLists;
	static int anInt8072 = 0;
	Class458 deleteTextureIds;
	static int anInt8074 = 4;
	Class458 deleteRenderBuffers;
	Class458 deletePrograms;
	float[][] aFloatArrayArray8077;
	long aLong8078;
	static int[] anIntArray8079 = new int[1000];
	int anInt8080;
	int anInt8081;
	int anInt8082;
	boolean aBoolean8083;
	OpenGLModel[] aClass387_Sub2Array8084;
	static int anInt8085 = 34168;
	boolean aBoolean8086;
	Class222 aClass222_8087;
	static int anInt8088 = 1;
	Class233 aClass233_8089;
	boolean aBoolean8090;
	Class233 aClass233_8091;
	OpenGlArrayBufferPointer aClass32_8092;
	boolean fragment_shader;
	float[] aFloatArray8094;
	float aFloat8095;
	float aFloat8096;
	float aFloat8097;
	float aFloat8098;
	float aFloat8099;
	float aFloat8100;
	int anInt8101;
	float aFloat8102;
	Class222 aClass222_8103;
	Class233 aClass233_8104;
	static int anInt8105 = -2;
	float[] aFloatArray8106;
	int anInt8107;
	boolean aBoolean8108;
	int anInt8109;
	Class233 aClass233_8110;
	Class30_Sub2_Sub1 aClass30_Sub2_Sub1_8111;
	int anInt8112;
	int anInt8113;
	int anInt8114;
	int anInt8115;
	OpenGL anOpenGL8116;
	int anInt8117;
	int anInt8118 = 128;
	static int anInt8119 = 4;
	static int anInt8120 = 128;
	boolean aBoolean8121;
	float[] aFloatArray8122;
	float[] aFloatArray8123;
	float[] aFloatArray8124;
	float aFloat8125;
	boolean aBoolean8126;
	int anInt8127;
	float aFloat8128;
	static int anInt8129 = 5121;
	float aFloat8130;
	float aFloat8131;
	float aFloat8132;
	boolean texture_float;
	float aFloat8134;
	int anInt8135;
	int anInt8136;
	boolean aBoolean8137;
	boolean aBoolean8138;
	int anInt8139;
	Class30_Sub2 aClass30_Sub2_8140;
	static int anInt8141 = 1;
	float aFloat8142;
	boolean aBoolean8143;
	float aFloat8144;
	float aFloat8145;
	boolean aBoolean8146;
	boolean aBoolean8147;
	Class52_Sub1_Sub2 aClass52_Sub1_Sub2_8148;
	Class78 aClass78_8149;
	Interface2 anInterface2_8150;
	Interface1 anInterface1_8151;
	int anInt8152;
	Class458 deleteBufferIds;
	static int anInt8154 = 5890;
	int anInt8155;
	int anInt8156;
	float[] aFloatArray8157;
	static int anInt8158 = 260;
	Class66_Sub1 aClass66_Sub1_8159;
	float aFloat8160;
	Class458 deleteShaders;
	String aString8162;
	static float[] aFloatArray8163 = new float[4];
	Class298_Sub10[] aClass298_Sub10Array8164;
	int anInt8165;
	boolean aBoolean8166;
	static int anInt8167 = 2;
	int anInt8168;
	int anInt8169;
	boolean framebuffer_obj;
	boolean aBoolean8171;
	boolean aBoolean8172;
	boolean aBoolean8173;
	boolean aBoolean8174;
	int anInt8175;
	boolean aBoolean8176;
	boolean tex3d;
	boolean aBoolean8178;
	boolean aBoolean8179;
	int anInt8180;
	NativeHeap aNativeHeap8181;
	Class30[] aClass30Array8182;
	boolean vertex_shader;
	Class233 aClass233_8184;
	boolean aBoolean8185;
	int anInt8186;
	float aFloat8187;
	float aFloat8188;
	OpenGLModel[] aClass387_Sub2Array8189;
	static int anInt8190 = 2;
	float aFloat8191;
	static int anInt8192 = 100663296;
	OpenGlArrayBufferPointer aClass32_8193;
	int anInt8194;
	int anInt8195;
	int anInt8196;
	RsFloatBuffer aClass298_Sub53_Sub1_8197;
	int[] anIntArray8198;
	int[] anIntArray8199;
	int[] anIntArray8200;
	byte[] aByteArray8201;

	public Sprite method5030(int[] is, int i, int i_0_, int i_1_, int i_2_, boolean bool) {
		return new Class57_Sub3(this, i_1_, i_2_, is, i, i_0_);
	}

	void method5220() {
		int i = 0;
		while (!((GLToolkit) this).anOpenGL8116.f()) {
			if (i++ > 5)
				throw new RuntimeException("");
			IPAddress.method6060(1000L);
		}
	}

	int method5221() {
		int i = 0;
		((GLToolkit) this).aString8022 = OpenGL.glGetString(7936).toLowerCase();
		((GLToolkit) this).aString8162 = OpenGL.glGetString(7937).toLowerCase();
		// System.err.println("GLSTR1:" + aString8022 + "," + "GLSTR2:" +
		// aString8162);
		if (((GLToolkit) this).aString8022.indexOf("microsoft") != -1)
			i |= 0x1;
		if (((GLToolkit) this).aString8022.indexOf("brian paul") != -1
				|| ((GLToolkit) this).aString8022.indexOf("mesa") != -1)
			i |= 0x1;
		String string = OpenGL.glGetString(7938);
		String[] strings = Class365_Sub1_Sub3_Sub1.method4508(string.replace('.', ' '), ' ', 1456146944);
		if (strings.length >= 2) {
			try {
				int i_3_ = Class216.method1998(strings[0], (short) -12183);
				int i_4_ = Class216.method1998(strings[1], (short) -18117);
				((GLToolkit) this).anInt8101 = i_3_ * 10 + i_4_;
			} catch (NumberFormatException numberformatexception) {
				i |= 0x4;
			}
		} else
			i |= 0x4;
		if (((GLToolkit) this).anInt8101 < 12)
			i |= 0x2;
		if (!((GLToolkit) this).anOpenGL8116.a("GL_ARB_multitexture"))
			i |= 0x8;
		if (!((GLToolkit) this).anOpenGL8116.a("GL_ARB_texture_env_combine"))
			i |= 0x20;
		int[] is = new int[1];
		OpenGL.glGetIntegerv(34018, is, 0);
		((GLToolkit) this).anInt8165 = is[0];
		OpenGL.glGetIntegerv(34929, is, 0);
		((GLToolkit) this).anInt8168 = is[0];
		OpenGL.glGetIntegerv(34930, is, 0);
		((GLToolkit) this).anInt8169 = is[0];
		if (((GLToolkit) this).anInt8165 < 2 || ((GLToolkit) this).anInt8168 < 2 || ((GLToolkit) this).anInt8169 < 2)
			i |= 0x10;
		((GLToolkit) this).aBoolean8143 = Stream.r();
		((GLToolkit) this).aBoolean8126 = ((GLToolkit) this).anOpenGL8116.a("GL_ARB_vertex_buffer_object");
		((GLToolkit) this).aBoolean8173 = ((GLToolkit) this).anOpenGL8116.a("GL_ARB_multisample");
		((GLToolkit) this).aBoolean8039 = ((GLToolkit) this).anOpenGL8116.a("GL_ARB_vertex_program");
		((GLToolkit) this).anOpenGL8116.a("GL_ARB_fragment_program");
		((GLToolkit) this).vertex_shader = ((GLToolkit) this).anOpenGL8116.a("GL_ARB_vertex_shader");
		((GLToolkit) this).fragment_shader = ((GLToolkit) this).anOpenGL8116.a("GL_ARB_fragment_shader");
		((GLToolkit) this).tex3d = ((GLToolkit) this).anOpenGL8116.a("GL_EXT_texture3D");
		((GLToolkit) this).aBoolean8179 = ((GLToolkit) this).anOpenGL8116.a("GL_ARB_texture_rectangle");
		((GLToolkit) this).aBoolean8178 = ((GLToolkit) this).anOpenGL8116.a("GL_ARB_texture_cube_map");
		((GLToolkit) this).texture_float = ((GLToolkit) this).anOpenGL8116.a("GL_ARB_texture_float");
		((GLToolkit) this).aBoolean8031 = false;
		((GLToolkit) this).framebuffer_obj = ((GLToolkit) this).anOpenGL8116.a("GL_EXT_framebuffer_object");
		((GLToolkit) this).aBoolean8171 = ((GLToolkit) this).anOpenGL8116.a("GL_EXT_framebuffer_blit");
		((GLToolkit) this).aBoolean8137 = ((GLToolkit) this).anOpenGL8116.a("GL_EXT_framebuffer_multisample");
		((GLToolkit) this).aBoolean8174 = (((GLToolkit) this).aBoolean8171 & ((GLToolkit) this).aBoolean8137);
		((GLToolkit) this).aBoolean8166 = Class495.aString6094.startsWith("mac");
		OpenGL.glGetFloatv(2834, aFloatArray8163, 0);
		((GLToolkit) this).aFloat8188 = aFloatArray8163[0];
		((GLToolkit) this).aFloat8187 = aFloatArray8163[1];
		// System.err.println("vertex_shader:" + vertex_shader + ",
		// fragment_shader:" + fragment_shader + ", framebuffer:" +
		// framebuffer_obj + ", texturefloat:" + texture_float);
		// System.err.println("texture3d:" + tex3d);
		return i != 0 ? i : 0;
	}

	void method5222() {
		((GLToolkit) this).aClass30Array8182 = new Class30[((GLToolkit) this).anInt8165];
		((GLToolkit) this).aClass30_Sub2_8140 = new Class30_Sub2(this, 3553, Class55.aClass55_557, Class77.aClass77_717,
				1, 1);
		new Class30_Sub2(this, 3553, Class55.aClass55_557, Class77.aClass77_717, 1, 1);
		new Class30_Sub2(this, 3553, Class55.aClass55_557, Class77.aClass77_717, 1, 1);
		for (int i = 0; i < 7; i++) {
			((GLToolkit) this).aClass387_Sub2Array8189[i] = new OpenGLModel(this);
			((GLToolkit) this).aClass387_Sub2Array8084[i] = new OpenGLModel(this);
		}
		if (((GLToolkit) this).framebuffer_obj) {
			((GLToolkit) this).aClass52_Sub1_Sub2_8148 = new Class52_Sub1_Sub2(this);
			new Class52_Sub1_Sub2(this);
		}
	}

	public final void m(int i, float f, float f_5_, float f_6_, float f_7_, float f_8_) {
		boolean bool = ((GLToolkit) this).anInt8033 != i;
		if (bool || ((GLToolkit) this).aFloat8131 != f || ((GLToolkit) this).aFloat8132 != f_5_) {
			((GLToolkit) this).anInt8033 = i;
			((GLToolkit) this).aFloat8131 = f;
			((GLToolkit) this).aFloat8132 = f_5_;
			if (bool) {
				((GLToolkit) this).aFloat8125 = ((float) (((GLToolkit) this).anInt8033 & 0xff0000) / 1.671168E7F);
				((GLToolkit) this).aFloat8128 = ((float) (((GLToolkit) this).anInt8033 & 0xff00) / 65280.0F);
				((GLToolkit) this).aFloat8191 = ((float) (((GLToolkit) this).anInt8033 & 0xff) / 255.0F);
				method5239();
			}
			method5230();
		}
		if (((GLToolkit) this).aFloatArray8122[0] != f_6_ || ((GLToolkit) this).aFloatArray8122[1] != f_7_
				|| ((GLToolkit) this).aFloatArray8122[2] != f_8_) {
			((GLToolkit) this).aFloatArray8122[0] = f_6_;
			((GLToolkit) this).aFloatArray8122[1] = f_7_;
			((GLToolkit) this).aFloatArray8122[2] = f_8_;
			((GLToolkit) this).aFloatArray8123[0] = -f_6_;
			((GLToolkit) this).aFloatArray8123[1] = -f_7_;
			((GLToolkit) this).aFloatArray8123[2] = -f_8_;
			float f_9_ = (float) (1.0 / Math.sqrt((double) (f_6_ * f_6_ + f_7_ * f_7_ + f_8_ * f_8_)));
			((GLToolkit) this).aFloatArray8124[0] = f_6_ * f_9_;
			((GLToolkit) this).aFloatArray8124[1] = f_7_ * f_9_;
			((GLToolkit) this).aFloatArray8124[2] = f_8_ * f_9_;
			((GLToolkit) this).aFloatArray8157[0] = -((GLToolkit) this).aFloatArray8124[0];
			((GLToolkit) this).aFloatArray8157[1] = -((GLToolkit) this).aFloatArray8124[1];
			((GLToolkit) this).aFloatArray8157[2] = -((GLToolkit) this).aFloatArray8124[2];
			method5279();
			((GLToolkit) this).anInt8066 = (int) (f_6_ * 256.0F / f_7_);
			((GLToolkit) this).anInt8026 = (int) (f_8_ * 256.0F / f_7_);
		}
	}

	public Class58 method4987() {
		int i = -1;
		if (((GLToolkit) this).aString8022.indexOf("nvidia") != -1)
			i = 4318;
		else if (((GLToolkit) this).aString8022.indexOf("intel") != -1)
			i = 32902;
		else if (((GLToolkit) this).aString8022.indexOf("ati") != -1)
			i = 4098;
		return new Class58(i, "OpenGL", ((GLToolkit) this).anInt8101, ((GLToolkit) this).aString8162, 0L);
	}

	void method4989(int i, int i_10_) throws Exception_Sub1 {
		try {
			aClass52_Sub2_5312.method580();
		} catch (Exception exception) {
			/* empty */
		}
		if (anInterface_ma5299 != null)
			anInterface_ma5299.method176(185441622);
	}

	public void method5075() {
		OpenGL.glFinish();
	}

	void method5023() {
		for (Class298 class298 = ((GLToolkit) this).aClass458_8067.method5967(
				1327944912); class298 != null; class298 = ((GLToolkit) this).aClass458_8067.method5969((byte) -104))
			((Class_v_Sub1) class298).method3674();
		if (((GLToolkit) this).aClass42_8055 != null)
			((GLToolkit) this).aClass42_8055.method486();
		if (((GLToolkit) this).aBoolean8065) {
			Class216.method2000(false, true, (short) -2325);
			((GLToolkit) this).aBoolean8065 = false;
		}
	}

	final void method5223() {
		if (((GLToolkit) this).anInt8107 != 1) {
			((GLToolkit) this).anInt8107 = 1;
			method5240();
			method5231();
			method5276();
			OpenGL.glMatrixMode(5888);
			OpenGL.glLoadIdentity();
			((GLToolkit) this).anInt8080 &= ~0x8;
		}
	}

	public boolean method5074() {
		return true;
	}

	public boolean method4995() {
		return true;
	}

	public boolean method5050() {
		return (((GLToolkit) this).aClass298_Sub8_Sub1_8056 != null
				&& (((GLToolkit) this).anInt8051 <= 1 || ((GLToolkit) this).aBoolean8174));
	}

	public boolean method4996() {
		return true;
	}

	public boolean method5082() {
		return true;
	}

	public boolean method5159() {
		return true;
	}

	boolean method5224() {
		return ((GLToolkit) this).aClass27_8054.method400(3);
	}

	public boolean method4998() {
		return true;
	}

	public boolean method5051() {
		return false;
	}

	public void method5047(boolean bool) {
		/* empty */
	}

	void method5225() {
		method5257();
	}

	public void method5091(int i, int i_11_, int i_12_, int i_13_, int i_14_, int i_15_) {
		method5250();
		method5266(i_15_);
		float f = (float) i_12_ - (float) i;
		float f_16_ = (float) i_13_ - (float) i_11_;
		if (f == 0.0F && f_16_ == 0.0F)
			f = 1.0F;
		else {
			float f_17_ = (float) (1.0 / Math.sqrt((double) (f * f + f_16_ * f_16_)));
			f *= f_17_;
			f_16_ *= f_17_;
		}
		OpenGL.glColor4ub((byte) (i_14_ >> 16), (byte) (i_14_ >> 8), (byte) i_14_, (byte) (i_14_ >> 24));
		OpenGL.glBegin(1);
		OpenGL.glVertex2f((float) i + 0.35F, (float) i_11_ + 0.35F);
		OpenGL.glVertex2f((float) i_12_ + f + 0.35F, (float) i_13_ + f_16_ + 0.35F);
		OpenGL.glEnd();
	}

	public int[] aq(int i, int i_18_, int i_19_, int i_20_) {
		if (aClass52_5292 != null) {
			int[] is = new int[i_19_ * i_20_];
			int i_21_ = aClass52_5292.method552();
			for (int i_22_ = 0; i_22_ < i_20_; i_22_++)
				OpenGL.glReadPixelsi(i, i_21_ - i_18_ - i_22_ - 1, i_19_, 1, 32993, ((GLToolkit) this).anInt8186, is,
						i_22_ * i_19_);
			return is;
		}
		return null;
	}

	public void method5176() {
		if (((GLToolkit) this).aBoolean8185 && aClass52_5292 != null) {
			int i = ((GLToolkit) this).anInt8081;
			int i_23_ = ((GLToolkit) this).anInt8024;
			int i_24_ = ((GLToolkit) this).anInt8109;
			int i_25_ = ((GLToolkit) this).anInt8059;
			L();
			int i_26_ = ((GLToolkit) this).anInt8115;
			int i_27_ = ((GLToolkit) this).anInt8194;
			int i_28_ = ((GLToolkit) this).anInt8117;
			int i_29_ = ((GLToolkit) this).anInt8180;
			method5011();
			OpenGL.glReadBuffer(1028);
			OpenGL.glDrawBuffer(1029);
			method5291();
			method5226(false);
			method5262(false);
			method5264(false);
			method5281(false);
			method5256(null);
			method5275(-2);
			method5243(1);
			method5266(0);
			OpenGL.glMatrixMode(5889);
			OpenGL.glLoadIdentity();
			OpenGL.glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);
			OpenGL.glMatrixMode(5888);
			OpenGL.glLoadIdentity();
			OpenGL.glRasterPos2i(0, 0);
			OpenGL.glCopyPixels(0, 0, aClass52_5292.method545(), aClass52_5292.method552(), 6144);
			OpenGL.glFlush();
			OpenGL.glReadBuffer(1029);
			OpenGL.glDrawBuffer(1029);
			r(i, i_24_, i_23_, i_25_);
			method5187(i_26_, i_27_, i_28_, i_29_);
		}
	}

	public void ba(int i, int i_30_) {
		int i_31_ = 0;
		if ((i & 0x1) != 0) {
			OpenGL.glClearColor((float) (i_30_ & 0xff0000) / 1.671168E7F, (float) (i_30_ & 0xff00) / 65280.0F,
					(float) (i_30_ & 0xff) / 255.0F, (float) (i_30_ >>> 24) / 255.0F);
			i_31_ = 16384;
		}
		if ((i & 0x2) != 0) {
			method5281(true);
			i_31_ |= 0x100;
		}
		if ((i & 0x4) != 0)
			i_31_ |= 0x400;
		OpenGL.glClear(i_31_);
	}

	public void method5019(int i, int i_32_, int i_33_, int i_34_, int i_35_, int i_36_) {
		float f = (float) i + 0.35F;
		float f_37_ = (float) i_32_ + 0.35F;
		float f_38_ = f + (float) i_33_ - 1.0F;
		float f_39_ = f_37_ + (float) i_34_ - 1.0F;
		method5250();
		method5266(i_36_);
		OpenGL.glColor4ub((byte) (i_35_ >> 16), (byte) (i_35_ >> 8), (byte) i_35_, (byte) (i_35_ >> 24));
		if (((GLToolkit) this).aBoolean8173)
			OpenGL.glDisable(32925);
		OpenGL.glBegin(2);
		OpenGL.glVertex2f(f, f_37_);
		OpenGL.glVertex2f(f, f_39_);
		OpenGL.glVertex2f(f_38_, f_39_);
		OpenGL.glVertex2f(f_38_, f_37_);
		OpenGL.glEnd();
		if (((GLToolkit) this).aBoolean8173)
			OpenGL.glEnable(32925);
	}

	public void method5020(int i, int i_40_, float f, int i_41_, int i_42_, float f_43_, int i_44_, int i_45_,
			float f_46_, int i_47_, int i_48_, int i_49_, int i_50_) {
		method5250();
		method5266(i_50_);
		OpenGL.glBegin(4);
		OpenGL.glColor4ub((byte) (i_47_ >> 16), (byte) (i_47_ >> 8), (byte) i_47_, (byte) (i_47_ >> 24));
		OpenGL.glVertex3f((float) i + 0.35F, (float) i_40_ + 0.35F, f);
		OpenGL.glColor4ub((byte) (i_48_ >> 16), (byte) (i_48_ >> 8), (byte) i_48_, (byte) (i_48_ >> 24));
		OpenGL.glVertex3f((float) i_41_ + 0.35F, (float) i_42_ + 0.35F, f_43_);
		OpenGL.glColor4ub((byte) (i_49_ >> 16), (byte) (i_49_ >> 8), (byte) i_49_, (byte) (i_49_ >> 24));
		OpenGL.glVertex3f((float) i_44_ + 0.35F, (float) i_45_ + 0.35F, f_46_);
		OpenGL.glEnd();
	}

	public boolean method5111() {
		return true;
	}

	public void fu(int i, int i_51_, int i_52_, int i_53_, int i_54_) {
		method5250();
		method5266(i_54_);
		float f = (float) i + 0.35F;
		float f_55_ = (float) i_51_ + 0.35F;
		OpenGL.glColor4ub((byte) (i_53_ >> 16), (byte) (i_53_ >> 8), (byte) i_53_, (byte) (i_53_ >> 24));
		OpenGL.glBegin(1);
		OpenGL.glVertex2f(f, f_55_);
		OpenGL.glVertex2f(f, f_55_ + (float) i_52_);
		OpenGL.glEnd();
	}

	final void method5226(boolean bool) {
		if (bool != ((GLToolkit) this).aBoolean8138) {
			((GLToolkit) this).aBoolean8138 = bool;
			method5241();
			((GLToolkit) this).anInt8080 &= ~0xf;
		}
	}

	public boolean method5127() {
		return true;
	}

	public void method5022(int i, int i_56_, int i_57_, int i_58_, int i_59_, int i_60_, Class_ta class_ta, int i_61_,
			int i_62_) {
		Class_ta_Sub1 class_ta_sub1 = (Class_ta_Sub1) class_ta;
		Class30_Sub2_Sub1 class30_sub2_sub1 = ((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441;
		method5251();
		method5256(((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441);
		method5266(i_60_);
		method5258(7681, 8448);
		method5259(0, 34167, 768);
		float f = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9049
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9048);
		float f_63_ = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9051
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9047);
		float f_64_ = (float) i_57_ - (float) i;
		float f_65_ = (float) i_58_ - (float) i_56_;
		float f_66_ = (float) (1.0 / Math.sqrt((double) (f_64_ * f_64_ + f_65_ * f_65_)));
		f_64_ *= f_66_;
		f_65_ *= f_66_;
		OpenGL.glColor4ub((byte) (i_59_ >> 16), (byte) (i_59_ >> 8), (byte) i_59_, (byte) (i_59_ >> 24));
		OpenGL.glBegin(1);
		OpenGL.glTexCoord2f(f * (float) (i - i_61_), f_63_ * (float) (i_56_ - i_62_));
		OpenGL.glVertex2f((float) i + 0.35F, (float) i_56_ + 0.35F);
		OpenGL.glTexCoord2f(f * (float) (i_57_ - i_61_), f_63_ * (float) (i_58_ - i_62_));
		OpenGL.glVertex2f((float) i_57_ + f_64_ + 0.35F, (float) i_58_ + f_65_ + 0.35F);
		OpenGL.glEnd();
		method5259(0, 5890, 768);
	}

	public void method5007(int i, int i_67_, int i_68_, int i_69_, int i_70_, int i_71_, Class_ta class_ta, int i_72_,
			int i_73_, int i_74_, int i_75_, int i_76_) {
		if (i != i_68_ || i_67_ != i_69_) {
			Class_ta_Sub1 class_ta_sub1 = (Class_ta_Sub1) class_ta;
			Class30_Sub2_Sub1 class30_sub2_sub1 = ((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441;
			method5251();
			method5256(((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441);
			method5266(i_71_);
			method5258(7681, 8448);
			method5259(0, 34167, 768);
			float f = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9049
					/ (float) (((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9048));
			float f_77_ = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9051
					/ (float) (((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9047));
			float f_78_ = (float) i_68_ - (float) i;
			float f_79_ = (float) i_69_ - (float) i_67_;
			float f_80_ = (float) (1.0 / Math.sqrt((double) (f_78_ * f_78_ + f_79_ * f_79_)));
			f_78_ *= f_80_;
			f_79_ *= f_80_;
			OpenGL.glColor4ub((byte) (i_70_ >> 16), (byte) (i_70_ >> 8), (byte) i_70_, (byte) (i_70_ >> 24));
			i_76_ %= i_75_ + i_74_;
			float f_81_ = f_78_ * (float) i_74_;
			float f_82_ = f_79_ * (float) i_74_;
			float f_83_ = 0.0F;
			float f_84_ = 0.0F;
			float f_85_ = f_81_;
			float f_86_ = f_82_;
			if (i_76_ > i_74_) {
				f_83_ = f_78_ * (float) (i_74_ + i_75_ - i_76_);
				f_84_ = f_79_ * (float) (i_74_ + i_75_ - i_76_);
			} else {
				f_85_ = f_78_ * (float) (i_74_ - i_76_);
				f_86_ = f_79_ * (float) (i_74_ - i_76_);
			}
			float f_87_ = (float) i + 0.35F + f_83_;
			float f_88_ = (float) i_67_ + 0.35F + f_84_;
			float f_89_ = f_78_ * (float) i_75_;
			float f_90_ = f_79_ * (float) i_75_;
			for (;;) {
				if (i_68_ > i) {
					if (f_87_ > (float) i_68_ + 0.35F)
						break;
					if (f_87_ + f_85_ > (float) i_68_)
						f_85_ = (float) i_68_ - f_87_;
				} else {
					if (f_87_ < (float) i_68_ + 0.35F)
						break;
					if (f_87_ + f_85_ < (float) i_68_)
						f_85_ = (float) i_68_ - f_87_;
				}
				if (i_69_ > i_67_) {
					if (f_88_ > (float) i_69_ + 0.35F)
						break;
					if (f_88_ + f_86_ > (float) i_69_)
						f_86_ = (float) i_69_ - f_88_;
				} else {
					if (f_88_ < (float) i_69_ + 0.35F)
						break;
					if (f_88_ + f_86_ < (float) i_69_)
						f_86_ = (float) i_69_ - f_88_;
				}
				OpenGL.glBegin(1);
				OpenGL.glTexCoord2f(f * (f_87_ - (float) i_72_), f_77_ * (f_88_ - (float) i_73_));
				OpenGL.glVertex2f(f_87_, f_88_);
				OpenGL.glTexCoord2f(f * (f_87_ + f_85_ - (float) i_72_), f_77_ * (f_88_ + f_86_ - (float) i_73_));
				OpenGL.glVertex2f(f_87_ + f_85_, f_88_ + f_86_);
				OpenGL.glEnd();
				f_87_ += f_89_ + f_85_;
				f_88_ += f_90_ + f_86_;
				f_85_ = f_81_;
				f_86_ = f_82_;
			}
			method5259(0, 5890, 768);
		}
	}

	public void method5059(float f, float f_91_, float f_92_, float[] fs) {
		float f_93_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[14]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[2] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[6] * f_91_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[10] * f_92_));
		float f_94_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * f_91_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * f_92_));
		if (f_93_ < -f_94_ || f_93_ > f_94_) {
			float[] fs_95_ = fs;
			float[] fs_96_ = fs;
			fs[2] = Float.NaN;
			fs_96_[1] = Float.NaN;
			fs_95_[0] = Float.NaN;
		} else {
			float f_97_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
					+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * f)
					+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * f_91_)
					+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * f_92_));
			if (f_97_ < -f_94_ || f_97_ > f_94_) {
				float[] fs_98_ = fs;
				float[] fs_99_ = fs;
				fs[2] = Float.NaN;
				fs_99_[1] = Float.NaN;
				fs_98_[0] = Float.NaN;
			} else {
				float f_100_ = ((((GLToolkit) this).aClass233_8069.aFloatArray2594[13])
						+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[1]) * f
						+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5]) * f_91_
						+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9]) * f_92_);
				if (f_100_ < -f_94_ || f_100_ > f_94_) {
					float[] fs_101_ = fs;
					float[] fs_102_ = fs;
					fs[2] = Float.NaN;
					fs_102_[1] = Float.NaN;
					fs_101_[0] = Float.NaN;
				} else {
					float f_103_ = ((((GLToolkit) this).aClass233_8110.aFloatArray2594[14])
							+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[2]) * f
							+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[6]) * f_91_
							+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[10]) * f_92_);
					fs[0] = (((GLToolkit) this).aFloat8095 + (((GLToolkit) this).aFloat8096 * f_97_ / f_94_));
					fs[1] = (((GLToolkit) this).aFloat8097 + (((GLToolkit) this).aFloat8098 * f_100_ / f_94_));
					fs[2] = f_103_;
				}
			}
		}
	}

	public int method5025(int i, int i_104_, int i_105_, int i_106_, int i_107_, int i_108_) {
		int i_109_ = 0;
		float f = (((GLToolkit) this).aClass233_8069.aFloatArray2594[14]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[2] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[6] * (float) i_104_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[10] * (float) i_105_));
		float f_110_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[14]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[2] * (float) i_106_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[6] * (float) i_107_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[10] * (float) i_108_));
		float f_111_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * (float) i_104_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * (float) i_105_));
		float f_112_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * (float) i_106_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * (float) i_107_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * (float) i_108_));
		if (f < -f_111_ && f_110_ < -f_112_)
			i_109_ |= 0x10;
		else if (f > f_111_ && f_110_ > f_112_)
			i_109_ |= 0x20;
		float f_113_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * (float) i_104_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * (float) i_105_));
		float f_114_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * (float) i_106_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * (float) i_107_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * (float) i_108_));
		if (f_113_ < -f_111_ && f_114_ < -f_112_)
			i_109_ |= 0x1;
		if (f_113_ > f_111_ && f_114_ > f_112_)
			i_109_ |= 0x2;
		float f_115_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[13]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[1] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5] * (float) i_104_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9] * (float) i_105_));
		float f_116_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[13]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[1] * (float) i_106_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5] * (float) i_107_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9] * (float) i_108_));
		if (f_115_ < -f_111_ && f_116_ < -f_112_)
			i_109_ |= 0x4;
		if (f_115_ > f_111_ && f_116_ > f_112_)
			i_109_ |= 0x8;
		return i_109_;
	}

	public Class_v method5026(int i) {
		Class_v_Sub1 class_v_sub1 = new Class_v_Sub1(i);
		((GLToolkit) this).aClass458_8067.method5968(class_v_sub1, 812002958);
		return class_v_sub1;
	}

	public void method5027(Class_v class_v) {
		((GLToolkit) this).aNativeHeap8181 = ((Class_v_Sub1) (Class_v_Sub1) class_v).aNativeHeap9783;
		if (((GLToolkit) this).anInterface1_8037 == null) {
			RsFloatBuffer class298_sub53_sub1 = new RsFloatBuffer(80);
			if (((GLToolkit) this).aBoolean8143) {
				class298_sub53_sub1.method3658(-1.0F);
				class298_sub53_sub1.method3658(-1.0F);
				class298_sub53_sub1.method3658(0.0F);
				class298_sub53_sub1.method3658(0.0F);
				class298_sub53_sub1.method3658(0.0F);
				class298_sub53_sub1.method3658(-1.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(0.0F);
				class298_sub53_sub1.method3658(0.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(0.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(-1.0F);
				class298_sub53_sub1.method3658(0.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(0.0F);
			} else {
				class298_sub53_sub1.method3659(-1.0F);
				class298_sub53_sub1.method3659(-1.0F);
				class298_sub53_sub1.method3659(0.0F);
				class298_sub53_sub1.method3659(0.0F);
				class298_sub53_sub1.method3659(0.0F);
				class298_sub53_sub1.method3659(-1.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(0.0F);
				class298_sub53_sub1.method3659(0.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(0.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(-1.0F);
				class298_sub53_sub1.method3659(0.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(0.0F);
			}
			((GLToolkit) this).anInterface1_8037 = method5244(20, class298_sub53_sub1.buffer,
					class298_sub53_sub1.index * 385051775, false);
			((GLToolkit) this).aClass32_8092 = new OpenGlArrayBufferPointer(((GLToolkit) this).anInterface1_8037, 5126, 3, 0);
			((GLToolkit) this).aClass32_8193 = new OpenGlArrayBufferPointer(((GLToolkit) this).anInterface1_8037, 5126, 2, 12);
			((GLToolkit) this).aClass34_8057.method439(this);
		}
	}

	final void method5227(float[] fs) {
		float[] fs_117_ = new float[16];
		System.arraycopy(fs, 0, fs_117_, 0, 16);
		fs_117_[1] = -fs_117_[1];
		fs_117_[5] = -fs_117_[5];
		fs_117_[9] = -fs_117_[9];
		fs_117_[13] = -fs_117_[13];
		OpenGL.glMatrixMode(5889);
		OpenGL.glLoadMatrixf(fs_117_, 0);
		OpenGL.glMatrixMode(5888);
	}

	public Sprite method5125(IndexedImage class89, boolean bool) {
		int[] is = new int[class89.anInt812 * class89.anInt816];
		int i = 0;
		int i_118_ = 0;
		if (class89.aByteArray819 != null) {
			for (int i_119_ = 0; i_119_ < class89.anInt816; i_119_++) {
				for (int i_120_ = 0; i_120_ < class89.anInt812; i_120_++) {
					is[i_118_++] = (class89.aByteArray819[i] << 24
							| (class89.anIntArray817[class89.aByteArray818[i] & 0xff]));
					i++;
				}
			}
		} else {
			for (int i_121_ = 0; i_121_ < class89.anInt816; i_121_++) {
				for (int i_122_ = 0; i_122_ < class89.anInt812; i_122_++) {
					int i_123_ = (class89.anIntArray817[class89.aByteArray818[i++] & 0xff]);
					is[i_118_++] = i_123_ != 0 ? ~0xffffff | i_123_ : 0;
				}
			}
		}
		Sprite class57 = method5031(is, 0, class89.anInt812, class89.anInt812, class89.anInt816, 435895730);
		class57.method621(class89.anInt815, class89.anInt811, class89.anInt814, class89.anInt813);
		return class57;
	}

	public Sprite method5033(int i, int i_124_, int i_125_, int i_126_, boolean bool) {
		return new Class57_Sub3(this, i, i_124_, i_125_, i_126_);
	}

	static int method5228(Class55 class55) {
		switch (class55.anInt566 * -976336893) {
			case 5:
				return 6407;
			case 2:
				return 6402;
			case 1:
				return 6409;
			case 9:
				return 6408;
			default:
				throw new IllegalStateException();
			case 7:
				return 6406;
			case 3:
				return 6410;
		}
	}

	public Class264 method5092(Class505 class505, IndexedImage[] class89s, boolean bool) {
		return new Class264_Sub3(this, class505, class89s, bool);
	}

	public void method5169(int i) {
		/* empty */
	}

	public Model createModel(ModelDecoder class64, int i, int i_127_, int i_128_, int i_129_) {
		return new OpenGLModel(this, class64, i, i_128_, i_129_, i_127_);
	}

	final synchronized void deleteTex(int i, int i_130_) {
		Class298_Sub35 class298_sub35 = new Class298_Sub35(i_130_);
		class298_sub35.hash = (long) i * 4191220306876042991L;
		((GLToolkit) this).deleteTextureIds.method5968(class298_sub35, 91285961);
	}

	public int mergeFunctionMasks(int i, int i_131_) {
		return i | i_131_;
	}

	public Ground method5122(int i, int i_132_, int[][] is, int[][] is_133_, int i_134_, int i_135_, int i_136_) {
		return new Class_xa_Sub3(this, i_135_, i_136_, i, i_132_, is, is_133_, i_134_);
	}

	public Class233 method5036() {
		return ((GLToolkit) this).aClass233_8058;
	}

	public Class222 method5178() {
		return ((GLToolkit) this).aClass222_8060;
	}

	public void method5021(int i, Class298_Sub10[] class298_sub10s) {
		for (int i_137_ = 0; i_137_ < i; i_137_++)
			((GLToolkit) this).aClass298_Sub10Array8164[i_137_] = class298_sub10s[i_137_];
		((GLToolkit) this).anInt8135 = i;
		if (((GLToolkit) this).anInt8107 != 1)
			method5277();
	}

	public void method5058(int i, Class78 class78) {
		if (!((GLToolkit) this).aBoolean8146)
			throw new RuntimeException("");
		((GLToolkit) this).anInt8155 = i;
		((GLToolkit) this).aClass78_8149 = class78;
		if (((GLToolkit) this).aBoolean8147) {
			((Class27) ((GLToolkit) this).aClass27_8054).aClass47_Sub5_358.method524();
			((Class27) ((GLToolkit) this).aClass27_8054).aClass47_Sub5_358.method523();
		}
	}

	public void O() {
		((GLToolkit) this).aBoolean8146 = false;
	}

	public void method5168(int i, int i_138_, int i_139_, int i_140_, int i_141_, int i_142_, int i_143_) {
		OpenGL.glLineWidth((float) i_142_);
		method5091(i, i_138_, i_139_, i_140_, i_141_, i_143_);
		OpenGL.glLineWidth(1.0F);
	}

	public void method5187(int i, int i_144_, int i_145_, int i_146_) {
		((GLToolkit) this).anInt8115 = i;
		((GLToolkit) this).anInt8194 = i_144_;
		((GLToolkit) this).anInt8117 = i_145_;
		((GLToolkit) this).anInt8180 = i_146_;
		method5231();
	}

	void method5230() {
		aFloatArray8163[0] = (((GLToolkit) this).aFloat8131 * ((GLToolkit) this).aFloat8125);
		aFloatArray8163[1] = (((GLToolkit) this).aFloat8131 * ((GLToolkit) this).aFloat8128);
		aFloatArray8163[2] = (((GLToolkit) this).aFloat8131 * ((GLToolkit) this).aFloat8191);
		aFloatArray8163[3] = 1.0F;
		OpenGL.glLightfv(16384, 4609, aFloatArray8163, 0);
		aFloatArray8163[0] = (-((GLToolkit) this).aFloat8132 * ((GLToolkit) this).aFloat8125);
		aFloatArray8163[1] = (-((GLToolkit) this).aFloat8132 * ((GLToolkit) this).aFloat8128);
		aFloatArray8163[2] = (-((GLToolkit) this).aFloat8132 * ((GLToolkit) this).aFloat8191);
		aFloatArray8163[3] = 1.0F;
		OpenGL.glLightfv(16385, 4609, aFloatArray8163, 0);
	}

	public void fo(int i, int i_147_, int i_148_, int i_149_, int i_150_, int i_151_, byte[] is, int i_152_,
			int i_153_) {
		float f;
		float f_154_;
		if (((GLToolkit) this).aClass30_Sub2_Sub1_8111 == null
				|| (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).anInt6746 < i_148_)
				|| (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).anInt6747 < i_149_)) {
			((GLToolkit) this).aClass30_Sub2_Sub1_8111 = Class30_Sub2_Sub1.method428(this, Class55.aClass55_567,
					Class77.aClass77_717, i_148_, i_149_, false, is, Class55.aClass55_567);
			((GLToolkit) this).aClass30_Sub2_Sub1_8111.method420(false, false);
			f = ((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).aFloat9051;
			f_154_ = ((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).aFloat9049;
		} else {
			((GLToolkit) this).aClass30_Sub2_Sub1_8111.method421(0, 0, i_148_, i_149_, is, Class55.aClass55_567, 0, 0,
					false);
			f = (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).aFloat9051 * (float) i_149_
					/ (float) (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).anInt6747));
			f_154_ = (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).aFloat9049 * (float) i_148_
					/ (float) (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).anInt6746));
		}
		method5251();
		method5256(((GLToolkit) this).aClass30_Sub2_Sub1_8111);
		method5266(i_153_);
		OpenGL.glColor4ub((byte) (i_150_ >> 16), (byte) (i_150_ >> 8), (byte) i_150_, (byte) (i_150_ >> 24));
		method5273(i_151_);
		method5258(34165, 34165);
		method5259(0, 34166, 768);
		method5259(2, 5890, 770);
		method5286(0, 34166, 770);
		method5286(2, 5890, 770);
		float f_155_ = (float) i;
		float f_156_ = (float) i_147_;
		float f_157_ = f_155_ + (float) i_148_;
		float f_158_ = f_156_ + (float) i_149_;
		OpenGL.glBegin(7);
		OpenGL.glTexCoord2f(0.0F, 0.0F);
		OpenGL.glVertex2f(f_155_, f_156_);
		OpenGL.glTexCoord2f(0.0F, f_154_);
		OpenGL.glVertex2f(f_155_, f_158_);
		OpenGL.glTexCoord2f(f, f_154_);
		OpenGL.glVertex2f(f_157_, f_158_);
		OpenGL.glTexCoord2f(f, 0.0F);
		OpenGL.glVertex2f(f_157_, f_156_);
		OpenGL.glEnd();
		method5259(0, 5890, 768);
		method5259(2, 34166, 770);
		method5286(0, 5890, 770);
		method5286(2, 34166, 770);
	}

	public final void method5129(Class222 class222) {
		((GLToolkit) this).aClass222_8087.method2070(class222);
		((GLToolkit) this).aClass233_8110.method2145(((GLToolkit) this).aClass222_8087);
		((GLToolkit) this).aClass222_8103.method2070(class222);
		((GLToolkit) this).aClass222_8103.method2058();
		((GLToolkit) this).aClass233_8089.method2145(((GLToolkit) this).aClass222_8103);
		method5235();
		if (((GLToolkit) this).anInt8107 != 1)
			method5234();
	}

	public final void r(int i, int i_159_, int i_160_, int i_161_) {
		if (aClass52_5292 != null) {
			if (i < 0)
				i = 0;
			if (i_160_ > aClass52_5292.method545())
				i_160_ = aClass52_5292.method545();
			if (i_159_ < 0)
				i_159_ = 0;
			if (i_161_ > aClass52_5292.method552())
				i_161_ = aClass52_5292.method552();
			((GLToolkit) this).anInt8081 = i;
			((GLToolkit) this).anInt8109 = i_159_;
			((GLToolkit) this).anInt8024 = i_160_;
			((GLToolkit) this).anInt8059 = i_161_;
			OpenGL.glEnable(3089);
			method5232();
		}
	}

	public final void o(int i, int i_162_, int i_163_, int i_164_) {
		if (((GLToolkit) this).anInt8081 < i)
			((GLToolkit) this).anInt8081 = i;
		if (((GLToolkit) this).anInt8024 > i_163_)
			((GLToolkit) this).anInt8024 = i_163_;
		if (((GLToolkit) this).anInt8109 < i_162_)
			((GLToolkit) this).anInt8109 = i_162_;
		if (((GLToolkit) this).anInt8059 > i_164_)
			((GLToolkit) this).anInt8059 = i_164_;
		OpenGL.glEnable(3089);
		method5232();
	}

	public final void method5095(Class66 class66) {
		((GLToolkit) this).aClass66_Sub1_8159 = (Class66_Sub1) class66;
	}

	final void method5231() {
		if (aClass52_5292 != null) {
			int i;
			int i_165_;
			int i_166_;
			int i_167_;
			if (((GLToolkit) this).anInt8107 == 2) {
				i = ((GLToolkit) this).anInt8115;
				i_165_ = ((GLToolkit) this).anInt8194;
				i_166_ = ((GLToolkit) this).anInt8117;
				i_167_ = ((GLToolkit) this).anInt8180;
			} else {
				i = 0;
				i_165_ = 0;
				i_166_ = aClass52_5292.method545();
				i_167_ = aClass52_5292.method552();
			}
			if (i_166_ < 1)
				i_166_ = 1;
			if (i_167_ < 1)
				i_167_ = 1;
			OpenGL.glViewport(((GLToolkit) this).anInt8113 + i,
					(((GLToolkit) this).anInt8114 + aClass52_5292.method552() - i_165_ - i_167_), i_166_, i_167_);
			((GLToolkit) this).aFloat8096 = (float) ((GLToolkit) this).anInt8117 / 2.0F;
			((GLToolkit) this).aFloat8098 = (float) ((GLToolkit) this).anInt8180 / 2.0F;
			((GLToolkit) this).aFloat8095 = ((float) ((GLToolkit) this).anInt8115 + ((GLToolkit) this).aFloat8096);
			((GLToolkit) this).aFloat8097 = ((float) ((GLToolkit) this).anInt8194 + ((GLToolkit) this).aFloat8098);
		}
	}

	final void method5232() {
		if (aClass52_5292 != null && (((GLToolkit) this).anInt8081 < ((GLToolkit) this).anInt8024)
				&& (((GLToolkit) this).anInt8109 < ((GLToolkit) this).anInt8059))
			OpenGL.glScissor((((GLToolkit) this).anInt8113 + ((GLToolkit) this).anInt8081),
					(((GLToolkit) this).anInt8114 + aClass52_5292.method552() - ((GLToolkit) this).anInt8059),
					(((GLToolkit) this).anInt8024 - ((GLToolkit) this).anInt8081),
					(((GLToolkit) this).anInt8059 - ((GLToolkit) this).anInt8109));
		else
			OpenGL.glScissor(0, 0, 0, 0);
	}

	final void method5233(Class233 class233) {
		OpenGL.glLoadMatrixf(class233.aFloatArray2594, 0);
	}

	public final void method5043(Class222 class222) {
		((GLToolkit) this).aClass222_8087.method2070(class222);
		((GLToolkit) this).aClass233_8110.method2145(((GLToolkit) this).aClass222_8087);
		((GLToolkit) this).aClass222_8103.method2070(class222);
		((GLToolkit) this).aClass222_8103.method2058();
		((GLToolkit) this).aClass233_8089.method2145(((GLToolkit) this).aClass222_8103);
		method5235();
		if (((GLToolkit) this).anInt8107 != 1)
			method5234();
	}

	public Class222 method5044() {
		return new Class222(((GLToolkit) this).aClass222_8087);
	}

	final void method5234() {
		OpenGL.glLoadIdentity();
		OpenGL.glMultMatrixf((((GLToolkit) this).aClass233_8110.aFloatArray2594), 0);
		if (((GLToolkit) this).aBoolean8147)
			((Class27) ((GLToolkit) this).aClass27_8054).aClass47_Sub5_358.method524();
		method5279();
		method5277();
	}

	public final void method5182(Class233 class233) {
		((GLToolkit) this).aClass233_8041.method2142(class233);
		method5235();
		method5240();
	}

	public void method5080() {
		if (((GLToolkit) this).aBoolean8185 && aClass52_5292 != null) {
			int i = ((GLToolkit) this).anInt8081;
			int i_168_ = ((GLToolkit) this).anInt8024;
			int i_169_ = ((GLToolkit) this).anInt8109;
			int i_170_ = ((GLToolkit) this).anInt8059;
			L();
			int i_171_ = ((GLToolkit) this).anInt8115;
			int i_172_ = ((GLToolkit) this).anInt8194;
			int i_173_ = ((GLToolkit) this).anInt8117;
			int i_174_ = ((GLToolkit) this).anInt8180;
			method5011();
			OpenGL.glReadBuffer(1028);
			OpenGL.glDrawBuffer(1029);
			method5291();
			method5226(false);
			method5262(false);
			method5264(false);
			method5281(false);
			method5256(null);
			method5275(-2);
			method5243(1);
			method5266(0);
			OpenGL.glMatrixMode(5889);
			OpenGL.glLoadIdentity();
			OpenGL.glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);
			OpenGL.glMatrixMode(5888);
			OpenGL.glLoadIdentity();
			OpenGL.glRasterPos2i(0, 0);
			OpenGL.glCopyPixels(0, 0, aClass52_5292.method545(), aClass52_5292.method552(), 6144);
			OpenGL.glFlush();
			OpenGL.glReadBuffer(1029);
			OpenGL.glDrawBuffer(1029);
			r(i, i_169_, i_168_, i_170_);
			method5187(i_171_, i_172_, i_173_, i_174_);
		}
	}

	public Sprite method5101(IndexedImage class89, boolean bool) {
		int[] is = new int[class89.anInt812 * class89.anInt816];
		int i = 0;
		int i_175_ = 0;
		if (class89.aByteArray819 != null) {
			for (int i_176_ = 0; i_176_ < class89.anInt816; i_176_++) {
				for (int i_177_ = 0; i_177_ < class89.anInt812; i_177_++) {
					is[i_175_++] = (class89.aByteArray819[i] << 24
							| (class89.anIntArray817[class89.aByteArray818[i] & 0xff]));
					i++;
				}
			}
		} else {
			for (int i_178_ = 0; i_178_ < class89.anInt816; i_178_++) {
				for (int i_179_ = 0; i_179_ < class89.anInt812; i_179_++) {
					int i_180_ = (class89.anIntArray817[class89.aByteArray818[i++] & 0xff]);
					is[i_175_++] = i_180_ != 0 ? ~0xffffff | i_180_ : 0;
				}
			}
		}
		Sprite class57 = method5031(is, 0, class89.anInt812, class89.anInt812, class89.anInt816, -797687723);
		class57.method621(class89.anInt815, class89.anInt811, class89.anInt814, class89.anInt813);
		return class57;
	}

	public Ground method5123(int i, int i_181_, int[][] is, int[][] is_182_, int i_183_, int i_184_, int i_185_) {
		return new Class_xa_Sub3(this, i_184_, i_185_, i, i_181_, is, is_182_, i_183_);
	}

	public void method5161(float f, float f_186_, float f_187_, float[] fs) {
		float f_188_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * f_186_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * f_187_));
		float f_189_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * f_186_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * f_187_));
		float f_190_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[13]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[1] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5] * f_186_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9] * f_187_));
		float f_191_ = (((GLToolkit) this).aClass233_8110.aFloatArray2594[14]
				+ ((GLToolkit) this).aClass233_8110.aFloatArray2594[2] * f
				+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[6] * f_186_)
				+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[10] * f_187_));
		fs[0] = (((GLToolkit) this).aFloat8095 + ((GLToolkit) this).aFloat8096 * f_189_ / f_188_);
		fs[1] = (((GLToolkit) this).aFloat8097 + ((GLToolkit) this).aFloat8098 * f_190_ / f_188_);
		fs[2] = f_191_;
	}

	final void method5235() {
		((GLToolkit) this).aClass233_8069.method2142(((GLToolkit) this).aClass233_8110);
		((GLToolkit) this).aClass233_8069.method2144(((GLToolkit) this).aClass233_8041);
		((GLToolkit) this).aClass233_8069.method2157(((GLToolkit) this).aFloatArrayArray8077[0]);
		((GLToolkit) this).aClass233_8069.method2158(((GLToolkit) this).aFloatArrayArray8077[1]);
		((GLToolkit) this).aClass233_8069.method2156(((GLToolkit) this).aFloatArrayArray8077[2]);
		((GLToolkit) this).aClass233_8069.method2170(((GLToolkit) this).aFloatArrayArray8077[3]);
		((GLToolkit) this).aClass233_8069.method2171(((GLToolkit) this).aFloatArrayArray8077[4]);
		((GLToolkit) this).aClass233_8069.method2163(((GLToolkit) this).aFloatArrayArray8077[5]);
	}

	public void method4999(int i, int i_192_, int i_193_, int i_194_, int i_195_, int i_196_, int i_197_) {
		OpenGL.glLineWidth((float) i_196_);
		method5091(i, i_192_, i_193_, i_194_, i_195_, i_197_);
		OpenGL.glLineWidth(1.0F);
	}

	public void RA(boolean bool) {
		((GLToolkit) this).aBoolean8108 = bool;
		method5265();
	}

	public int method5048() {
		return 4;
	}

	final void method5236() {
		OpenGL.glPushMatrix();
	}

	void fv(int i, int i_198_, int i_199_, int i_200_, int i_201_) {
		if (i_199_ < 0)
			i_199_ = -i_199_;
		if (i + i_199_ >= ((GLToolkit) this).anInt8081 && i - i_199_ <= ((GLToolkit) this).anInt8024
				&& i_198_ + i_199_ >= ((GLToolkit) this).anInt8109 && i_198_ - i_199_ <= ((GLToolkit) this).anInt8059) {
			method5250();
			method5266(i_201_);
			OpenGL.glColor4ub((byte) (i_200_ >> 16), (byte) (i_200_ >> 8), (byte) i_200_, (byte) (i_200_ >> 24));
			float f = (float) i + 0.35F;
			float f_202_ = (float) i_198_ + 0.35F;
			int i_203_ = i_199_ << 1;
			if ((float) i_203_ < ((GLToolkit) this).aFloat8188) {
				OpenGL.glBegin(7);
				OpenGL.glVertex2f(f + 1.0F, f_202_ + 1.0F);
				OpenGL.glVertex2f(f + 1.0F, f_202_ - 1.0F);
				OpenGL.glVertex2f(f - 1.0F, f_202_ - 1.0F);
				OpenGL.glVertex2f(f - 1.0F, f_202_ + 1.0F);
				OpenGL.glEnd();
			} else if ((float) i_203_ <= ((GLToolkit) this).aFloat8187) {
				OpenGL.glEnable(2832);
				OpenGL.glPointSize((float) i_203_);
				OpenGL.glBegin(0);
				OpenGL.glVertex2f(f, f_202_);
				OpenGL.glEnd();
				OpenGL.glDisable(2832);
			} else {
				OpenGL.glBegin(6);
				OpenGL.glVertex2f(f, f_202_);
				int i_204_ = 262144 / (6 * i_199_);
				if (i_204_ <= 64)
					i_204_ = 64;
				else if (i_204_ > 512)
					i_204_ = 512;
				i_204_ = Class422_Sub4.method5639(i_204_, 2146982068);
				OpenGL.glVertex2f(f + (float) i_199_, f_202_);
				for (int i_205_ = 16384 - i_204_; i_205_ > 0; i_205_ -= i_204_)
					OpenGL.glVertex2f(f + (Class35.aFloatArray417[i_205_] * (float) i_199_),
							f_202_ + (Class35.aFloatArray418[i_205_] * (float) i_199_));
				OpenGL.glVertex2f(f + (float) i_199_, f_202_);
				OpenGL.glEnd();
			}
		}
	}

	final void method5237() {
		if (((GLToolkit) this).anInt8107 != 2) {
			((GLToolkit) this).anInt8107 = 2;
			method5227(((GLToolkit) this).aClass233_8041.aFloatArray2594);
			method5234();
			method5231();
			method5276();
			((GLToolkit) this).anInt8080 &= ~0x7;
		}
	}

	public void method5103(Class_v class_v) {
		((GLToolkit) this).aNativeHeap8181 = ((Class_v_Sub1) (Class_v_Sub1) class_v).aNativeHeap9783;
		if (((GLToolkit) this).anInterface1_8037 == null) {
			RsFloatBuffer class298_sub53_sub1 = new RsFloatBuffer(80);
			if (((GLToolkit) this).aBoolean8143) {
				class298_sub53_sub1.method3658(-1.0F);
				class298_sub53_sub1.method3658(-1.0F);
				class298_sub53_sub1.method3658(0.0F);
				class298_sub53_sub1.method3658(0.0F);
				class298_sub53_sub1.method3658(0.0F);
				class298_sub53_sub1.method3658(-1.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(0.0F);
				class298_sub53_sub1.method3658(0.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(0.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(-1.0F);
				class298_sub53_sub1.method3658(0.0F);
				class298_sub53_sub1.method3658(1.0F);
				class298_sub53_sub1.method3658(0.0F);
			} else {
				class298_sub53_sub1.method3659(-1.0F);
				class298_sub53_sub1.method3659(-1.0F);
				class298_sub53_sub1.method3659(0.0F);
				class298_sub53_sub1.method3659(0.0F);
				class298_sub53_sub1.method3659(0.0F);
				class298_sub53_sub1.method3659(-1.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(0.0F);
				class298_sub53_sub1.method3659(0.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(0.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(-1.0F);
				class298_sub53_sub1.method3659(0.0F);
				class298_sub53_sub1.method3659(1.0F);
				class298_sub53_sub1.method3659(0.0F);
			}
			((GLToolkit) this).anInterface1_8037 = method5244(20, class298_sub53_sub1.buffer,
					class298_sub53_sub1.index * 385051775, false);
			((GLToolkit) this).aClass32_8092 = new OpenGlArrayBufferPointer(((GLToolkit) this).anInterface1_8037, 5126, 3, 0);
			((GLToolkit) this).aClass32_8193 = new OpenGlArrayBufferPointer(((GLToolkit) this).anInterface1_8037, 5126, 2, 12);
			((GLToolkit) this).aClass34_8057.method439(this);
			try {
				Class var_class = java.lang.ClassLoader.class;
				Field field = var_class.getDeclaredField("nativeLibraries");
				Class var_class_124_ = java.lang.reflect.AccessibleObject.class;
				Method method = var_class_124_.getDeclaredMethod("setAccessible", (new Class[] { Boolean.TYPE }));
				method.invoke(field, new Object[] { Boolean.TRUE });
			} catch (Throwable throwable) {
				/* empty */
			}
		}
	}

	public boolean method5032() {
		return (((GLToolkit) this).aBoolean8173 && (!method5054() || ((GLToolkit) this).aBoolean8174));
	}

	public final void c(int i, int i_206_, int i_207_) {
		if (((GLToolkit) this).anInt8139 != i || ((GLToolkit) this).anInt8007 != i_206_
				|| ((GLToolkit) this).anInt8195 != i_207_) {
			((GLToolkit) this).anInt8139 = i;
			((GLToolkit) this).anInt8007 = i_206_;
			((GLToolkit) this).anInt8195 = i_207_;
			method5242();
			method5241();
		}
	}

	final void method5238(float f, float f_208_) {
		((GLToolkit) this).aFloat8144 = f;
		((GLToolkit) this).aFloat8145 = f_208_;
		method5242();
	}

	void method5239() {
		aFloatArray8163[0] = (((GLToolkit) this).aFloat8130 * ((GLToolkit) this).aFloat8125);
		aFloatArray8163[1] = (((GLToolkit) this).aFloat8130 * ((GLToolkit) this).aFloat8128);
		aFloatArray8163[2] = (((GLToolkit) this).aFloat8130 * ((GLToolkit) this).aFloat8191);
		aFloatArray8163[3] = 1.0F;
		OpenGL.glLightModelfv(2899, aFloatArray8163, 0);
	}

	final void method5240() {
		((GLToolkit) this).aFloat8102 = ((GLToolkit) this).aClass233_8041.method2155();
		((GLToolkit) this).aFloat8134 = ((GLToolkit) this).aClass233_8041.method2154();
		method5242();
		if (((GLToolkit) this).anInt8107 == 2)
			method5227(((GLToolkit) this).aClass233_8041.aFloatArray2594);
		else if (((GLToolkit) this).anInt8107 == 1)
			method5227(((GLToolkit) this).aClass233_8091.aFloatArray2594);
	}

	void method5241() {
		if (((GLToolkit) this).aBoolean8138 && ((GLToolkit) this).anInt8007 >= 0)
			OpenGL.glEnable(2912);
		else
			OpenGL.glDisable(2912);
	}

	void method5242() {
		((GLToolkit) this).aFloat8160 = (((GLToolkit) this).aFloat8102 - (float) ((GLToolkit) this).anInt8195
				- ((GLToolkit) this).aFloat8145);
		((GLToolkit) this).aFloat8142 = (((GLToolkit) this).aFloat8160
				- ((float) ((GLToolkit) this).anInt8007 * ((GLToolkit) this).aFloat8144));
		if (((GLToolkit) this).aFloat8142 < ((GLToolkit) this).aFloat8134)
			((GLToolkit) this).aFloat8142 = ((GLToolkit) this).aFloat8134;
		OpenGL.glFogf(2915, ((GLToolkit) this).aFloat8142);
		OpenGL.glFogf(2916, ((GLToolkit) this).aFloat8160);
		aFloatArray8163[0] = (float) (((GLToolkit) this).anInt8139 & 0xff0000) / 1.671168E7F;
		aFloatArray8163[1] = (float) (((GLToolkit) this).anInt8139 & 0xff00) / 65280.0F;
		aFloatArray8163[2] = (float) (((GLToolkit) this).anInt8139 & 0xff) / 255.0F;
		OpenGL.glFogfv(2918, aFloatArray8163, 0);
	}

	final void method5243(int i) {
		if (i == 1)
			method5258(7681, 7681);
		else if (i == 0)
			method5258(8448, 8448);
		else if (i == 2)
			method5258(34165, 7681);
		else if (i == 3)
			method5258(260, 8448);
		else if (i == 4)
			method5258(34023, 34023);
	}

	public Class66 method5028(int i, int i_209_, int i_210_, int i_211_, int i_212_, int i_213_) {
		return (((GLToolkit) this).aBoolean8178 ? new Class66_Sub1_Sub1(this, i, i_209_, i_210_, i_211_, i_212_, i_213_)
				: null);
	}

	public Class66 method5179(Class66 class66, Class66 class66_214_, float f, Class66 class66_215_) {
		if (class66 != null && class66_214_ != null && ((GLToolkit) this).aBoolean8178
				&& ((GLToolkit) this).framebuffer_obj) {
			Class66_Sub1_Sub2 class66_sub1_sub2 = null;
			Class66_Sub1 class66_sub1 = (Class66_Sub1) class66;
			Class66_Sub1 class66_sub1_216_ = (Class66_Sub1) class66_214_;
			Class30_Sub1 class30_sub1 = class66_sub1.method769();
			Class30_Sub1 class30_sub1_217_ = class66_sub1_216_.method769();
			if (class30_sub1 != null && class30_sub1_217_ != null) {
				int i = ((((Class30_Sub1) class30_sub1).anInt6745 > ((Class30_Sub1) class30_sub1_217_).anInt6745)
						? ((Class30_Sub1) class30_sub1).anInt6745 : ((Class30_Sub1) class30_sub1_217_).anInt6745);
				if (class66 != class66_215_ && class66_214_ != class66_215_
						&& class66_215_ instanceof Class66_Sub1_Sub2) {
					Class66_Sub1_Sub2 class66_sub1_sub2_218_ = (Class66_Sub1_Sub2) class66_215_;
					if (class66_sub1_sub2_218_.method771() == i)
						class66_sub1_sub2 = class66_sub1_sub2_218_;
				}
				if (class66_sub1_sub2 == null)
					class66_sub1_sub2 = new Class66_Sub1_Sub2(this, i);
				if (class66_sub1_sub2.method772(class30_sub1, class30_sub1_217_, f))
					return class66_sub1_sub2;
			}
		}
		return f < 0.5F ? class66 : class66_214_;
	}

	public void method5055(float f, float f_219_, float f_220_, float[] fs) {
		float f_221_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[14]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[2] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[6] * f_219_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[10] * f_220_));
		float f_222_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * f_219_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * f_220_));
		if (f_221_ < -f_222_ || f_221_ > f_222_) {
			float[] fs_223_ = fs;
			float[] fs_224_ = fs;
			fs[2] = Float.NaN;
			fs_224_[1] = Float.NaN;
			fs_223_[0] = Float.NaN;
		} else {
			float f_225_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
					+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * f)
					+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * f_219_)
					+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * f_220_));
			if (f_225_ < -f_222_ || f_225_ > f_222_) {
				float[] fs_226_ = fs;
				float[] fs_227_ = fs;
				fs[2] = Float.NaN;
				fs_227_[1] = Float.NaN;
				fs_226_[0] = Float.NaN;
			} else {
				float f_228_ = ((((GLToolkit) this).aClass233_8069.aFloatArray2594[13])
						+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[1]) * f
						+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5]) * f_219_
						+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9]) * f_220_);
				if (f_228_ < -f_222_ || f_228_ > f_222_) {
					float[] fs_229_ = fs;
					float[] fs_230_ = fs;
					fs[2] = Float.NaN;
					fs_230_[1] = Float.NaN;
					fs_229_[0] = Float.NaN;
				} else {
					float f_231_ = ((((GLToolkit) this).aClass233_8110.aFloatArray2594[14])
							+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[2]) * f
							+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[6]) * f_219_
							+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[10]) * f_220_);
					fs[0] = (((GLToolkit) this).aFloat8095 + (((GLToolkit) this).aFloat8096 * f_225_ / f_222_));
					fs[1] = (((GLToolkit) this).aFloat8097 + (((GLToolkit) this).aFloat8098 * f_228_ / f_222_));
					fs[2] = f_231_;
				}
			}
		}
	}

	public Class_ta method5034(int i, int i_232_, int[] is, int[] is_233_) {
		return Class_ta_Sub1.method5999(this, i, i_232_, is, is_233_);
	}

	public final boolean method5054() {
		return (((GLToolkit) this).aClass298_Sub8_Sub1_8056 != null
				&& ((GLToolkit) this).aClass298_Sub8_Sub1_8056.method2886());
	}

	final void method5188(float f, float f_234_, float f_235_, float f_236_, float f_237_, float f_238_) {
		Class298_Sub8_Sub1.aFloat9173 = f;
		Class298_Sub8_Sub1.aFloat9172 = f_234_;
		Class298_Sub8_Sub1.aFloat9171 = f_235_;
	}

	public final void method5056(int i, int i_239_, int i_240_, int i_241_) {
		((GLToolkit) this).aClass42_8055.method481(i, i_239_, i_240_, i_241_);
	}

	public final void method5112() {
		((GLToolkit) this).aClass42_8055.method483();
	}

	public Class52_Sub1 method5094() {
		return new Class52_Sub1_Sub2(this);
	}

	public final void method5189(Class66 class66) {
		((GLToolkit) this).aClass66_Sub1_8159 = (Class66_Sub1) class66;
	}

	final Interface1 method5244(int i, byte[] is, int i_242_, boolean bool) {
		if (((GLToolkit) this).aBoolean8126 && (!bool || ((GLToolkit) this).aBoolean8176))
			return new Class40_Sub2(this, i, is, i_242_, bool);
		return new Class46_Sub2(this, i, is, i_242_);
	}

	final Interface1 method5245(int i, Buffer buffer, int i_243_, boolean bool) {
		if (((GLToolkit) this).aBoolean8126 && (!bool || ((GLToolkit) this).aBoolean8176))
			return new Class40_Sub2(this, i, buffer, i_243_, bool);
		return new Class46_Sub2(this, i, buffer);
	}

	final void method5246(Interface1 interface1) {
		if (((GLToolkit) this).anInterface1_8151 != interface1) {
			if (((GLToolkit) this).aBoolean8126)
				OpenGL.glBindBufferARB(34962, interface1.method10());
			((GLToolkit) this).anInterface1_8151 = interface1;
		}
	}

	final void method5247(Interface2 interface2) {
		if (((GLToolkit) this).anInterface2_8150 != interface2) {
			if (((GLToolkit) this).aBoolean8126)
				OpenGL.glBindBufferARB(34963, interface2.method26());
			((GLToolkit) this).anInterface2_8150 = interface2;
		}
	}

	final void method5248(OpenGlArrayBufferPointer class32, OpenGlArrayBufferPointer class32_244_, OpenGlArrayBufferPointer class32_245_, OpenGlArrayBufferPointer class32_246_) {
		if (class32 != null) {
			method5246(((OpenGlArrayBufferPointer) class32).buffer);
			OpenGL.glVertexPointer(((OpenGlArrayBufferPointer) class32).aByte396, ((OpenGlArrayBufferPointer) class32).aShort395,
					((GLToolkit) this).anInterface1_8151.method15(),
					(((GLToolkit) this).anInterface1_8151.method16() + (long) ((OpenGlArrayBufferPointer) class32).aByte398));
			OpenGL.glEnableClientState(32884);
		} else
			OpenGL.glDisableClientState(32884);
		if (class32_244_ != null) {
			method5246(((OpenGlArrayBufferPointer) class32_244_).buffer);
			OpenGL.glNormalPointer(((OpenGlArrayBufferPointer) class32_244_).aShort395, ((GLToolkit) this).anInterface1_8151.method15(),
					(((GLToolkit) this).anInterface1_8151.method16() + (long) ((OpenGlArrayBufferPointer) class32_244_).aByte398));
			OpenGL.glEnableClientState(32885);
		} else
			OpenGL.glDisableClientState(32885);
		if (class32_245_ != null) {
			method5246(((OpenGlArrayBufferPointer) class32_245_).buffer);
			OpenGL.glColorPointer(((OpenGlArrayBufferPointer) class32_245_).aByte396, ((OpenGlArrayBufferPointer) class32_245_).aShort395,
					((GLToolkit) this).anInterface1_8151.method15(),
					(((GLToolkit) this).anInterface1_8151.method16() + (long) ((OpenGlArrayBufferPointer) class32_245_).aByte398));
			OpenGL.glEnableClientState(32886);
		} else
			OpenGL.glDisableClientState(32886);
		if (class32_246_ != null) {
			method5246(((OpenGlArrayBufferPointer) class32_246_).buffer);
			OpenGL.glTexCoordPointer(((OpenGlArrayBufferPointer) class32_246_).aByte396, ((OpenGlArrayBufferPointer) class32_246_).aShort395,
					((GLToolkit) this).anInterface1_8151.method15(),
					(((GLToolkit) this).anInterface1_8151.method16() + (long) ((OpenGlArrayBufferPointer) class32_246_).aByte398));
			OpenGL.glEnableClientState(32888);
		} else
			OpenGL.glDisableClientState(32888);
	}

	final void method5150(float f, float f_247_, float f_248_, float f_249_, float f_250_, float f_251_) {
		Class298_Sub8_Sub1.aFloat9173 = f;
		Class298_Sub8_Sub1.aFloat9172 = f_247_;
		Class298_Sub8_Sub1.aFloat9171 = f_248_;
	}

	final synchronized void deleteFrameBuffers(int i) {
		Class298_Sub35 class298_sub35 = new Class298_Sub35(i);
		((GLToolkit) this).deleteFrameBuffers.method5968(class298_sub35, 241612105);
	}

	final void method5250() {
		if (((GLToolkit) this).anInt8080 != 1) {
			method5223();
			method5226(false);
			method5262(false);
			method5264(false);
			method5281(false);
			method5256(null);
			method5275(-2);
			method5243(1);
			((GLToolkit) this).anInt8080 = 1;
		}
	}

	final void method5251() {
		if (((GLToolkit) this).anInt8080 != 2) {
			method5223();
			method5226(false);
			method5262(false);
			method5264(false);
			method5281(false);
			method5275(-2);
			((GLToolkit) this).anInt8080 = 2;
		}
	}

	final void method5252() {
		if (((GLToolkit) this).anInt8080 != 8) {
			method5237();
			method5226(true);
			method5264(true);
			method5281(true);
			method5266(1);
			((GLToolkit) this).anInt8080 = 8;
		}
	}

	public final void method5133(Class233 class233) {
		((GLToolkit) this).aClass233_8041.method2142(class233);
		method5235();
		method5240();
	}

	final void method5253(int i, boolean bool) {
		method5278(i, bool, true);
	}

	final void method5254(Interface2 interface2, int i, int i_252_, int i_253_) {
		method5247(interface2);
		OpenGL.glDrawElements(i, i_253_, 5123, interface2.method20() + (long) (i_252_ * 2));
	}

	final void method5255(int i) {
		if (((GLToolkit) this).anInt8156 != i) {
			OpenGL.glActiveTexture(33984 + i);
			((GLToolkit) this).anInt8156 = i;
		}
	}

	final void method5256(Class30 class30) {
		Class30 class30_254_ = (((GLToolkit) this).aClass30Array8182[((GLToolkit) this).anInt8156]);
		if (class30_254_ != class30) {
			if (class30 != null) {
				if (class30_254_ != null) {
					if (((Class30) class30).anInt372 != ((Class30) class30_254_).anInt372) {
						OpenGL.glDisable(((Class30) class30_254_).anInt372);
						OpenGL.glEnable(((Class30) class30).anInt372);
					}
				} else
					OpenGL.glEnable(((Class30) class30).anInt372);
				OpenGL.glBindTexture(((Class30) class30).anInt372, ((Class30) class30).anInt376);
			} else
				OpenGL.glDisable(((Class30) class30_254_).anInt372);
			((GLToolkit) this).aClass30Array8182[(((GLToolkit) this).anInt8156)] = class30;
		}
		((GLToolkit) this).anInt8080 &= ~0x1;
	}

	void method5257() {
		int i = aClass52_5292.method545();
		int i_255_ = aClass52_5292.method552();
		((GLToolkit) this).aClass233_8091.method2151(0.0F, (float) i, 0.0F, (float) i_255_, -1.0F, 1.0F);
		method5011();
		method5291();
		L();
	}

	public final void qa(int[] is) {
		is[0] = ((GLToolkit) this).anInt8081;
		is[1] = ((GLToolkit) this).anInt8109;
		is[2] = ((GLToolkit) this).anInt8024;
		is[3] = ((GLToolkit) this).anInt8059;
	}

	final void method5258(int i, int i_256_) {
		if (((GLToolkit) this).anInt8156 == 0) {
			boolean bool = false;
			if (((GLToolkit) this).anInt8136 != i) {
				OpenGL.glTexEnvi(8960, 34161, i);
				((GLToolkit) this).anInt8136 = i;
				bool = true;
			}
			if (((GLToolkit) this).anInt8010 != i_256_) {
				OpenGL.glTexEnvi(8960, 34162, i_256_);
				((GLToolkit) this).anInt8010 = i_256_;
				bool = true;
			}
			if (bool)
				((GLToolkit) this).anInt8080 &= ~0xd;
		} else {
			OpenGL.glTexEnvi(8960, 34161, i);
			OpenGL.glTexEnvi(8960, 34162, i_256_);
		}
	}

	final void method5259(int i, int i_257_, int i_258_) {
		OpenGL.glTexEnvi(8960, 34176 + i, i_257_);
		OpenGL.glTexEnvi(8960, 34192 + i, i_258_);
	}

	public void method5157(int i, int i_259_, float f, int i_260_, int i_261_, float f_262_, int i_263_, int i_264_,
			float f_265_, int i_266_, int i_267_, int i_268_, int i_269_) {
		method5250();
		method5266(i_269_);
		OpenGL.glBegin(4);
		OpenGL.glColor4ub((byte) (i_266_ >> 16), (byte) (i_266_ >> 8), (byte) i_266_, (byte) (i_266_ >> 24));
		OpenGL.glVertex3f((float) i + 0.35F, (float) i_259_ + 0.35F, f);
		OpenGL.glColor4ub((byte) (i_267_ >> 16), (byte) (i_267_ >> 8), (byte) i_267_, (byte) (i_267_ >> 24));
		OpenGL.glVertex3f((float) i_260_ + 0.35F, (float) i_261_ + 0.35F, f_262_);
		OpenGL.glColor4ub((byte) (i_268_ >> 16), (byte) (i_268_ >> 8), (byte) i_268_, (byte) (i_268_ >> 24));
		OpenGL.glVertex3f((float) i_263_ + 0.35F, (float) i_264_ + 0.35F, f_265_);
		OpenGL.glEnd();
	}

	public void el(float f, float f_270_) {
		((GLToolkit) this).aFloat8099 = f;
		((GLToolkit) this).aFloat8100 = f_270_;
		method5276();
	}

	final void method5260(float f, float f_271_, float f_272_, float f_273_) {
		aFloatArray8163[0] = f;
		aFloatArray8163[1] = f_271_;
		aFloatArray8163[2] = f_272_;
		aFloatArray8163[3] = f_273_;
		OpenGL.glTexEnvfv(8960, 8705, aFloatArray8163, 0);
	}

	final void method5261(float f, float f_274_, float f_275_) {
		OpenGL.glMatrixMode(5890);
		if (((GLToolkit) this).aBoolean8090)
			OpenGL.glLoadIdentity();
		OpenGL.glTranslatef(f, f_274_, f_275_);
		OpenGL.glMatrixMode(5888);
		((GLToolkit) this).aBoolean8090 = true;
	}

	public void method5060(float f, float f_276_, float f_277_, float[] fs) {
		float f_278_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * f_276_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * f_277_));
		float f_279_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * f_276_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * f_277_));
		float f_280_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[13]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[1] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5] * f_276_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9] * f_277_));
		float f_281_ = (((GLToolkit) this).aClass233_8110.aFloatArray2594[14]
				+ ((GLToolkit) this).aClass233_8110.aFloatArray2594[2] * f
				+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[6] * f_276_)
				+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[10] * f_277_));
		fs[0] = (((GLToolkit) this).aFloat8095 + ((GLToolkit) this).aFloat8096 * f_279_ / f_278_);
		fs[1] = (((GLToolkit) this).aFloat8097 + ((GLToolkit) this).aFloat8098 * f_280_ / f_278_);
		fs[2] = f_281_;
	}

	final void method5262(boolean bool) {
		if (bool != ((GLToolkit) this).aBoolean8050) {
			((GLToolkit) this).aBoolean8050 = bool;
			method5290();
			((GLToolkit) this).anInt8080 &= ~0x7;
		}
	}

	final void method5263(boolean bool) {
		if (bool != ((GLToolkit) this).aBoolean8027) {
			((GLToolkit) this).aBoolean8027 = bool;
			method5290();
		}
	}

	public final boolean method5148() {
		return (((GLToolkit) this).aClass298_Sub8_Sub1_8056 != null
				&& ((GLToolkit) this).aClass298_Sub8_Sub1_8056.method2886());
	}

	final void method5264(boolean bool) {
		if (bool != ((GLToolkit) this).aBoolean8121) {
			if (bool)
				OpenGL.glEnable(2929);
			else
				OpenGL.glDisable(2929);
			((GLToolkit) this).aBoolean8121 = bool;
			((GLToolkit) this).anInt8080 &= ~0xf;
		}
	}

	public final synchronized void method4993(int i) {
		int i_282_ = 0;
		i &= 0x7fffffff;
		while (!((GLToolkit) this).deleteBufferIds.method5970((byte) 109)) {
			Class298_Sub35 class298_sub35 = (Class298_Sub35) ((GLToolkit) this).deleteBufferIds.method5971(1624694038);
			anIntArray8079[i_282_++] = (int) (class298_sub35.hash * 7051297995265073167L);
			((GLToolkit) this).anInt8112 -= class298_sub35.anInt7394 * -774922497;
			if (i_282_ == 1000) {
				OpenGL.glDeleteBuffersARB(i_282_, anIntArray8079, 0);
				i_282_ = 0;
			}
		}
		if (i_282_ > 0) {
			OpenGL.glDeleteBuffersARB(i_282_, anIntArray8079, 0);
			i_282_ = 0;
		}
		while (!((GLToolkit) this).deleteTextureIds.method5970((byte) 109)) {
			Class298_Sub35 class298_sub35 = (Class298_Sub35) ((GLToolkit) this).deleteTextureIds.method5971(1990742795);
			anIntArray8079[i_282_++] = (int) (class298_sub35.hash * 7051297995265073167L);
			((GLToolkit) this).anInt8175 -= class298_sub35.anInt7394 * -774922497;
			if (i_282_ == 1000) {
				OpenGL.glDeleteTextures(i_282_, anIntArray8079, 0);
				i_282_ = 0;
			}
		}
		if (i_282_ > 0) {
			OpenGL.glDeleteTextures(i_282_, anIntArray8079, 0);
			i_282_ = 0;
		}
		while (!((GLToolkit) this).deleteFrameBuffers.method5970((byte) 124)) {
			Class298_Sub35 class298_sub35 = (Class298_Sub35) ((GLToolkit) this).deleteFrameBuffers
					.method5971(1696221823);
			anIntArray8079[i_282_++] = class298_sub35.anInt7394 * -774922497;
			if (i_282_ == 1000) {
				OpenGL.glDeleteFramebuffersEXT(i_282_, anIntArray8079, 0);
				i_282_ = 0;
			}
		}
		if (i_282_ > 0) {
			OpenGL.glDeleteFramebuffersEXT(i_282_, anIntArray8079, 0);
			i_282_ = 0;
		}
		while (!((GLToolkit) this).deleteRenderBuffers.method5970((byte) 109)) {
			Class298_Sub35 class298_sub35 = (Class298_Sub35) ((GLToolkit) this).deleteRenderBuffers
					.method5971(1834890584);
			anIntArray8079[i_282_++] = (int) (class298_sub35.hash * 7051297995265073167L);
			((GLToolkit) this).anInt8070 -= class298_sub35.anInt7394 * -774922497;
			if (i_282_ == 1000) {
				OpenGL.glDeleteRenderbuffersEXT(i_282_, anIntArray8079, 0);
				i_282_ = 0;
			}
		}
		if (i_282_ > 0) {
			OpenGL.glDeleteRenderbuffersEXT(i_282_, anIntArray8079, 0);
		}
		while (!((GLToolkit) this).deleteLists.method5970((byte) 104)) {
			Class298_Sub35 class298_sub35 = (Class298_Sub35) ((GLToolkit) this).deleteLists.method5971(1957497379);
			OpenGL.glDeleteLists((int) (class298_sub35.hash * 7051297995265073167L),
					class298_sub35.anInt7394 * -774922497);
		}
		while (!((GLToolkit) this).deletePrograms.method5970((byte) 76)) {
			Class298 class298 = ((GLToolkit) this).deletePrograms.method5971(1672075374);
			OpenGL.glDeleteProgramARB((int) (class298.hash * 7051297995265073167L));
		}
		while (!((GLToolkit) this).deleteShaders.method5970((byte) 105)) {
			Class298 class298 = ((GLToolkit) this).deleteShaders.method5971(1793950137);
			OpenGL.glDeleteShader((int) (class298.hash * 7051297995265073167L));
		}
		while (!((GLToolkit) this).deleteLists.method5970((byte) 88)) {
			Class298_Sub35 class298_sub35 = (Class298_Sub35) ((GLToolkit) this).deleteLists.method5971(1623809962);
			OpenGL.glDeleteLists((int) (class298_sub35.hash * 7051297995265073167L),
					class298_sub35.anInt7394 * -774922497);
		}
		((GLToolkit) this).aClass61_8052.method717();
		if (za() > 100663296 && (Class122.method1319((byte) 1) > ((GLToolkit) this).aLong8078 + 60000L)) {
			System.gc();
			((GLToolkit) this).aLong8078 = Class122.method1319((byte) 1);
		}
		((GLToolkit) this).anInt8062 = i;
	}

	final void method5265() {
		OpenGL.glDepthMask(((GLToolkit) this).aBoolean8086 && ((GLToolkit) this).aBoolean8108);
	}

	final void method5266(int i) {
		if (((GLToolkit) this).anInt8196 != i) {
			int i_283_;
			boolean bool;
			boolean bool_284_;
			if (i == 1) {
				i_283_ = 1;
				bool = true;
				bool_284_ = true;
			} else if (i == 2) {
				i_283_ = 2;
				bool = true;
				bool_284_ = false;
			} else if (i == 128) {
				i_283_ = 3;
				bool = true;
				bool_284_ = true;
			} else {
				i_283_ = 0;
				bool = true;
				bool_284_ = false;
			}
			if (bool != ((GLToolkit) this).aBoolean8083) {
				OpenGL.glColorMask(bool, bool, bool, true);
				((GLToolkit) this).aBoolean8083 = bool;
			}
			if (bool_284_ != ((GLToolkit) this).aBoolean8038) {
				if (bool_284_)
					OpenGL.glEnable(3008);
				else
					OpenGL.glDisable(3008);
				((GLToolkit) this).aBoolean8038 = bool_284_;
			}
			if (i_283_ != ((GLToolkit) this).anInt8082) {
				if (i_283_ == 1) {
					OpenGL.glEnable(3042);
					OpenGL.glBlendFunc(770, 771);
				} else if (i_283_ == 2) {
					OpenGL.glEnable(3042);
					OpenGL.glBlendFunc(1, 1);
				} else if (i_283_ == 3) {
					OpenGL.glEnable(3042);
					OpenGL.glBlendFunc(774, 1);
				} else
					OpenGL.glDisable(3042);
				((GLToolkit) this).anInt8082 = i_283_;
			}
			((GLToolkit) this).anInt8196 = i;
			((GLToolkit) this).anInt8080 &= ~0xc;
		}
	}

	public final int za() {
		return (((GLToolkit) this).anInt8112 + ((GLToolkit) this).anInt8175 + ((GLToolkit) this).anInt8070);
	}

	final synchronized void deleteBuf(int i, int i_285_) {
		Class298_Sub35 class298_sub35 = new Class298_Sub35(i_285_);
		class298_sub35.hash = (long) i * 4191220306876042991L;
		((GLToolkit) this).deleteBufferIds.method5968(class298_sub35, 161198069);
	}

	public boolean method5073() {
		return true;
	}

	public void method5042(Class69 class69) {
		((GLToolkit) this).aClass34_8057.method436(this, class69);
	}

	final synchronized void deleteRenderBuffers(int i, int i_286_) {
		Class298_Sub35 class298_sub35 = new Class298_Sub35(i_286_);
		class298_sub35.hash = (long) i * 4191220306876042991L;
		((GLToolkit) this).deleteRenderBuffers.method5968(class298_sub35, 1393821197);
	}

	public void DA(int i, Class_ta class_ta, int i_287_, int i_288_) {
		Class_ta_Sub1 class_ta_sub1 = (Class_ta_Sub1) class_ta;
		Class30_Sub2_Sub1 class30_sub2_sub1 = ((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441;
		method5251();
		method5256(((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441);
		method5266(1);
		method5258(7681, 8448);
		method5259(0, 34167, 768);
		float f = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9049
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9048);
		float f_289_ = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9051
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9047);
		OpenGL.glColor4ub((byte) (i >> 16), (byte) (i >> 8), (byte) i, (byte) (i >> 24));
		OpenGL.glBegin(7);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8081 - i_287_),
				f_289_ * (float) (((GLToolkit) this).anInt8109 - i_288_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8081, ((GLToolkit) this).anInt8109);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8081 - i_287_),
				f_289_ * (float) (((GLToolkit) this).anInt8059 - i_288_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8081, ((GLToolkit) this).anInt8059);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8024 - i_287_),
				f_289_ * (float) (((GLToolkit) this).anInt8059 - i_288_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8024, ((GLToolkit) this).anInt8059);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8024 - i_287_),
				f_289_ * (float) (((GLToolkit) this).anInt8109 - i_288_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8024, ((GLToolkit) this).anInt8109);
		OpenGL.glEnd();
		method5259(0, 5890, 768);
	}

	final synchronized void deleteProg(int i) {
		Class298 class298 = new Class298();
		class298.hash = (long) i * 4191220306876042991L;
		((GLToolkit) this).deletePrograms.method5968(class298, 577290901);
	}

	public void method5061(boolean bool) {
		/* empty */
	}

	static {
		aFloatArray8017 = new float[4];
	}

	public int method5177() {
		return 4;
	}

	public Class58 method5063() {
		int i = -1;
		if (((GLToolkit) this).aString8022.indexOf("nvidia") != -1)
			i = 4318;
		else if (((GLToolkit) this).aString8022.indexOf("intel") != -1)
			i = 32902;
		else if (((GLToolkit) this).aString8022.indexOf("ati") != -1)
			i = 4098;
		return new Class58(i, "OpenGL", ((GLToolkit) this).anInt8101, ((GLToolkit) this).aString8162, 0L);
	}

	public int[] eg(int i, int i_290_, int i_291_, int i_292_) {
		if (aClass52_5292 != null) {
			int[] is = new int[i_291_ * i_292_];
			int i_293_ = aClass52_5292.method552();
			for (int i_294_ = 0; i_294_ < i_292_; i_294_++)
				OpenGL.glReadPixelsi(i, i_293_ - i_290_ - i_294_ - 1, i_291_, 1, 32993, ((GLToolkit) this).anInt8186,
						is, i_294_ * i_291_);
			return is;
		}
		return null;
	}

	void method5065(int i, int i_295_) throws Exception_Sub1 {
		try {
			aClass52_Sub2_5312.method580();
		} catch (Exception exception) {
			/* empty */
		}
		if (anInterface_ma5299 != null)
			anInterface_ma5299.method176(1384205509);
	}

	final void method5270() {
		if (((GLToolkit) this).anInt8080 != 4) {
			method5223();
			method5226(false);
			method5262(false);
			method5264(false);
			method5281(false);
			method5275(-2);
			method5266(1);
			((GLToolkit) this).anInt8080 = 4;
		}
	}

	public void method5067() {
		OpenGL.glFinish();
	}

	void method5009() {
		for (Class298 class298 = ((GLToolkit) this).aClass458_8067.method5967(
				1349337677); class298 != null; class298 = ((GLToolkit) this).aClass458_8067.method5969((byte) -2))
			((Class_v_Sub1) class298).method3674();
		if (((GLToolkit) this).aClass42_8055 != null)
			((GLToolkit) this).aClass42_8055.method486();
		if (((GLToolkit) this).aBoolean8065) {
			Class216.method2000(false, true, (short) 11532);
			((GLToolkit) this).aBoolean8065 = false;
		}
	}

	public final Class233 method5045() {
		return new Class233(((GLToolkit) this).aClass233_8041);
	}

	public final synchronized void method5174(int i) {
		int i_296_ = 0;
		i &= 0x7fffffff;
		while (!((GLToolkit) this).deleteBufferIds.method5970((byte) 96)) {
			Class298_Sub35 class298_sub35 = (Class298_Sub35) ((GLToolkit) this).deleteBufferIds.method5971(1817899200);
			anIntArray8079[i_296_++] = (int) (class298_sub35.hash * 7051297995265073167L);
			((GLToolkit) this).anInt8112 -= class298_sub35.anInt7394 * -774922497;
			if (i_296_ == 1000) {
				OpenGL.glDeleteBuffersARB(i_296_, anIntArray8079, 0);
				i_296_ = 0;
			}
		}
		if (i_296_ > 0) {
			OpenGL.glDeleteBuffersARB(i_296_, anIntArray8079, 0);
			i_296_ = 0;
		}
		while (!((GLToolkit) this).deleteTextureIds.method5970((byte) 53)) {
			Class298_Sub35 class298_sub35 = (Class298_Sub35) ((GLToolkit) this).deleteTextureIds.method5971(1913013745);
			anIntArray8079[i_296_++] = (int) (class298_sub35.hash * 7051297995265073167L);
			((GLToolkit) this).anInt8175 -= class298_sub35.anInt7394 * -774922497;
			if (i_296_ == 1000) {
				OpenGL.glDeleteTextures(i_296_, anIntArray8079, 0);
				i_296_ = 0;
			}
		}
		if (i_296_ > 0) {
			OpenGL.glDeleteTextures(i_296_, anIntArray8079, 0);
			i_296_ = 0;
		}
		while (!((GLToolkit) this).deleteFrameBuffers.method5970((byte) 47)) {
			Class298_Sub35 class298_sub35 = (Class298_Sub35) ((GLToolkit) this).deleteFrameBuffers
					.method5971(1781470933);
			anIntArray8079[i_296_++] = class298_sub35.anInt7394 * -774922497;
			if (i_296_ == 1000) {
				OpenGL.glDeleteFramebuffersEXT(i_296_, anIntArray8079, 0);
				i_296_ = 0;
			}
		}
		if (i_296_ > 0) {
			OpenGL.glDeleteFramebuffersEXT(i_296_, anIntArray8079, 0);
			i_296_ = 0;
		}
		while (!((GLToolkit) this).deleteRenderBuffers.method5970((byte) 74)) {
			Class298_Sub35 class298_sub35 = (Class298_Sub35) ((GLToolkit) this).deleteRenderBuffers
					.method5971(1659174916);
			anIntArray8079[i_296_++] = (int) (class298_sub35.hash * 7051297995265073167L);
			((GLToolkit) this).anInt8070 -= class298_sub35.anInt7394 * -774922497;
			if (i_296_ == 1000) {
				OpenGL.glDeleteRenderbuffersEXT(i_296_, anIntArray8079, 0);
				i_296_ = 0;
			}
		}
		if (i_296_ > 0) {
			OpenGL.glDeleteRenderbuffersEXT(i_296_, anIntArray8079, 0);
			boolean bool = false;
		}
		while (!((GLToolkit) this).deleteLists.method5970((byte) 66)) {
			Class298_Sub35 class298_sub35 = (Class298_Sub35) ((GLToolkit) this).deleteLists.method5971(1908940488);
			OpenGL.glDeleteLists((int) (class298_sub35.hash * 7051297995265073167L),
					class298_sub35.anInt7394 * -774922497);
		}
		while (!((GLToolkit) this).deletePrograms.method5970((byte) 73)) {
			Class298 class298 = ((GLToolkit) this).deletePrograms.method5971(1809693478);
			OpenGL.glDeleteProgramARB((int) (class298.hash * 7051297995265073167L));
		}
		while (!((GLToolkit) this).deleteShaders.method5970((byte) 40)) {
			Class298 class298 = ((GLToolkit) this).deleteShaders.method5971(1808532873);
			OpenGL.glDeleteShader((int) (class298.hash * 7051297995265073167L));
		}
		while (!((GLToolkit) this).deleteLists.method5970((byte) 94)) {
			Class298_Sub35 class298_sub35 = (Class298_Sub35) ((GLToolkit) this).deleteLists.method5971(1903219721);
			OpenGL.glDeleteLists((int) (class298_sub35.hash * 7051297995265073167L),
					class298_sub35.anInt7394 * -774922497);
		}
		((GLToolkit) this).aClass61_8052.method717();
		if (za() > 100663296 && (Class122.method1319((byte) 1) > ((GLToolkit) this).aLong8078 + 60000L)) {
			System.gc();
			((GLToolkit) this).aLong8078 = Class122.method1319((byte) 1);
		}
		((GLToolkit) this).anInt8062 = i;
	}

	public final int dm() {
		return (((GLToolkit) this).anInt8112 + ((GLToolkit) this).anInt8175 + ((GLToolkit) this).anInt8070);
	}

	public final int du() {
		return (((GLToolkit) this).anInt8112 + ((GLToolkit) this).anInt8175 + ((GLToolkit) this).anInt8070);
	}

	public boolean method5070() {
		return true;
	}

	public boolean method5071() {
		return true;
	}

	public final Class233 method5172() {
		return new Class233(((GLToolkit) this).aClass233_8041);
	}

	public void method5093(int i, int i_297_, int i_298_, int i_299_, int i_300_, int i_301_) {
		float f = (float) i + 0.35F;
		float f_302_ = (float) i_297_ + 0.35F;
		float f_303_ = f + (float) i_298_ - 1.0F;
		float f_304_ = f_302_ + (float) i_299_ - 1.0F;
		method5250();
		method5266(i_301_);
		OpenGL.glColor4ub((byte) (i_300_ >> 16), (byte) (i_300_ >> 8), (byte) i_300_, (byte) (i_300_ >> 24));
		if (((GLToolkit) this).aBoolean8173)
			OpenGL.glDisable(32925);
		OpenGL.glBegin(2);
		OpenGL.glVertex2f(f, f_302_);
		OpenGL.glVertex2f(f, f_304_);
		OpenGL.glVertex2f(f_303_, f_304_);
		OpenGL.glVertex2f(f_303_, f_302_);
		OpenGL.glEnd();
		if (((GLToolkit) this).aBoolean8173)
			OpenGL.glEnable(32925);
	}

	public boolean method5081() {
		return true;
	}

	public Sprite method5029(int i, int i_305_, boolean bool, boolean bool_306_) {
		return new Class57_Sub3(this, i, i_305_, bool);
	}

	public final boolean method5146() {
		return (((GLToolkit) this).aClass298_Sub8_Sub1_8056 != null
				&& ((GLToolkit) this).aClass298_Sub8_Sub1_8056.method2886());
	}

	public boolean method5076() {
		return (((GLToolkit) this).aBoolean8173 && (!method5054() || ((GLToolkit) this).aBoolean8174));
	}

	public boolean method5077() {
		return (((GLToolkit) this).aBoolean8173 && (!method5054() || ((GLToolkit) this).aBoolean8174));
	}

	public boolean method5078() {
		return true;
	}

	public boolean method5079() {
		return true;
	}

	public boolean method4994() {
		return true;
	}

	public boolean method5001() {
		return true;
	}

	public void method5012(boolean bool) {
		/* empty */
	}

	public void method5085(boolean bool) {
		/* empty */
	}

	Class52_Sub2 method5117(Canvas canvas, int i, int i_307_) {
		return new Class52_Sub2_Sub3(this, canvas);
	}

	public int[] ev(int i, int i_308_, int i_309_, int i_310_) {
		if (aClass52_5292 != null) {
			int[] is = new int[i_309_ * i_310_];
			int i_311_ = aClass52_5292.method552();
			for (int i_312_ = 0; i_312_ < i_310_; i_312_++)
				OpenGL.glReadPixelsi(i, i_311_ - i_308_ - i_312_ - 1, i_309_, 1, 32993, ((GLToolkit) this).anInt8186,
						is, i_312_ * i_309_);
			return is;
		}
		return null;
	}

	public Sprite method5190(int[] is, int i, int i_313_, int i_314_, int i_315_, boolean bool) {
		return new Class57_Sub3(this, i_314_, i_315_, is, i, i_313_);
	}

	final void method5271() {
		if (((GLToolkit) this).aBoolean8090) {
			OpenGL.glMatrixMode(5890);
			OpenGL.glLoadIdentity();
			OpenGL.glMatrixMode(5888);
			((GLToolkit) this).aBoolean8090 = false;
		}
	}

	public void em(boolean bool) {
		((GLToolkit) this).aBoolean8108 = bool;
		method5265();
	}

	final synchronized void deleteShad(long l) {
		Class298 class298 = new Class298();
		class298.hash = l * 4191220306876042991L;
		((GLToolkit) this).deleteShaders.method5968(class298, 1529923054);
	}

	public void method5086() {
		((GLToolkit) this).anInt8115 = 0;
		((GLToolkit) this).anInt8194 = 0;
		((GLToolkit) this).anInt8117 = aClass52_5292.method545();
		((GLToolkit) this).anInt8180 = aClass52_5292.method552();
		method5231();
	}

	public void ey(float f, float f_316_) {
		((GLToolkit) this).aFloat8099 = f;
		((GLToolkit) this).aFloat8100 = f_316_;
		method5276();
	}

	public void ez(float f, float f_317_) {
		((GLToolkit) this).aFloat8099 = f;
		((GLToolkit) this).aFloat8100 = f_317_;
		method5276();
	}

	public final void eq() {
		if (aClass52_5292 != null) {
			((GLToolkit) this).anInt8081 = 0;
			((GLToolkit) this).anInt8109 = 0;
			((GLToolkit) this).anInt8024 = aClass52_5292.method545();
			((GLToolkit) this).anInt8059 = aClass52_5292.method552();
			OpenGL.glDisable(3089);
		}
	}

	void method5141() {
		for (Class298 class298 = ((GLToolkit) this).aClass458_8067.method5967(
				1553115518); class298 != null; class298 = ((GLToolkit) this).aClass458_8067.method5969((byte) -25))
			((Class_v_Sub1) class298).method3674();
		if (((GLToolkit) this).aClass42_8055 != null)
			((GLToolkit) this).aClass42_8055.method486();
		if (((GLToolkit) this).aBoolean8065) {
			Class216.method2000(false, true, (short) -1007);
			((GLToolkit) this).aBoolean8065 = false;
		}
	}

	public final void ei() {
		if (aClass52_5292 != null) {
			((GLToolkit) this).anInt8081 = 0;
			((GLToolkit) this).anInt8109 = 0;
			((GLToolkit) this).anInt8024 = aClass52_5292.method545();
			((GLToolkit) this).anInt8059 = aClass52_5292.method552();
			OpenGL.glDisable(3089);
		}
	}

	public final void ej(int i, int i_318_, int i_319_, int i_320_) {
		if (aClass52_5292 != null) {
			if (i < 0)
				i = 0;
			if (i_319_ > aClass52_5292.method545())
				i_319_ = aClass52_5292.method545();
			if (i_318_ < 0)
				i_318_ = 0;
			if (i_320_ > aClass52_5292.method552())
				i_320_ = aClass52_5292.method552();
			((GLToolkit) this).anInt8081 = i;
			((GLToolkit) this).anInt8109 = i_318_;
			((GLToolkit) this).anInt8024 = i_319_;
			((GLToolkit) this).anInt8059 = i_320_;
			OpenGL.glEnable(3089);
			method5232();
		}
	}

	public final void ed(int i, int i_321_, int i_322_, int i_323_) {
		if (aClass52_5292 != null) {
			if (i < 0)
				i = 0;
			if (i_322_ > aClass52_5292.method545())
				i_322_ = aClass52_5292.method545();
			if (i_321_ < 0)
				i_321_ = 0;
			if (i_323_ > aClass52_5292.method552())
				i_323_ = aClass52_5292.method552();
			((GLToolkit) this).anInt8081 = i;
			((GLToolkit) this).anInt8109 = i_321_;
			((GLToolkit) this).anInt8024 = i_322_;
			((GLToolkit) this).anInt8059 = i_323_;
			OpenGL.glEnable(3089);
			method5232();
		}
	}

	public final void ea(int i, int i_324_, int i_325_, int i_326_) {
		if (((GLToolkit) this).anInt8081 < i)
			((GLToolkit) this).anInt8081 = i;
		if (((GLToolkit) this).anInt8024 > i_325_)
			((GLToolkit) this).anInt8024 = i_325_;
		if (((GLToolkit) this).anInt8109 < i_324_)
			((GLToolkit) this).anInt8109 = i_324_;
		if (((GLToolkit) this).anInt8059 > i_326_)
			((GLToolkit) this).anInt8059 = i_326_;
		OpenGL.glEnable(3089);
		method5232();
	}

	public final void eh(int i, int i_327_, int i_328_, int i_329_) {
		if (((GLToolkit) this).anInt8081 < i)
			((GLToolkit) this).anInt8081 = i;
		if (((GLToolkit) this).anInt8024 > i_328_)
			((GLToolkit) this).anInt8024 = i_328_;
		if (((GLToolkit) this).anInt8109 < i_327_)
			((GLToolkit) this).anInt8109 = i_327_;
		if (((GLToolkit) this).anInt8059 > i_329_)
			((GLToolkit) this).anInt8059 = i_329_;
		OpenGL.glEnable(3089);
		method5232();
	}

	GLToolkit(Canvas canvas, Interface_ma interface_ma, int i) {
		super(interface_ma);
		((GLToolkit) this).aClass34_8057 = new Class34();
		((GLToolkit) this).aClass233_8058 = new Class233();
		((GLToolkit) this).aClass233_8030 = new Class233();
		((GLToolkit) this).aClass222_8060 = new Class222();
		((GLToolkit) this).anInt8063 = 8;
		((GLToolkit) this).anInt8064 = 3;
		((GLToolkit) this).aBoolean8065 = false;
		((GLToolkit) this).aClass458_8067 = new Class458();
		((GLToolkit) this).deleteLists = new Class458();
		((GLToolkit) this).deleteBufferIds = new Class458();
		((GLToolkit) this).deleteTextureIds = new Class458();
		((GLToolkit) this).deleteFrameBuffers = new Class458();
		((GLToolkit) this).deleteRenderBuffers = new Class458();
		((GLToolkit) this).deletePrograms = new Class458();
		((GLToolkit) this).deleteShaders = new Class458();
		((GLToolkit) this).aClass222_8087 = new Class222();
		((GLToolkit) this).aClass233_8110 = new Class233();
		((GLToolkit) this).aClass233_8089 = new Class233();
		((GLToolkit) this).aClass233_8041 = new Class233();
		((GLToolkit) this).aClass233_8091 = new Class233();
		((GLToolkit) this).aClass233_8069 = new Class233();
		((GLToolkit) this).aFloatArrayArray8077 = new float[6][4];
		((GLToolkit) this).aFloatArray8094 = new float[4];
		((GLToolkit) this).aFloat8099 = 0.0F;
		((GLToolkit) this).aFloat8100 = 1.0F;
		((GLToolkit) this).aFloat8134 = 0.0F;
		((GLToolkit) this).aFloat8102 = -1.0F;
		((GLToolkit) this).aClass222_8103 = new Class222();
		((GLToolkit) this).aClass233_8104 = new Class233();
		((GLToolkit) this).aClass233_8184 = new Class233();
		((GLToolkit) this).aFloatArray8106 = new float[16];
		((GLToolkit) this).aBoolean8108 = true;
		((GLToolkit) this).anInt8109 = 0;
		((GLToolkit) this).anInt8059 = 0;
		((GLToolkit) this).anInt8081 = 0;
		((GLToolkit) this).anInt8024 = 0;
		((GLToolkit) this).anInt8113 = 0;
		((GLToolkit) this).anInt8114 = 0;
		((GLToolkit) this).aFloatArray8122 = new float[4];
		((GLToolkit) this).aFloatArray8123 = new float[4];
		((GLToolkit) this).aFloatArray8124 = new float[4];
		((GLToolkit) this).aFloatArray8157 = new float[4];
		((GLToolkit) this).anInt8033 = -1;
		((GLToolkit) this).aFloat8125 = 1.0F;
		((GLToolkit) this).aFloat8128 = 1.0F;
		((GLToolkit) this).aFloat8191 = 1.0F;
		((GLToolkit) this).aFloat8131 = -1.0F;
		((GLToolkit) this).aFloat8132 = -1.0F;
		((GLToolkit) this).aClass298_Sub10Array8164 = new Class298_Sub10[anInt8119];
		((GLToolkit) this).anInt8139 = -1;
		((GLToolkit) this).anInt8007 = -1;
		((GLToolkit) this).anInt8195 = 0;
		((GLToolkit) this).aFloat8144 = 1.0F;
		((GLToolkit) this).aFloat8145 = 0.0F;
		((GLToolkit) this).aBoolean8147 = false;
		((GLToolkit) this).anInt8136 = 8448;
		((GLToolkit) this).anInt8010 = 8448;
		((GLToolkit) this).aFloat8187 = -1.0F;
		((GLToolkit) this).aFloat8188 = -1.0F;
		((GLToolkit) this).aClass387_Sub2Array8189 = new OpenGLModel[7];
		((GLToolkit) this).aClass387_Sub2Array8084 = new OpenGLModel[7];
		((GLToolkit) this).aClass298_Sub53_Sub1_8197 = new RsFloatBuffer(8192);
		((GLToolkit) this).anIntArray8198 = new int[1];
		((GLToolkit) this).anIntArray8199 = new int[1];
		((GLToolkit) this).anIntArray8200 = new int[1];
		((GLToolkit) this).aByteArray8201 = new byte[16384];
		try {
			((GLToolkit) this).anInt8051 = i;
			if (!EmitterConfig.method955(1106914335).method265("jaclib", 2057615026))
				throw new RuntimeException("");
			if (!EmitterConfig.method955(-921527498).method265("jaggl", -949360058))
				throw new RuntimeException("");
			((GLToolkit) this).anOpenGL8116 = new OpenGL();
			long l = ((GLToolkit) this).anOpenGL8116.init(canvas, 8, 8, 8, 24, 0, ((GLToolkit) this).anInt8051);
			if (l == 0L)
				throw new RuntimeException("");
			method5220();
			int i_330_ = method5221();
			if (i_330_ != 0)
				throw new RuntimeException("");
			((GLToolkit) this).anInt8186 = ((GLToolkit) this).aBoolean8143 ? 33639 : 5121;
			if (((GLToolkit) this).aString8162.indexOf("radeon") != -1) {
				int i_331_ = 0;
				boolean bool = false;
				boolean bool_332_ = false;
				String[] strings = (Class365_Sub1_Sub3_Sub1.method4508(((GLToolkit) this).aString8162.replace('/', ' '),
						' ', 1272064462));
				for (int i_333_ = 0; i_333_ < strings.length; i_333_++) {
					String string = strings[i_333_];
					try {
						if (string.length() <= 0)
							continue;
						if (string.charAt(0) == 'x' && string.length() >= 3
								&& Class51.method543(string.substring(1, 3), 1705722610)) {
							string = string.substring(1);
							bool_332_ = true;
						}
						if (string.equals("hd")) {
							bool = true;
							continue;
						}
						if (string.startsWith("hd")) {
							string = string.substring(2);
							bool = true;
						}
						if (string.length() < 4 || !Class51.method543(string.substring(0, 4), 1971957735))
							continue;
						i_331_ = Class216.method1998(string.substring(0, 4), (short) -25254);
					} catch (Exception exception) {
						continue;
					}
					break;
				}
				if (!bool_332_ && !bool) {
					if (i_331_ >= 7000 && i_331_ <= 7999)
						((GLToolkit) this).aBoolean8126 = false;
					if (i_331_ >= 7000 && i_331_ <= 9250)
						((GLToolkit) this).tex3d = false;
				}
				if (!bool || i_331_ < 4000)
					((GLToolkit) this).texture_float = false;
				((GLToolkit) this).aBoolean8179 &= ((GLToolkit) this).anOpenGL8116.a("GL_ARB_half_float_pixel");
				((GLToolkit) this).aBoolean8176 = ((GLToolkit) this).aBoolean8126;
				((GLToolkit) this).aBoolean8172 = true;
			}
			if (((GLToolkit) this).aString8022.indexOf("intel") != -1)
				((GLToolkit) this).framebuffer_obj = false;
			((GLToolkit) this).aBoolean8185 = !((GLToolkit) this).aString8022.equals("s3 graphics");
			if (((GLToolkit) this).aBoolean8126) {
				try {
					int[] is = new int[1];
					OpenGL.glGenBuffersARB(1, is, 0);
				} catch (Throwable throwable) {
					throw new RuntimeException("");
				}
			}
			Class374_Sub1.method4640(false, true, -162450455);
			((GLToolkit) this).aBoolean8065 = true;
			((GLToolkit) this).aClass61_8052 = new Class61(this, anInterface_ma5299);
			method5222();
			((GLToolkit) this).aClass49_8061 = new Class49(this);
			((GLToolkit) this).aClass42_8055 = new Class42(this);
			if (((GLToolkit) this).aClass42_8055.method482()) {
				((GLToolkit) this).aClass298_Sub8_Sub1_8056 = new Class298_Sub8_Sub1(this);
				if (!((GLToolkit) this).aClass298_Sub8_Sub1_8056.method2890()) {
					((GLToolkit) this).aClass298_Sub8_Sub1_8056.method2870();
					((GLToolkit) this).aClass298_Sub8_Sub1_8056 = null;
				}
			}
			method5151(canvas, new Class52_Sub2_Sub3(this, canvas, l), (byte) 26);
			method5003(canvas, (byte) -7);
			((GLToolkit) this).aClass27_8054 = new Class27(this);
			method5282();
			method5176();
		} catch (Throwable throwable) {
			throwable.printStackTrace();
			method5136(1149922694);
			if (throwable instanceof OutOfMemoryError)
				throw (OutOfMemoryError) throwable;
			throw new RuntimeException("");
		}
	}

	public final void eo(int[] is) {
		is[0] = ((GLToolkit) this).anInt8081;
		is[1] = ((GLToolkit) this).anInt8109;
		is[2] = ((GLToolkit) this).anInt8024;
		is[3] = ((GLToolkit) this).anInt8059;
	}

	public final void er(int[] is) {
		is[0] = ((GLToolkit) this).anInt8081;
		is[1] = ((GLToolkit) this).anInt8109;
		is[2] = ((GLToolkit) this).anInt8024;
		is[3] = ((GLToolkit) this).anInt8059;
	}

	public void method5096(int i, int i_334_, int i_335_, int i_336_, int i_337_, int i_338_, Class_ta class_ta,
			int i_339_, int i_340_) {
		Class_ta_Sub1 class_ta_sub1 = (Class_ta_Sub1) class_ta;
		Class30_Sub2_Sub1 class30_sub2_sub1 = ((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441;
		method5251();
		method5256(((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441);
		method5266(i_338_);
		method5258(7681, 8448);
		method5259(0, 34167, 768);
		float f = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9049
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9048);
		float f_341_ = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9051
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9047);
		float f_342_ = (float) i_335_ - (float) i;
		float f_343_ = (float) i_336_ - (float) i_334_;
		float f_344_ = (float) (1.0 / Math.sqrt((double) (f_342_ * f_342_ + f_343_ * f_343_)));
		f_342_ *= f_344_;
		f_343_ *= f_344_;
		OpenGL.glColor4ub((byte) (i_337_ >> 16), (byte) (i_337_ >> 8), (byte) i_337_, (byte) (i_337_ >> 24));
		OpenGL.glBegin(1);
		OpenGL.glTexCoord2f(f * (float) (i - i_339_), f_341_ * (float) (i_334_ - i_340_));
		OpenGL.glVertex2f((float) i + 0.35F, (float) i_334_ + 0.35F);
		OpenGL.glTexCoord2f(f * (float) (i_335_ - i_339_), f_341_ * (float) (i_336_ - i_340_));
		OpenGL.glVertex2f((float) i_335_ + f_342_ + 0.35F, (float) i_336_ + f_343_ + 0.35F);
		OpenGL.glEnd();
		method5259(0, 5890, 768);
	}

	public void fb(int i, int i_345_) {
		int i_346_ = 0;
		if ((i & 0x1) != 0) {
			OpenGL.glClearColor((float) (i_345_ & 0xff0000) / 1.671168E7F, (float) (i_345_ & 0xff00) / 65280.0F,
					(float) (i_345_ & 0xff) / 255.0F, (float) (i_345_ >>> 24) / 255.0F);
			i_346_ = 16384;
		}
		if ((i & 0x2) != 0) {
			method5281(true);
			i_346_ |= 0x100;
		}
		if ((i & 0x4) != 0)
			i_346_ |= 0x400;
		OpenGL.glClear(i_346_);
	}

	public void method5011() {
		((GLToolkit) this).anInt8115 = 0;
		((GLToolkit) this).anInt8194 = 0;
		((GLToolkit) this).anInt8117 = aClass52_5292.method545();
		((GLToolkit) this).anInt8180 = aClass52_5292.method552();
		method5231();
	}

	public void fn(int i, int i_347_) {
		int i_348_ = 0;
		if ((i & 0x1) != 0) {
			OpenGL.glClearColor((float) (i_347_ & 0xff0000) / 1.671168E7F, (float) (i_347_ & 0xff00) / 65280.0F,
					(float) (i_347_ & 0xff) / 255.0F, (float) (i_347_ >>> 24) / 255.0F);
			i_348_ = 16384;
		}
		if ((i & 0x2) != 0) {
			method5281(true);
			i_348_ |= 0x100;
		}
		if ((i & 0x4) != 0)
			i_348_ |= 0x400;
		OpenGL.glClear(i_348_);
	}

	public int method5024(int i, int i_349_) {
		return i & i_349_ ^ i_349_;
	}

	public Interface8_Impl1_Impl2 method5186(int i, int i_350_) {
		return new Class298_Sub37_Sub18(this, Class55.aClass55_561, Class77.aClass77_719, i, i_350_);
	}

	public final void L() {
		if (aClass52_5292 != null) {
			((GLToolkit) this).anInt8081 = 0;
			((GLToolkit) this).anInt8109 = 0;
			((GLToolkit) this).anInt8024 = aClass52_5292.method545();
			((GLToolkit) this).anInt8059 = aClass52_5292.method552();
			OpenGL.glDisable(3089);
		}
	}

	public void fi(int i, int i_351_, int i_352_, int i_353_, int i_354_, int i_355_, byte[] is, int i_356_,
			int i_357_) {
		float f;
		float f_358_;
		if (((GLToolkit) this).aClass30_Sub2_Sub1_8111 == null
				|| (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).anInt6746 < i_352_)
				|| (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).anInt6747 < i_353_)) {
			((GLToolkit) this).aClass30_Sub2_Sub1_8111 = Class30_Sub2_Sub1.method428(this, Class55.aClass55_567,
					Class77.aClass77_717, i_352_, i_353_, false, is, Class55.aClass55_567);
			((GLToolkit) this).aClass30_Sub2_Sub1_8111.method420(false, false);
			f = ((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).aFloat9051;
			f_358_ = ((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).aFloat9049;
		} else {
			((GLToolkit) this).aClass30_Sub2_Sub1_8111.method421(0, 0, i_352_, i_353_, is, Class55.aClass55_567, 0, 0,
					false);
			f = (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).aFloat9051 * (float) i_353_
					/ (float) (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).anInt6747));
			f_358_ = (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).aFloat9049 * (float) i_352_
					/ (float) (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).anInt6746));
		}
		method5251();
		method5256(((GLToolkit) this).aClass30_Sub2_Sub1_8111);
		method5266(i_357_);
		OpenGL.glColor4ub((byte) (i_354_ >> 16), (byte) (i_354_ >> 8), (byte) i_354_, (byte) (i_354_ >> 24));
		method5273(i_355_);
		method5258(34165, 34165);
		method5259(0, 34166, 768);
		method5259(2, 5890, 770);
		method5286(0, 34166, 770);
		method5286(2, 5890, 770);
		float f_359_ = (float) i;
		float f_360_ = (float) i_351_;
		float f_361_ = f_359_ + (float) i_352_;
		float f_362_ = f_360_ + (float) i_353_;
		OpenGL.glBegin(7);
		OpenGL.glTexCoord2f(0.0F, 0.0F);
		OpenGL.glVertex2f(f_359_, f_360_);
		OpenGL.glTexCoord2f(0.0F, f_358_);
		OpenGL.glVertex2f(f_359_, f_362_);
		OpenGL.glTexCoord2f(f, f_358_);
		OpenGL.glVertex2f(f_361_, f_362_);
		OpenGL.glTexCoord2f(f, 0.0F);
		OpenGL.glVertex2f(f_361_, f_360_);
		OpenGL.glEnd();
		method5259(0, 5890, 768);
		method5259(2, 34166, 770);
		method5286(0, 5890, 770);
		method5286(2, 34166, 770);
	}

	void fm(int i, int i_363_, int i_364_, int i_365_, int i_366_) {
		if (i_364_ < 0)
			i_364_ = -i_364_;
		if (i + i_364_ >= ((GLToolkit) this).anInt8081 && i - i_364_ <= ((GLToolkit) this).anInt8024
				&& i_363_ + i_364_ >= ((GLToolkit) this).anInt8109 && i_363_ - i_364_ <= ((GLToolkit) this).anInt8059) {
			method5250();
			method5266(i_366_);
			OpenGL.glColor4ub((byte) (i_365_ >> 16), (byte) (i_365_ >> 8), (byte) i_365_, (byte) (i_365_ >> 24));
			float f = (float) i + 0.35F;
			float f_367_ = (float) i_363_ + 0.35F;
			int i_368_ = i_364_ << 1;
			if ((float) i_368_ < ((GLToolkit) this).aFloat8188) {
				OpenGL.glBegin(7);
				OpenGL.glVertex2f(f + 1.0F, f_367_ + 1.0F);
				OpenGL.glVertex2f(f + 1.0F, f_367_ - 1.0F);
				OpenGL.glVertex2f(f - 1.0F, f_367_ - 1.0F);
				OpenGL.glVertex2f(f - 1.0F, f_367_ + 1.0F);
				OpenGL.glEnd();
			} else if ((float) i_368_ <= ((GLToolkit) this).aFloat8187) {
				OpenGL.glEnable(2832);
				OpenGL.glPointSize((float) i_368_);
				OpenGL.glBegin(0);
				OpenGL.glVertex2f(f, f_367_);
				OpenGL.glEnd();
				OpenGL.glDisable(2832);
			} else {
				OpenGL.glBegin(6);
				OpenGL.glVertex2f(f, f_367_);
				int i_369_ = 262144 / (6 * i_364_);
				if (i_369_ <= 64)
					i_369_ = 64;
				else if (i_369_ > 512)
					i_369_ = 512;
				i_369_ = Class422_Sub4.method5639(i_369_, 1068867591);
				OpenGL.glVertex2f(f + (float) i_364_, f_367_);
				for (int i_370_ = 16384 - i_369_; i_370_ > 0; i_370_ -= i_369_)
					OpenGL.glVertex2f(f + (Class35.aFloatArray417[i_370_] * (float) i_364_),
							f_367_ + (Class35.aFloatArray418[i_370_] * (float) i_364_));
				OpenGL.glVertex2f(f + (float) i_364_, f_367_);
				OpenGL.glEnd();
			}
		}
	}

	public void ff(int i, int i_371_, int i_372_, int i_373_, int i_374_) {
		method5250();
		method5266(i_374_);
		float f = (float) i + 0.35F;
		float f_375_ = (float) i_371_ + 0.35F;
		OpenGL.glColor4ub((byte) (i_373_ >> 16), (byte) (i_373_ >> 8), (byte) i_373_, (byte) (i_373_ >> 24));
		OpenGL.glBegin(1);
		OpenGL.glVertex2f(f, f_375_);
		OpenGL.glVertex2f(f + (float) i_372_, f_375_);
		OpenGL.glEnd();
	}

	public Class264 method5114(Class505 class505, IndexedImage[] class89s, boolean bool) {
		return new Class264_Sub3(this, class505, class89s, bool);
	}

	public void ft(int i, int i_376_, int i_377_, int i_378_, int i_379_) {
		method5250();
		method5266(i_379_);
		float f = (float) i + 0.35F;
		float f_380_ = (float) i_376_ + 0.35F;
		OpenGL.glColor4ub((byte) (i_378_ >> 16), (byte) (i_378_ >> 8), (byte) i_378_, (byte) (i_378_ >> 24));
		OpenGL.glBegin(1);
		OpenGL.glVertex2f(f, f_380_);
		OpenGL.glVertex2f(f, f_380_ + (float) i_377_);
		OpenGL.glEnd();
	}

	public void fl(int i, int i_381_, int i_382_, int i_383_, int i_384_) {
		method5250();
		method5266(i_384_);
		float f = (float) i + 0.35F;
		float f_385_ = (float) i_381_ + 0.35F;
		OpenGL.glColor4ub((byte) (i_383_ >> 16), (byte) (i_383_ >> 8), (byte) i_383_, (byte) (i_383_ >> 24));
		OpenGL.glBegin(1);
		OpenGL.glVertex2f(f, f_385_);
		OpenGL.glVertex2f(f, f_385_ + (float) i_382_);
		OpenGL.glEnd();
	}

	public void method5038(int i, int i_386_, int i_387_, int i_388_, int i_389_, int i_390_, int i_391_, int i_392_,
			int i_393_) {
		if (i != i_387_ || i_386_ != i_388_) {
			method5250();
			method5266(i_390_);
			float f = (float) i_387_ - (float) i;
			float f_394_ = (float) i_388_ - (float) i_386_;
			float f_395_ = (float) (1.0 / Math.sqrt((double) (f * f + f_394_ * f_394_)));
			f *= f_395_;
			f_394_ *= f_395_;
			OpenGL.glColor4ub((byte) (i_389_ >> 16), (byte) (i_389_ >> 8), (byte) i_389_, (byte) (i_389_ >> 24));
			i_393_ %= i_392_ + i_391_;
			float f_396_ = f * (float) i_391_;
			float f_397_ = f_394_ * (float) i_391_;
			float f_398_ = 0.0F;
			float f_399_ = 0.0F;
			float f_400_ = f_396_;
			float f_401_ = f_397_;
			if (i_393_ > i_391_) {
				f_398_ = f * (float) (i_391_ + i_392_ - i_393_);
				f_399_ = f_394_ * (float) (i_391_ + i_392_ - i_393_);
			} else {
				f_400_ = f * (float) (i_391_ - i_393_);
				f_401_ = f_394_ * (float) (i_391_ - i_393_);
			}
			float f_402_ = (float) i + 0.35F + f_398_;
			float f_403_ = (float) i_386_ + 0.35F + f_399_;
			float f_404_ = f * (float) i_392_;
			float f_405_ = f_394_ * (float) i_392_;
			for (;;) {
				if (i_387_ > i) {
					if (f_402_ > (float) i_387_ + 0.35F)
						break;
					if (f_402_ + f_400_ > (float) i_387_)
						f_400_ = (float) i_387_ - f_402_;
				} else {
					if (f_402_ < (float) i_387_ + 0.35F)
						break;
					if (f_402_ + f_400_ < (float) i_387_)
						f_400_ = (float) i_387_ - f_402_;
				}
				if (i_388_ > i_386_) {
					if (f_403_ > (float) i_388_ + 0.35F)
						break;
					if (f_403_ + f_401_ > (float) i_388_)
						f_401_ = (float) i_388_ - f_403_;
				} else {
					if (f_403_ < (float) i_388_ + 0.35F)
						break;
					if (f_403_ + f_401_ < (float) i_388_)
						f_401_ = (float) i_388_ - f_403_;
				}
				OpenGL.glBegin(1);
				OpenGL.glVertex2f(f_402_, f_403_);
				OpenGL.glVertex2f(f_402_ + f_400_, f_403_ + f_401_);
				OpenGL.glEnd();
				f_402_ += f_404_ + f_400_;
				f_403_ += f_405_ + f_401_;
				f_400_ = f_396_;
				f_401_ = f_397_;
			}
		}
	}

	public void method5088(int i, int i_406_, int i_407_, int i_408_, int i_409_, int i_410_, Class_ta class_ta,
			int i_411_, int i_412_) {
		Class_ta_Sub1 class_ta_sub1 = (Class_ta_Sub1) class_ta;
		Class30_Sub2_Sub1 class30_sub2_sub1 = ((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441;
		method5251();
		method5256(((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441);
		method5266(i_410_);
		method5258(7681, 8448);
		method5259(0, 34167, 768);
		float f = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9049
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9048);
		float f_413_ = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9051
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9047);
		float f_414_ = (float) i_407_ - (float) i;
		float f_415_ = (float) i_408_ - (float) i_406_;
		float f_416_ = (float) (1.0 / Math.sqrt((double) (f_414_ * f_414_ + f_415_ * f_415_)));
		f_414_ *= f_416_;
		f_415_ *= f_416_;
		OpenGL.glColor4ub((byte) (i_409_ >> 16), (byte) (i_409_ >> 8), (byte) i_409_, (byte) (i_409_ >> 24));
		OpenGL.glBegin(1);
		OpenGL.glTexCoord2f(f * (float) (i - i_411_), f_413_ * (float) (i_406_ - i_412_));
		OpenGL.glVertex2f((float) i + 0.35F, (float) i_406_ + 0.35F);
		OpenGL.glTexCoord2f(f * (float) (i_407_ - i_411_), f_413_ * (float) (i_408_ - i_412_));
		OpenGL.glVertex2f((float) i_407_ + f_414_ + 0.35F, (float) i_408_ + f_415_ + 0.35F);
		OpenGL.glEnd();
		method5259(0, 5890, 768);
	}

	public void XA(int i, int i_417_, int i_418_, int i_419_, int i_420_) {
		method5250();
		method5266(i_420_);
		float f = (float) i + 0.35F;
		float f_421_ = (float) i_417_ + 0.35F;
		OpenGL.glColor4ub((byte) (i_419_ >> 16), (byte) (i_419_ >> 8), (byte) i_419_, (byte) (i_419_ >> 24));
		OpenGL.glBegin(1);
		OpenGL.glVertex2f(f, f_421_);
		OpenGL.glVertex2f(f + (float) i_418_, f_421_);
		OpenGL.glEnd();
	}

	public void method5097(int i, int i_422_, int i_423_, int i_424_, int i_425_, int i_426_, Class_ta class_ta,
			int i_427_, int i_428_) {
		Class_ta_Sub1 class_ta_sub1 = (Class_ta_Sub1) class_ta;
		Class30_Sub2_Sub1 class30_sub2_sub1 = ((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441;
		method5251();
		method5256(((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441);
		method5266(i_426_);
		method5258(7681, 8448);
		method5259(0, 34167, 768);
		float f = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9049
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9048);
		float f_429_ = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9051
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9047);
		float f_430_ = (float) i_423_ - (float) i;
		float f_431_ = (float) i_424_ - (float) i_422_;
		float f_432_ = (float) (1.0 / Math.sqrt((double) (f_430_ * f_430_ + f_431_ * f_431_)));
		f_430_ *= f_432_;
		f_431_ *= f_432_;
		OpenGL.glColor4ub((byte) (i_425_ >> 16), (byte) (i_425_ >> 8), (byte) i_425_, (byte) (i_425_ >> 24));
		OpenGL.glBegin(1);
		OpenGL.glTexCoord2f(f * (float) (i - i_427_), f_429_ * (float) (i_422_ - i_428_));
		OpenGL.glVertex2f((float) i + 0.35F, (float) i_422_ + 0.35F);
		OpenGL.glTexCoord2f(f * (float) (i_423_ - i_427_), f_429_ * (float) (i_424_ - i_428_));
		OpenGL.glVertex2f((float) i_423_ + f_430_ + 0.35F, (float) i_424_ + f_431_ + 0.35F);
		OpenGL.glEnd();
		method5259(0, 5890, 768);
	}

	public void method5098(int i, int i_433_, int i_434_, int i_435_, int i_436_, int i_437_, Class_ta class_ta,
			int i_438_, int i_439_, int i_440_, int i_441_, int i_442_) {
		if (i != i_434_ || i_433_ != i_435_) {
			Class_ta_Sub1 class_ta_sub1 = (Class_ta_Sub1) class_ta;
			Class30_Sub2_Sub1 class30_sub2_sub1 = ((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441;
			method5251();
			method5256(((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441);
			method5266(i_437_);
			method5258(7681, 8448);
			method5259(0, 34167, 768);
			float f = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9049
					/ (float) (((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9048));
			float f_443_ = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9051
					/ (float) (((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9047));
			float f_444_ = (float) i_434_ - (float) i;
			float f_445_ = (float) i_435_ - (float) i_433_;
			float f_446_ = (float) (1.0 / Math.sqrt((double) (f_444_ * f_444_ + f_445_ * f_445_)));
			f_444_ *= f_446_;
			f_445_ *= f_446_;
			OpenGL.glColor4ub((byte) (i_436_ >> 16), (byte) (i_436_ >> 8), (byte) i_436_, (byte) (i_436_ >> 24));
			i_442_ %= i_441_ + i_440_;
			float f_447_ = f_444_ * (float) i_440_;
			float f_448_ = f_445_ * (float) i_440_;
			float f_449_ = 0.0F;
			float f_450_ = 0.0F;
			float f_451_ = f_447_;
			float f_452_ = f_448_;
			if (i_442_ > i_440_) {
				f_449_ = f_444_ * (float) (i_440_ + i_441_ - i_442_);
				f_450_ = f_445_ * (float) (i_440_ + i_441_ - i_442_);
			} else {
				f_451_ = f_444_ * (float) (i_440_ - i_442_);
				f_452_ = f_445_ * (float) (i_440_ - i_442_);
			}
			float f_453_ = (float) i + 0.35F + f_449_;
			float f_454_ = (float) i_433_ + 0.35F + f_450_;
			float f_455_ = f_444_ * (float) i_441_;
			float f_456_ = f_445_ * (float) i_441_;
			for (;;) {
				if (i_434_ > i) {
					if (f_453_ > (float) i_434_ + 0.35F)
						break;
					if (f_453_ + f_451_ > (float) i_434_)
						f_451_ = (float) i_434_ - f_453_;
				} else {
					if (f_453_ < (float) i_434_ + 0.35F)
						break;
					if (f_453_ + f_451_ < (float) i_434_)
						f_451_ = (float) i_434_ - f_453_;
				}
				if (i_435_ > i_433_) {
					if (f_454_ > (float) i_435_ + 0.35F)
						break;
					if (f_454_ + f_452_ > (float) i_435_)
						f_452_ = (float) i_435_ - f_454_;
				} else {
					if (f_454_ < (float) i_435_ + 0.35F)
						break;
					if (f_454_ + f_452_ < (float) i_435_)
						f_452_ = (float) i_435_ - f_454_;
				}
				OpenGL.glBegin(1);
				OpenGL.glTexCoord2f(f * (f_453_ - (float) i_438_), f_443_ * (f_454_ - (float) i_439_));
				OpenGL.glVertex2f(f_453_, f_454_);
				OpenGL.glTexCoord2f(f * (f_453_ + f_451_ - (float) i_438_),
						f_443_ * (f_454_ + f_452_ - (float) i_439_));
				OpenGL.glVertex2f(f_453_ + f_451_, f_454_ + f_452_);
				OpenGL.glEnd();
				f_453_ += f_455_ + f_451_;
				f_454_ += f_456_ + f_452_;
				f_451_ = f_447_;
				f_452_ = f_448_;
			}
			method5259(0, 5890, 768);
		}
	}

	public int method5099(int i, int i_457_, int i_458_, int i_459_, int i_460_, int i_461_) {
		int i_462_ = 0;
		float f = (((GLToolkit) this).aClass233_8069.aFloatArray2594[14]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[2] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[6] * (float) i_457_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[10] * (float) i_458_));
		float f_463_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[14]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[2] * (float) i_459_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[6] * (float) i_460_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[10] * (float) i_461_));
		float f_464_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * (float) i_457_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * (float) i_458_));
		float f_465_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * (float) i_459_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * (float) i_460_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * (float) i_461_));
		if (f < -f_464_ && f_463_ < -f_465_)
			i_462_ |= 0x10;
		else if (f > f_464_ && f_463_ > f_465_)
			i_462_ |= 0x20;
		float f_466_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * (float) i_457_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * (float) i_458_));
		float f_467_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * (float) i_459_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * (float) i_460_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * (float) i_461_));
		if (f_466_ < -f_464_ && f_467_ < -f_465_)
			i_462_ |= 0x1;
		if (f_466_ > f_464_ && f_467_ > f_465_)
			i_462_ |= 0x2;
		float f_468_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[13]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[1] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5] * (float) i_457_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9] * (float) i_458_));
		float f_469_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[13]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[1] * (float) i_459_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5] * (float) i_460_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9] * (float) i_461_));
		if (f_468_ < -f_464_ && f_469_ < -f_465_)
			i_462_ |= 0x4;
		if (f_468_ > f_464_ && f_469_ > f_465_)
			i_462_ |= 0x8;
		return i_462_;
	}

	public int method5100(int i, int i_470_, int i_471_, int i_472_, int i_473_, int i_474_) {
		int i_475_ = 0;
		float f = (((GLToolkit) this).aClass233_8069.aFloatArray2594[14]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[2] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[6] * (float) i_470_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[10] * (float) i_471_));
		float f_476_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[14]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[2] * (float) i_472_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[6] * (float) i_473_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[10] * (float) i_474_));
		float f_477_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * (float) i_470_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * (float) i_471_));
		float f_478_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * (float) i_472_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * (float) i_473_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * (float) i_474_));
		if (f < -f_477_ && f_476_ < -f_478_)
			i_475_ |= 0x10;
		else if (f > f_477_ && f_476_ > f_478_)
			i_475_ |= 0x20;
		float f_479_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * (float) i_470_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * (float) i_471_));
		float f_480_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * (float) i_472_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * (float) i_473_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * (float) i_474_));
		if (f_479_ < -f_477_ && f_480_ < -f_478_)
			i_475_ |= 0x1;
		if (f_479_ > f_477_ && f_480_ > f_478_)
			i_475_ |= 0x2;
		float f_481_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[13]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[1] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5] * (float) i_470_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9] * (float) i_471_));
		float f_482_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[13]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[1] * (float) i_472_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5] * (float) i_473_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9] * (float) i_474_));
		if (f_481_ < -f_477_ && f_482_ < -f_478_)
			i_475_ |= 0x4;
		if (f_481_ > f_477_ && f_482_ > f_478_)
			i_475_ |= 0x8;
		return i_475_;
	}

	public int method5135(int i, int i_483_, int i_484_, int i_485_, int i_486_, int i_487_) {
		int i_488_ = 0;
		float f = (((GLToolkit) this).aClass233_8069.aFloatArray2594[14]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[2] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[6] * (float) i_483_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[10] * (float) i_484_));
		float f_489_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[14]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[2] * (float) i_485_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[6] * (float) i_486_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[10] * (float) i_487_));
		float f_490_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * (float) i_483_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * (float) i_484_));
		float f_491_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * (float) i_485_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * (float) i_486_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * (float) i_487_));
		if (f < -f_490_ && f_489_ < -f_491_)
			i_488_ |= 0x10;
		else if (f > f_490_ && f_489_ > f_491_)
			i_488_ |= 0x20;
		float f_492_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * (float) i_483_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * (float) i_484_));
		float f_493_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * (float) i_485_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * (float) i_486_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * (float) i_487_));
		if (f_492_ < -f_490_ && f_493_ < -f_491_)
			i_488_ |= 0x1;
		if (f_492_ > f_490_ && f_493_ > f_491_)
			i_488_ |= 0x2;
		float f_494_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[13]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[1] * (float) i)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5] * (float) i_483_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9] * (float) i_484_));
		float f_495_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[13]
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[1] * (float) i_485_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5] * (float) i_486_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9] * (float) i_487_));
		if (f_494_ < -f_490_ && f_495_ < -f_491_)
			i_488_ |= 0x4;
		if (f_494_ > f_490_ && f_495_ > f_491_)
			i_488_ |= 0x8;
		return i_488_;
	}

	public Class_v method5102(int i) {
		Class_v_Sub1 class_v_sub1 = new Class_v_Sub1(i);
		((GLToolkit) this).aClass458_8067.method5968(class_v_sub1, 1583518091);
		return class_v_sub1;
	}

	public Class58 method5062() {
		int i = -1;
		if (((GLToolkit) this).aString8022.indexOf("nvidia") != -1)
			i = 4318;
		else if (((GLToolkit) this).aString8022.indexOf("intel") != -1)
			i = 32902;
		else if (((GLToolkit) this).aString8022.indexOf("ati") != -1)
			i = 4098;
		return new Class58(i, "OpenGL", ((GLToolkit) this).anInt8101, ((GLToolkit) this).aString8162, 0L);
	}

	public Sprite method5105(int[] is, int i, int i_496_, int i_497_, int i_498_, boolean bool) {
		return new Class57_Sub3(this, i_497_, i_498_, is, i, i_496_);
	}

	public Sprite method5106(int[] is, int i, int i_499_, int i_500_, int i_501_, boolean bool) {
		return new Class57_Sub3(this, i_500_, i_501_, is, i, i_499_);
	}

	Class52_Sub2 method5006(Canvas canvas, int i, int i_502_) {
		return new Class52_Sub2_Sub3(this, canvas);
	}

	public Sprite method5107(IndexedImage class89, boolean bool) {
		int[] is = new int[class89.anInt812 * class89.anInt816];
		int i = 0;
		int i_503_ = 0;
		if (class89.aByteArray819 != null) {
			for (int i_504_ = 0; i_504_ < class89.anInt816; i_504_++) {
				for (int i_505_ = 0; i_505_ < class89.anInt812; i_505_++) {
					is[i_503_++] = (class89.aByteArray819[i] << 24
							| (class89.anIntArray817[class89.aByteArray818[i] & 0xff]));
					i++;
				}
			}
		} else {
			for (int i_506_ = 0; i_506_ < class89.anInt816; i_506_++) {
				for (int i_507_ = 0; i_507_ < class89.anInt812; i_507_++) {
					int i_508_ = (class89.anIntArray817[class89.aByteArray818[i++] & 0xff]);
					is[i_503_++] = i_508_ != 0 ? ~0xffffff | i_508_ : 0;
				}
			}
		}
		Sprite class57 = method5031(is, 0, class89.anInt812, class89.anInt812, class89.anInt816, 906612103);
		class57.method621(class89.anInt815, class89.anInt811, class89.anInt814, class89.anInt813);
		return class57;
	}

	public void ec(boolean bool) {
		((GLToolkit) this).aBoolean8108 = bool;
		method5265();
	}

	public void gg(int i, Class_ta class_ta, int i_509_, int i_510_) {
		Class_ta_Sub1 class_ta_sub1 = (Class_ta_Sub1) class_ta;
		Class30_Sub2_Sub1 class30_sub2_sub1 = ((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441;
		method5251();
		method5256(((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441);
		method5266(1);
		method5258(7681, 8448);
		method5259(0, 34167, 768);
		float f = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9049
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9048);
		float f_511_ = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9051
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9047);
		OpenGL.glColor4ub((byte) (i >> 16), (byte) (i >> 8), (byte) i, (byte) (i >> 24));
		OpenGL.glBegin(7);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8081 - i_509_),
				f_511_ * (float) (((GLToolkit) this).anInt8109 - i_510_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8081, ((GLToolkit) this).anInt8109);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8081 - i_509_),
				f_511_ * (float) (((GLToolkit) this).anInt8059 - i_510_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8081, ((GLToolkit) this).anInt8059);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8024 - i_509_),
				f_511_ * (float) (((GLToolkit) this).anInt8059 - i_510_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8024, ((GLToolkit) this).anInt8059);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8024 - i_509_),
				f_511_ * (float) (((GLToolkit) this).anInt8109 - i_510_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8024, ((GLToolkit) this).anInt8109);
		OpenGL.glEnd();
		method5259(0, 5890, 768);
	}

	void method5069() {
		for (Class298 class298 = ((GLToolkit) this).aClass458_8067.method5967(
				1818492578); class298 != null; class298 = ((GLToolkit) this).aClass458_8067.method5969((byte) -36))
			((Class_v_Sub1) class298).method3674();
		if (((GLToolkit) this).aClass42_8055 != null)
			((GLToolkit) this).aClass42_8055.method486();
		if (((GLToolkit) this).aBoolean8065) {
			Class216.method2000(false, true, (short) 19373);
			((GLToolkit) this).aBoolean8065 = false;
		}
	}

	public Class_ta method5110(int i, int i_512_, int[] is, int[] is_513_) {
		return Class_ta_Sub1.method5999(this, i, i_512_, is, is_513_);
	}

	public Class222 method5013() {
		return ((GLToolkit) this).aClass222_8060;
	}

	public void gv(int i, Class_ta class_ta, int i_514_, int i_515_) {
		Class_ta_Sub1 class_ta_sub1 = (Class_ta_Sub1) class_ta;
		Class30_Sub2_Sub1 class30_sub2_sub1 = ((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441;
		method5251();
		method5256(((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441);
		method5266(1);
		method5258(7681, 8448);
		method5259(0, 34167, 768);
		float f = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9049
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9048);
		float f_516_ = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9051
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9047);
		OpenGL.glColor4ub((byte) (i >> 16), (byte) (i >> 8), (byte) i, (byte) (i >> 24));
		OpenGL.glBegin(7);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8081 - i_514_),
				f_516_ * (float) (((GLToolkit) this).anInt8109 - i_515_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8081, ((GLToolkit) this).anInt8109);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8081 - i_514_),
				f_516_ * (float) (((GLToolkit) this).anInt8059 - i_515_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8081, ((GLToolkit) this).anInt8059);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8024 - i_514_),
				f_516_ * (float) (((GLToolkit) this).anInt8059 - i_515_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8024, ((GLToolkit) this).anInt8059);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8024 - i_514_),
				f_516_ * (float) (((GLToolkit) this).anInt8109 - i_515_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8024, ((GLToolkit) this).anInt8109);
		OpenGL.glEnd();
		method5259(0, 5890, 768);
	}

	public Class264 method5113(Class505 class505, IndexedImage[] class89s, boolean bool) {
		return new Class264_Sub3(this, class505, class89s, bool);
	}

	public Class233 method5083() {
		return ((GLToolkit) this).aClass233_8058;
	}

	final void method5273(int i) {
		aFloatArray8163[0] = (float) (i & 0xff0000) / 1.671168E7F;
		aFloatArray8163[1] = (float) (i & 0xff00) / 65280.0F;
		aFloatArray8163[2] = (float) (i & 0xff) / 255.0F;
		aFloatArray8163[3] = (float) (i >>> 24) / 255.0F;
		OpenGL.glTexEnvfv(8960, 8705, aFloatArray8163, 0);
	}

	public Model method5116(ModelDecoder class64, int i, int i_517_, int i_518_, int i_519_) {
		return new OpenGLModel(this, class64, i, i_518_, i_519_, i_517_);
	}

	public int method5126(int i, int i_520_) {
		return i & i_520_ ^ i_520_;
	}

	public int method5118(int i, int i_521_) {
		return i & i_521_ ^ i_521_;
	}

	public void method5066() {
		OpenGL.glFinish();
	}

	public int method5120(int i, int i_522_) {
		return i & i_522_ ^ i_522_;
	}

	public Ground method5121(int i, int i_523_, int[][] is, int[][] is_524_, int i_525_, int i_526_, int i_527_) {
		return new Class_xa_Sub3(this, i_526_, i_527_, i, i_523_, is, is_524_, i_525_);
	}

	static int method5274(Class55 class55, Class77 class77) {
		if (class77 == Class77.aClass77_717) {
			switch (class55.anInt566 * -976336893) {
				case 9:
					return 6408;
				case 7:
					return 6406;
				case 5:
					return 6407;
				case 3:
					return 6410;
				default:
					throw new IllegalArgumentException();
				case 1:
					return 6409;
			}
		}
		if (class77 == Class77.aClass77_718) {
			switch (class55.anInt566 * -976336893) {
				case 5:
					return 32852;
				case 2:
					return 33189;
				default:
					throw new IllegalArgumentException();
				case 3:
					return 36219;
				case 7:
					return 32830;
				case 9:
					return 32859;
				case 1:
					return 32834;
			}
		}
		if (class77 == Class77.aClass77_719) {
			switch (class55.anInt566 * -976336893) {
				case 2:
					return 33190;
				default:
					throw new IllegalArgumentException();
			}
		}
		if (class77 == Class77.aClass77_714) {
			switch (class55.anInt566 * -976336893) {
				default:
					throw new IllegalArgumentException();
				case 1:
					return 34846;
				case 3:
					return 34847;
				case 7:
					return 34844;
				case 5:
					return 34843;
				case 9:
					return 34842;
			}
		}
		if (class77 == Class77.aClass77_721) {
			switch (class55.anInt566 * -976336893) {
				case 7:
					return 34838;
				default:
					throw new IllegalArgumentException();
				case 3:
					return 34841;
				case 9:
					return 34836;
				case 1:
					return 34840;
				case 5:
					return 34837;
			}
		}
		throw new IllegalArgumentException();
	}

	public Ground method5087(int i, int i_528_, int[][] is, int[][] is_529_, int i_530_, int i_531_, int i_532_) {
		return new Class_xa_Sub3(this, i_531_, i_532_, i, i_528_, is, is_529_, i_530_);
	}

	void CA(int i, int i_533_, int i_534_, int i_535_, int i_536_) {
		if (i_534_ < 0)
			i_534_ = -i_534_;
		if (i + i_534_ >= ((GLToolkit) this).anInt8081 && i - i_534_ <= ((GLToolkit) this).anInt8024
				&& i_533_ + i_534_ >= ((GLToolkit) this).anInt8109 && i_533_ - i_534_ <= ((GLToolkit) this).anInt8059) {
			method5250();
			method5266(i_536_);
			OpenGL.glColor4ub((byte) (i_535_ >> 16), (byte) (i_535_ >> 8), (byte) i_535_, (byte) (i_535_ >> 24));
			float f = (float) i + 0.35F;
			float f_537_ = (float) i_533_ + 0.35F;
			int i_538_ = i_534_ << 1;
			if ((float) i_538_ < ((GLToolkit) this).aFloat8188) {
				OpenGL.glBegin(7);
				OpenGL.glVertex2f(f + 1.0F, f_537_ + 1.0F);
				OpenGL.glVertex2f(f + 1.0F, f_537_ - 1.0F);
				OpenGL.glVertex2f(f - 1.0F, f_537_ - 1.0F);
				OpenGL.glVertex2f(f - 1.0F, f_537_ + 1.0F);
				OpenGL.glEnd();
			} else if ((float) i_538_ <= ((GLToolkit) this).aFloat8187) {
				OpenGL.glEnable(2832);
				OpenGL.glPointSize((float) i_538_);
				OpenGL.glBegin(0);
				OpenGL.glVertex2f(f, f_537_);
				OpenGL.glEnd();
				OpenGL.glDisable(2832);
			} else {
				OpenGL.glBegin(6);
				OpenGL.glVertex2f(f, f_537_);
				int i_539_ = 262144 / (6 * i_534_);
				if (i_539_ <= 64)
					i_539_ = 64;
				else if (i_539_ > 512)
					i_539_ = 512;
				i_539_ = Class422_Sub4.method5639(i_539_, 2139258683);
				OpenGL.glVertex2f(f + (float) i_534_, f_537_);
				for (int i_540_ = 16384 - i_539_; i_540_ > 0; i_540_ -= i_539_)
					OpenGL.glVertex2f(f + (Class35.aFloatArray417[i_540_] * (float) i_534_),
							f_537_ + (Class35.aFloatArray418[i_540_] * (float) i_534_));
				OpenGL.glVertex2f(f + (float) i_534_, f_537_);
				OpenGL.glEnd();
			}
		}
	}

	public Class222 method5183() {
		return ((GLToolkit) this).aClass222_8060;
	}

	public Class222 method5008() {
		return ((GLToolkit) this).aClass222_8060;
	}

	public Class_ta method5109(int i, int i_541_, int[] is, int[] is_542_) {
		return Class_ta_Sub1.method5999(this, i, i_541_, is, is_542_);
	}

	public void method4997(int i, Class298_Sub10[] class298_sub10s) {
		for (int i_543_ = 0; i_543_ < i; i_543_++)
			((GLToolkit) this).aClass298_Sub10Array8164[i_543_] = class298_sub10s[i_543_];
		((GLToolkit) this).anInt8135 = i;
		if (((GLToolkit) this).anInt8107 != 1)
			method5277();
	}

	public void fa(int i, int i_544_, int i_545_, int i_546_, int i_547_, int i_548_) {
		float f = (float) i + 0.35F;
		float f_549_ = (float) i_544_ + 0.35F;
		float f_550_ = f + (float) i_545_;
		float f_551_ = f_549_ + (float) i_546_;
		method5250();
		method5266(i_548_);
		OpenGL.glColor4ub((byte) (i_547_ >> 16), (byte) (i_547_ >> 8), (byte) i_547_, (byte) (i_547_ >> 24));
		if (((GLToolkit) this).aBoolean8173)
			OpenGL.glDisable(32925);
		OpenGL.glBegin(7);
		OpenGL.glVertex2f(f, f_549_);
		OpenGL.glVertex2f(f, f_551_);
		OpenGL.glVertex2f(f_550_, f_551_);
		OpenGL.glVertex2f(f_550_, f_549_);
		OpenGL.glEnd();
		if (((GLToolkit) this).aBoolean8173)
			OpenGL.glEnable(32925);
	}

	final void method5275(int i) {
		method5253(i, true);
	}

	public final void method5130(Class222 class222) {
		((GLToolkit) this).aClass222_8087.method2070(class222);
		((GLToolkit) this).aClass233_8110.method2145(((GLToolkit) this).aClass222_8087);
		((GLToolkit) this).aClass222_8103.method2070(class222);
		((GLToolkit) this).aClass222_8103.method2058();
		((GLToolkit) this).aClass233_8089.method2145(((GLToolkit) this).aClass222_8103);
		method5235();
		if (((GLToolkit) this).anInt8107 != 1)
			method5234();
	}

	public final void method5131(Class222 class222) {
		((GLToolkit) this).aClass222_8087.method2070(class222);
		((GLToolkit) this).aClass233_8110.method2145(((GLToolkit) this).aClass222_8087);
		((GLToolkit) this).aClass222_8103.method2070(class222);
		((GLToolkit) this).aClass222_8103.method2058();
		((GLToolkit) this).aClass233_8089.method2145(((GLToolkit) this).aClass222_8103);
		method5235();
		if (((GLToolkit) this).anInt8107 != 1)
			method5234();
	}

	public final void method5132(Class222 class222) {
		((GLToolkit) this).aClass222_8087.method2070(class222);
		((GLToolkit) this).aClass233_8110.method2145(((GLToolkit) this).aClass222_8087);
		((GLToolkit) this).aClass222_8103.method2070(class222);
		((GLToolkit) this).aClass222_8103.method2058();
		((GLToolkit) this).aClass233_8089.method2145(((GLToolkit) this).aClass222_8103);
		method5235();
		if (((GLToolkit) this).anInt8107 != 1)
			method5234();
	}

	public void method5039(int i, int i_552_, int i_553_, int i_554_, int i_555_, int i_556_, int i_557_, int i_558_,
			int i_559_) {
		if (i != i_553_ || i_552_ != i_554_) {
			method5250();
			method5266(i_556_);
			float f = (float) i_553_ - (float) i;
			float f_560_ = (float) i_554_ - (float) i_552_;
			float f_561_ = (float) (1.0 / Math.sqrt((double) (f * f + f_560_ * f_560_)));
			f *= f_561_;
			f_560_ *= f_561_;
			OpenGL.glColor4ub((byte) (i_555_ >> 16), (byte) (i_555_ >> 8), (byte) i_555_, (byte) (i_555_ >> 24));
			i_559_ %= i_558_ + i_557_;
			float f_562_ = f * (float) i_557_;
			float f_563_ = f_560_ * (float) i_557_;
			float f_564_ = 0.0F;
			float f_565_ = 0.0F;
			float f_566_ = f_562_;
			float f_567_ = f_563_;
			if (i_559_ > i_557_) {
				f_564_ = f * (float) (i_557_ + i_558_ - i_559_);
				f_565_ = f_560_ * (float) (i_557_ + i_558_ - i_559_);
			} else {
				f_566_ = f * (float) (i_557_ - i_559_);
				f_567_ = f_560_ * (float) (i_557_ - i_559_);
			}
			float f_568_ = (float) i + 0.35F + f_564_;
			float f_569_ = (float) i_552_ + 0.35F + f_565_;
			float f_570_ = f * (float) i_558_;
			float f_571_ = f_560_ * (float) i_558_;
			for (;;) {
				if (i_553_ > i) {
					if (f_568_ > (float) i_553_ + 0.35F)
						break;
					if (f_568_ + f_566_ > (float) i_553_)
						f_566_ = (float) i_553_ - f_568_;
				} else {
					if (f_568_ < (float) i_553_ + 0.35F)
						break;
					if (f_568_ + f_566_ < (float) i_553_)
						f_566_ = (float) i_553_ - f_568_;
				}
				if (i_554_ > i_552_) {
					if (f_569_ > (float) i_554_ + 0.35F)
						break;
					if (f_569_ + f_567_ > (float) i_554_)
						f_567_ = (float) i_554_ - f_569_;
				} else {
					if (f_569_ < (float) i_554_ + 0.35F)
						break;
					if (f_569_ + f_567_ < (float) i_554_)
						f_567_ = (float) i_554_ - f_569_;
				}
				OpenGL.glBegin(1);
				OpenGL.glVertex2f(f_568_, f_569_);
				OpenGL.glVertex2f(f_568_ + f_566_, f_569_ + f_567_);
				OpenGL.glEnd();
				f_568_ += f_570_ + f_566_;
				f_569_ += f_571_ + f_567_;
				f_566_ = f_562_;
				f_567_ = f_563_;
			}
		}
	}

	public final void method5134(Class233 class233) {
		((GLToolkit) this).aClass233_8041.method2142(class233);
		method5235();
		method5240();
	}

	public final void hu(float f) {
		if (((GLToolkit) this).aFloat8130 != f) {
			((GLToolkit) this).aFloat8130 = f;
			method5239();
		}
	}

	public final void hs(float f) {
		if (((GLToolkit) this).aFloat8130 != f) {
			((GLToolkit) this).aFloat8130 = f;
			method5239();
		}
	}

	public final void hg(int i, float f, float f_572_, float f_573_, float f_574_, float f_575_) {
		boolean bool = ((GLToolkit) this).anInt8033 != i;
		if (bool || ((GLToolkit) this).aFloat8131 != f || ((GLToolkit) this).aFloat8132 != f_572_) {
			((GLToolkit) this).anInt8033 = i;
			((GLToolkit) this).aFloat8131 = f;
			((GLToolkit) this).aFloat8132 = f_572_;
			if (bool) {
				((GLToolkit) this).aFloat8125 = ((float) (((GLToolkit) this).anInt8033 & 0xff0000) / 1.671168E7F);
				((GLToolkit) this).aFloat8128 = ((float) (((GLToolkit) this).anInt8033 & 0xff00) / 65280.0F);
				((GLToolkit) this).aFloat8191 = ((float) (((GLToolkit) this).anInt8033 & 0xff) / 255.0F);
				method5239();
			}
			method5230();
		}
		if (((GLToolkit) this).aFloatArray8122[0] != f_573_ || ((GLToolkit) this).aFloatArray8122[1] != f_574_
				|| ((GLToolkit) this).aFloatArray8122[2] != f_575_) {
			((GLToolkit) this).aFloatArray8122[0] = f_573_;
			((GLToolkit) this).aFloatArray8122[1] = f_574_;
			((GLToolkit) this).aFloatArray8122[2] = f_575_;
			((GLToolkit) this).aFloatArray8123[0] = -f_573_;
			((GLToolkit) this).aFloatArray8123[1] = -f_574_;
			((GLToolkit) this).aFloatArray8123[2] = -f_575_;
			float f_576_ = (float) (1.0 / Math.sqrt((double) (f_573_ * f_573_ + f_574_ * f_574_ + f_575_ * f_575_)));
			((GLToolkit) this).aFloatArray8124[0] = f_573_ * f_576_;
			((GLToolkit) this).aFloatArray8124[1] = f_574_ * f_576_;
			((GLToolkit) this).aFloatArray8124[2] = f_575_ * f_576_;
			((GLToolkit) this).aFloatArray8157[0] = -((GLToolkit) this).aFloatArray8124[0];
			((GLToolkit) this).aFloatArray8157[1] = -((GLToolkit) this).aFloatArray8124[1];
			((GLToolkit) this).aFloatArray8157[2] = -((GLToolkit) this).aFloatArray8124[2];
			method5279();
			((GLToolkit) this).anInt8066 = (int) (f_573_ * 256.0F / f_574_);
			((GLToolkit) this).anInt8026 = (int) (f_575_ * 256.0F / f_574_);
		}
	}

	public final void hb(int i) {
		((GLToolkit) this).anInt8064 = 0;
		for (/**/; i > 1; i >>= 1)
			((GLToolkit) this).anInt8064++;
		((GLToolkit) this).anInt8063 = 1 << ((GLToolkit) this).anInt8064;
	}

	public final void hv(int i, int i_577_, int i_578_) {
		if (((GLToolkit) this).anInt8139 != i || ((GLToolkit) this).anInt8007 != i_577_
				|| ((GLToolkit) this).anInt8195 != i_578_) {
			((GLToolkit) this).anInt8139 = i;
			((GLToolkit) this).anInt8007 = i_577_;
			((GLToolkit) this).anInt8195 = i_578_;
			method5242();
			method5241();
		}
	}

	public final void hj(int i, int i_579_, int i_580_) {
		if (((GLToolkit) this).anInt8139 != i || ((GLToolkit) this).anInt8007 != i_579_
				|| ((GLToolkit) this).anInt8195 != i_580_) {
			((GLToolkit) this).anInt8139 = i;
			((GLToolkit) this).anInt8007 = i_579_;
			((GLToolkit) this).anInt8195 = i_580_;
			method5242();
			method5241();
		}
	}

	public final void hn(int i, int i_581_, int i_582_) {
		if (((GLToolkit) this).anInt8139 != i || ((GLToolkit) this).anInt8007 != i_581_
				|| ((GLToolkit) this).anInt8195 != i_582_) {
			((GLToolkit) this).anInt8139 = i;
			((GLToolkit) this).anInt8007 = i_581_;
			((GLToolkit) this).anInt8195 = i_582_;
			method5242();
			method5241();
		}
	}

	public final void he(int i, int i_583_, int i_584_) {
		if (((GLToolkit) this).anInt8139 != i || ((GLToolkit) this).anInt8007 != i_583_
				|| ((GLToolkit) this).anInt8195 != i_584_) {
			((GLToolkit) this).anInt8139 = i;
			((GLToolkit) this).anInt8007 = i_583_;
			((GLToolkit) this).anInt8195 = i_584_;
			method5242();
			method5241();
		}
	}

	public void method5137(boolean bool) {
		/* empty */
	}

	public void method5184(boolean bool) {
		/* empty */
	}

	public void GA(float f, float f_585_) {
		((GLToolkit) this).aFloat8099 = f;
		((GLToolkit) this).aFloat8100 = f_585_;
		method5276();
	}

	public Class66 method5140(int i, int i_586_, int i_587_, int i_588_, int i_589_, int i_590_) {
		return (((GLToolkit) this).aBoolean8178 ? new Class66_Sub1_Sub1(this, i, i_586_, i_587_, i_588_, i_589_, i_590_)
				: null);
	}

	public Class66 method5181(int i, int i_591_, int i_592_, int i_593_, int i_594_, int i_595_) {
		return (((GLToolkit) this).aBoolean8178 ? new Class66_Sub1_Sub1(this, i, i_591_, i_592_, i_593_, i_594_, i_595_)
				: null);
	}

	public Class66 method5084(int i, int i_596_, int i_597_, int i_598_, int i_599_, int i_600_) {
		return (((GLToolkit) this).aBoolean8178 ? new Class66_Sub1_Sub1(this, i, i_596_, i_597_, i_598_, i_599_, i_600_)
				: null);
	}

	public Class66 method4986(Class66 class66, Class66 class66_601_, float f, Class66 class66_602_) {
		if (class66 != null && class66_601_ != null && ((GLToolkit) this).aBoolean8178
				&& ((GLToolkit) this).framebuffer_obj) {
			Class66_Sub1_Sub2 class66_sub1_sub2 = null;
			Class66_Sub1 class66_sub1 = (Class66_Sub1) class66;
			Class66_Sub1 class66_sub1_603_ = (Class66_Sub1) class66_601_;
			Class30_Sub1 class30_sub1 = class66_sub1.method769();
			Class30_Sub1 class30_sub1_604_ = class66_sub1_603_.method769();
			if (class30_sub1 != null && class30_sub1_604_ != null) {
				int i = ((((Class30_Sub1) class30_sub1).anInt6745 > ((Class30_Sub1) class30_sub1_604_).anInt6745)
						? ((Class30_Sub1) class30_sub1).anInt6745 : ((Class30_Sub1) class30_sub1_604_).anInt6745);
				if (class66 != class66_602_ && class66_601_ != class66_602_
						&& class66_602_ instanceof Class66_Sub1_Sub2) {
					Class66_Sub1_Sub2 class66_sub1_sub2_605_ = (Class66_Sub1_Sub2) class66_602_;
					if (class66_sub1_sub2_605_.method771() == i)
						class66_sub1_sub2 = class66_sub1_sub2_605_;
				}
				if (class66_sub1_sub2 == null)
					class66_sub1_sub2 = new Class66_Sub1_Sub2(this, i);
				if (class66_sub1_sub2.method772(class30_sub1, class30_sub1_604_, f))
					return class66_sub1_sub2;
			}
		}
		return f < 0.5F ? class66 : class66_601_;
	}

	public Class66 method5142(Class66 class66, Class66 class66_606_, float f, Class66 class66_607_) {
		if (class66 != null && class66_606_ != null && ((GLToolkit) this).aBoolean8178
				&& ((GLToolkit) this).framebuffer_obj) {
			Class66_Sub1_Sub2 class66_sub1_sub2 = null;
			Class66_Sub1 class66_sub1 = (Class66_Sub1) class66;
			Class66_Sub1 class66_sub1_608_ = (Class66_Sub1) class66_606_;
			Class30_Sub1 class30_sub1 = class66_sub1.method769();
			Class30_Sub1 class30_sub1_609_ = class66_sub1_608_.method769();
			if (class30_sub1 != null && class30_sub1_609_ != null) {
				int i = ((((Class30_Sub1) class30_sub1).anInt6745 > ((Class30_Sub1) class30_sub1_609_).anInt6745)
						? ((Class30_Sub1) class30_sub1).anInt6745 : ((Class30_Sub1) class30_sub1_609_).anInt6745);
				if (class66 != class66_607_ && class66_606_ != class66_607_
						&& class66_607_ instanceof Class66_Sub1_Sub2) {
					Class66_Sub1_Sub2 class66_sub1_sub2_610_ = (Class66_Sub1_Sub2) class66_607_;
					if (class66_sub1_sub2_610_.method771() == i)
						class66_sub1_sub2 = class66_sub1_sub2_610_;
				}
				if (class66_sub1_sub2 == null)
					class66_sub1_sub2 = new Class66_Sub1_Sub2(this, i);
				if (class66_sub1_sub2.method772(class30_sub1, class30_sub1_609_, f))
					return class66_sub1_sub2;
			}
		}
		return f < 0.5F ? class66 : class66_606_;
	}

	public Class66 method5185(int i, int i_611_, int i_612_, int i_613_, int i_614_, int i_615_) {
		return (((GLToolkit) this).aBoolean8178 ? new Class66_Sub1_Sub1(this, i, i_611_, i_612_, i_613_, i_614_, i_615_)
				: null);
	}

	public final void method5145() {
		if (((GLToolkit) this).aClass298_Sub8_Sub1_8056 != null
				&& ((GLToolkit) this).aClass298_Sub8_Sub1_8056.method2886()) {
			((GLToolkit) this).aClass42_8055.method485(((GLToolkit) this).aClass298_Sub8_Sub1_8056);
			((GLToolkit) this).aClass61_8052.method718();
		}
	}

	public Ground method5040(int i, int i_616_, int[][] is, int[][] is_617_, int i_618_, int i_619_, int i_620_) {
		return new Class_xa_Sub3(this, i_619_, i_620_, i, i_616_, is, is_617_, i_618_);
	}

	public final boolean method5119() {
		return (((GLToolkit) this).aClass298_Sub8_Sub1_8056 != null
				&& ((GLToolkit) this).aClass298_Sub8_Sub1_8056.method2886());
	}

	public void method5115(int i) {
		/* empty */
	}

	public final boolean method5149() {
		return (((GLToolkit) this).aClass298_Sub8_Sub1_8056 != null
				&& ((GLToolkit) this).aClass298_Sub8_Sub1_8056.method2886());
	}

	public final void method4991(int i, int i_621_, int i_622_, int i_623_) {
		((GLToolkit) this).aClass42_8055.method481(i, i_621_, i_622_, i_623_);
	}

	public void method5128(Class69 class69) {
		((GLToolkit) this).aClass34_8057.method436(this, class69);
	}

	final void method5276() {
		if (((GLToolkit) this).anInt8107 == 2)
			OpenGL.glDepthRange(((GLToolkit) this).aFloat8099, ((GLToolkit) this).aFloat8100);
		else
			OpenGL.glDepthRange(0.0F, 1.0F);
	}

	public final void method5154() {
		((GLToolkit) this).aClass42_8055.method483();
	}

	public void method5155(int i, Class78 class78) {
		((GLToolkit) this).anInt8155 = i;
		((GLToolkit) this).aClass78_8149 = class78;
		((GLToolkit) this).aBoolean8146 = true;
	}

	public void method5156(int i, Class78 class78) {
		((GLToolkit) this).anInt8155 = i;
		((GLToolkit) this).aClass78_8149 = class78;
		((GLToolkit) this).aBoolean8146 = true;
	}

	public void method5089(int i, Class78 class78) {
		if (!((GLToolkit) this).aBoolean8146)
			throw new RuntimeException("");
		((GLToolkit) this).anInt8155 = i;
		((GLToolkit) this).aClass78_8149 = class78;
		if (((GLToolkit) this).aBoolean8147) {
			((Class27) ((GLToolkit) this).aClass27_8054).aClass47_Sub5_358.method524();
			((Class27) ((GLToolkit) this).aClass27_8054).aClass47_Sub5_358.method523();
		}
	}

	public void ih() {
		((GLToolkit) this).aBoolean8146 = false;
	}

	public void iv() {
		((GLToolkit) this).aBoolean8146 = false;
	}

	public void method5158(int i, int i_624_, float f, int i_625_, int i_626_, float f_627_, int i_628_, int i_629_,
			float f_630_, int i_631_, int i_632_, int i_633_, int i_634_) {
		method5250();
		method5266(i_634_);
		OpenGL.glBegin(4);
		OpenGL.glColor4ub((byte) (i_631_ >> 16), (byte) (i_631_ >> 8), (byte) i_631_, (byte) (i_631_ >> 24));
		OpenGL.glVertex3f((float) i + 0.35F, (float) i_624_ + 0.35F, f);
		OpenGL.glColor4ub((byte) (i_632_ >> 16), (byte) (i_632_ >> 8), (byte) i_632_, (byte) (i_632_ >> 24));
		OpenGL.glVertex3f((float) i_625_ + 0.35F, (float) i_626_ + 0.35F, f_627_);
		OpenGL.glColor4ub((byte) (i_633_ >> 16), (byte) (i_633_ >> 8), (byte) i_633_, (byte) (i_633_ >> 24));
		OpenGL.glVertex3f((float) i_628_ + 0.35F, (float) i_629_ + 0.35F, f_630_);
		OpenGL.glEnd();
	}

	public void method5139(int i, int i_635_, float f, int i_636_, int i_637_, float f_638_, int i_639_, int i_640_,
			float f_641_, int i_642_, int i_643_, int i_644_, int i_645_) {
		method5250();
		method5266(i_645_);
		OpenGL.glBegin(4);
		OpenGL.glColor4ub((byte) (i_642_ >> 16), (byte) (i_642_ >> 8), (byte) i_642_, (byte) (i_642_ >> 24));
		OpenGL.glVertex3f((float) i + 0.35F, (float) i_635_ + 0.35F, f);
		OpenGL.glColor4ub((byte) (i_643_ >> 16), (byte) (i_643_ >> 8), (byte) i_643_, (byte) (i_643_ >> 24));
		OpenGL.glVertex3f((float) i_636_ + 0.35F, (float) i_637_ + 0.35F, f_638_);
		OpenGL.glColor4ub((byte) (i_644_ >> 16), (byte) (i_644_ >> 8), (byte) i_644_, (byte) (i_644_ >> 24));
		OpenGL.glVertex3f((float) i_639_ + 0.35F, (float) i_640_ + 0.35F, f_641_);
		OpenGL.glEnd();
	}

	public void method5160(float f, float f_646_, float f_647_, float[] fs) {
		float f_648_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * f_646_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * f_647_));
		float f_649_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * f_646_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * f_647_));
		float f_650_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[13]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[1] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5] * f_646_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9] * f_647_));
		float f_651_ = (((GLToolkit) this).aClass233_8110.aFloatArray2594[14]
				+ ((GLToolkit) this).aClass233_8110.aFloatArray2594[2] * f
				+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[6] * f_646_)
				+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[10] * f_647_));
		fs[0] = (((GLToolkit) this).aFloat8095 + ((GLToolkit) this).aFloat8096 * f_649_ / f_648_);
		fs[1] = (((GLToolkit) this).aFloat8097 + ((GLToolkit) this).aFloat8098 * f_650_ / f_648_);
		fs[2] = f_651_;
	}

	public final void method5053() {
		if (((GLToolkit) this).aClass298_Sub8_Sub1_8056 != null
				&& ((GLToolkit) this).aClass298_Sub8_Sub1_8056.method2886()) {
			((GLToolkit) this).aClass42_8055.method485(((GLToolkit) this).aClass298_Sub8_Sub1_8056);
			((GLToolkit) this).aClass61_8052.method718();
		}
	}

	public void method5162(float f, float f_652_, float f_653_, float[] fs) {
		float f_654_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * f_652_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * f_653_));
		float f_655_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * f_652_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * f_653_));
		float f_656_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[13]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[1] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5] * f_652_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9] * f_653_));
		float f_657_ = (((GLToolkit) this).aClass233_8110.aFloatArray2594[14]
				+ ((GLToolkit) this).aClass233_8110.aFloatArray2594[2] * f
				+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[6] * f_652_)
				+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[10] * f_653_));
		fs[0] = (((GLToolkit) this).aFloat8095 + ((GLToolkit) this).aFloat8096 * f_655_ / f_654_);
		fs[1] = (((GLToolkit) this).aFloat8097 + ((GLToolkit) this).aFloat8098 * f_656_ / f_654_);
		fs[2] = f_657_;
	}

	public void method5164(float f, float f_658_, float f_659_, float[] fs) {
		float f_660_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[14]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[2] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[6] * f_658_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[10] * f_659_));
		float f_661_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[15]
				+ ((GLToolkit) this).aClass233_8069.aFloatArray2594[3] * f
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[7] * f_658_)
				+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[11] * f_659_));
		if (f_660_ < -f_661_ || f_660_ > f_661_) {
			float[] fs_662_ = fs;
			float[] fs_663_ = fs;
			fs[2] = Float.NaN;
			fs_663_[1] = Float.NaN;
			fs_662_[0] = Float.NaN;
		} else {
			float f_664_ = (((GLToolkit) this).aClass233_8069.aFloatArray2594[12]
					+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[0] * f)
					+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[4] * f_658_)
					+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[8] * f_659_));
			if (f_664_ < -f_661_ || f_664_ > f_661_) {
				float[] fs_665_ = fs;
				float[] fs_666_ = fs;
				fs[2] = Float.NaN;
				fs_666_[1] = Float.NaN;
				fs_665_[0] = Float.NaN;
			} else {
				float f_667_ = ((((GLToolkit) this).aClass233_8069.aFloatArray2594[13])
						+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[1]) * f
						+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[5]) * f_658_
						+ (((GLToolkit) this).aClass233_8069.aFloatArray2594[9]) * f_659_);
				if (f_667_ < -f_661_ || f_667_ > f_661_) {
					float[] fs_668_ = fs;
					float[] fs_669_ = fs;
					fs[2] = Float.NaN;
					fs_669_[1] = Float.NaN;
					fs_668_[0] = Float.NaN;
				} else {
					float f_670_ = ((((GLToolkit) this).aClass233_8110.aFloatArray2594[14])
							+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[2]) * f
							+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[6]) * f_658_
							+ (((GLToolkit) this).aClass233_8110.aFloatArray2594[10]) * f_659_);
					fs[0] = (((GLToolkit) this).aFloat8095 + (((GLToolkit) this).aFloat8096 * f_664_ / f_661_));
					fs[1] = (((GLToolkit) this).aFloat8097 + (((GLToolkit) this).aFloat8098 * f_667_ / f_661_));
					fs[2] = f_670_;
				}
			}
		}
	}

	public Class52_Sub1 method5138() {
		return new Class52_Sub1_Sub2(this);
	}

	public Interface8_Impl1_Impl2 method5165(int i, int i_671_) {
		return new Class298_Sub37_Sub18(this, Class55.aClass55_561, Class77.aClass77_719, i, i_671_);
	}

	public boolean method5180() {
		return false;
	}

	public boolean method5166() {
		return (((GLToolkit) this).aClass298_Sub8_Sub1_8056 != null
				&& (((GLToolkit) this).anInt8051 <= 1 || ((GLToolkit) this).aBoolean8174));
	}

	void method5277() {
		int i;
		for (i = 0; i < ((GLToolkit) this).anInt8135; i++) {
			Class298_Sub10 class298_sub10 = ((GLToolkit) this).aClass298_Sub10Array8164[i];
			int i_672_ = 16386 + i;
			aFloatArray8017[0] = (float) class298_sub10.method2895(823958259);
			aFloatArray8017[1] = (float) class298_sub10.method2894(-525522007);
			aFloatArray8017[2] = (float) class298_sub10.method2897((byte) 107);
			aFloatArray8017[3] = 1.0F;
			OpenGL.glLightfv(i_672_, 4611, aFloatArray8017, 0);
			int i_673_ = class298_sub10.method2898(-1921592398);
			float f = class298_sub10.method2901(608404512) / 255.0F;
			aFloatArray8017[0] = (float) (i_673_ >> 16 & 0xff) * f;
			aFloatArray8017[1] = (float) (i_673_ >> 8 & 0xff) * f;
			aFloatArray8017[2] = (float) (i_673_ & 0xff) * f;
			OpenGL.glLightfv(i_672_, 4609, aFloatArray8017, 0);
			OpenGL.glLightf(i_672_, 4617,
					(1.0F / (float) (class298_sub10.method2900(-2060003405) * class298_sub10.method2900(-1382135040))));
			OpenGL.glEnable(i_672_);
		}
		for (/**/; i < ((GLToolkit) this).anInt8127; i++)
			OpenGL.glDisable(16386 + i);
		((GLToolkit) this).anInt8127 = ((GLToolkit) this).anInt8135;
	}

	final void method5278(int i, boolean bool, boolean bool_674_) {
		if (i != ((GLToolkit) this).anInt8152 || (((GLToolkit) this).aBoolean8147 != ((GLToolkit) this).aBoolean8146)) {
			Class30_Sub2 class30_sub2 = null;
			int i_675_ = 0;
			byte i_676_ = 0;
			int i_677_ = 0;
			byte i_678_ = ((GLToolkit) this).aBoolean8146 ? (byte) 3 : (byte) 0;
			if (i >= 0) {
				TextureMetrics class53 = anInterface_ma5299.getTexture(i, 2098871583);
				if (class53.textureId != -1) {
					class30_sub2 = ((GLToolkit) this).aClass61_8052.method715(class53);
					if (class53.textureSpeedU != 0 || class53.textureSpeedV != 0)
						method5261(
								((float) (((GLToolkit) this).anInt8062 % 128000) / 1000.0F
										* (float) class53.textureSpeedU / 64.0F % 1.0F),
								((float) (((GLToolkit) this).anInt8062 % 128000) / 1000.0F
										* (float) class53.textureSpeedV / 64.0F % 1.0F),
								0.0F);
					else
						method5271();
					if (!((GLToolkit) this).aBoolean8146) {
						i_676_ = class53.effectParam1;
						i_677_ = class53.effectParam2 * 1616831825;
						i_678_ = class53.effectId;
					}
					i_675_ = class53.combineMode * -490972023;
				} else
					method5271();
			} else
				method5271();
			((GLToolkit) this).aClass27_8054.method401(i_678_, i_676_, i_677_, bool, bool_674_);
			if (!((GLToolkit) this).aClass27_8054.method402(class30_sub2, i_675_)) {
				method5256(class30_sub2);
				method5243(i_675_);
			}
			((GLToolkit) this).aBoolean8147 = ((GLToolkit) this).aBoolean8146;
			((GLToolkit) this).anInt8152 = i;
		}
		((GLToolkit) this).anInt8080 &= ~0x7;
	}

	public void method5167(int i, int i_679_, int i_680_, int i_681_, int i_682_, int i_683_) {
		method5250();
		method5266(i_683_);
		float f = (float) i_680_ - (float) i;
		float f_684_ = (float) i_681_ - (float) i_679_;
		if (f == 0.0F && f_684_ == 0.0F)
			f = 1.0F;
		else {
			float f_685_ = (float) (1.0 / Math.sqrt((double) (f * f + f_684_ * f_684_)));
			f *= f_685_;
			f_684_ *= f_685_;
		}
		OpenGL.glColor4ub((byte) (i_682_ >> 16), (byte) (i_682_ >> 8), (byte) i_682_, (byte) (i_682_ >> 24));
		OpenGL.glBegin(1);
		OpenGL.glVertex2f((float) i + 0.35F, (float) i_679_ + 0.35F);
		OpenGL.glVertex2f((float) i_680_ + f + 0.35F, (float) i_681_ + f_684_ + 0.35F);
		OpenGL.glEnd();
	}

	public void method5057(int i, Class78 class78) {
		((GLToolkit) this).anInt8155 = i;
		((GLToolkit) this).aClass78_8149 = class78;
		((GLToolkit) this).aBoolean8146 = true;
	}

	void method5279() {
		OpenGL.glLightfv(16384, 4611, ((GLToolkit) this).aFloatArray8124, 0);
		OpenGL.glLightfv(16385, 4611, ((GLToolkit) this).aFloatArray8157, 0);
	}

	public int method5170(int i, int i_686_) {
		return i | i_686_;
	}

	public void method5090(int i, int i_687_, int i_688_, int i_689_) {
		((GLToolkit) this).anInt8115 = i;
		((GLToolkit) this).anInt8194 = i_687_;
		((GLToolkit) this).anInt8117 = i_688_;
		((GLToolkit) this).anInt8180 = i_689_;
		method5231();
	}

	final Class30_Sub1 method5280() {
		return (((GLToolkit) this).aClass66_Sub1_8159 != null ? ((GLToolkit) this).aClass66_Sub1_8159.method769()
				: null);
	}

	final void method5281(boolean bool) {
		if (bool != ((GLToolkit) this).aBoolean8086) {
			((GLToolkit) this).aBoolean8086 = bool;
			method5265();
			((GLToolkit) this).anInt8080 &= ~0xf;
		}
	}

	public Class222 method5171() {
		return new Class222(((GLToolkit) this).aClass222_8087);
	}

	public int method5017(int i, int i_690_) {
		return i & i_690_ ^ i_690_;
	}

	public void fy(int i, int i_691_) {
		int i_692_ = 0;
		if ((i & 0x1) != 0) {
			OpenGL.glClearColor((float) (i_691_ & 0xff0000) / 1.671168E7F, (float) (i_691_ & 0xff00) / 65280.0F,
					(float) (i_691_ & 0xff) / 255.0F, (float) (i_691_ >>> 24) / 255.0F);
			i_692_ = 16384;
		}
		if ((i & 0x2) != 0) {
			method5281(true);
			i_692_ |= 0x100;
		}
		if ((i & 0x4) != 0)
			i_692_ |= 0x400;
		OpenGL.glClear(i_692_);
	}

	public final void J(int i) {
		((GLToolkit) this).anInt8064 = 0;
		for (/**/; i > 1; i >>= 1)
			((GLToolkit) this).anInt8064++;
		((GLToolkit) this).anInt8063 = 1 << ((GLToolkit) this).anInt8064;
	}

	public final Class233 method5124() {
		return new Class233(((GLToolkit) this).aClass233_8041);
	}

	void method5068() {
		for (Class298 class298 = ((GLToolkit) this).aClass458_8067.method5967(
				1739578177); class298 != null; class298 = ((GLToolkit) this).aClass458_8067.method5969((byte) -106))
			((Class_v_Sub1) class298).method3674();
		if (((GLToolkit) this).aClass42_8055 != null)
			((GLToolkit) this).aClass42_8055.method486();
		if (((GLToolkit) this).aBoolean8065) {
			Class216.method2000(false, true, (short) -19800);
			((GLToolkit) this).aBoolean8065 = false;
		}
	}

	void method5282() {
		method5275(-2);
		for (int i = ((GLToolkit) this).anInt8165 - 1; i >= 0; i--) {
			method5255(i);
			method5256(null);
			OpenGL.glTexEnvi(8960, 8704, 34160);
		}
		method5258(8448, 8448);
		method5259(2, 34168, 770);
		method5271();
		((GLToolkit) this).anInt8196 = 1;
		OpenGL.glEnable(3042);
		OpenGL.glBlendFunc(770, 771);
		((GLToolkit) this).anInt8082 = 1;
		OpenGL.glEnable(3008);
		OpenGL.glAlphaFunc(516, 0.0F);
		((GLToolkit) this).aBoolean8038 = true;
		OpenGL.glColorMask(true, true, true, true);
		((GLToolkit) this).aBoolean8083 = true;
		method5226(true);
		method5262(true);
		method5264(true);
		method5281(true);
		GA(0.0F, 1.0F);
		method5291();
		((GLToolkit) this).anOpenGL8116.setSwapInterval(0);
		OpenGL.glShadeModel(7425);
		OpenGL.glClearDepth(1.0F);
		OpenGL.glDepthFunc(515);
		OpenGL.glPolygonMode(1028, 6914);
		OpenGL.glEnable(2884);
		OpenGL.glCullFace(1029);
		OpenGL.glMatrixMode(5888);
		OpenGL.glLoadIdentity();
		OpenGL.glColorMaterial(1028, 5634);
		OpenGL.glEnable(2903);
		float[] fs = { 0.0F, 0.0F, 0.0F, 1.0F };
		for (int i = 0; i < 8; i++) {
			int i_693_ = 16384 + i;
			OpenGL.glLightfv(i_693_, 4608, fs, 0);
			OpenGL.glLightf(i_693_, 4615, 0.0F);
			OpenGL.glLightf(i_693_, 4616, 0.0F);
		}
		OpenGL.glEnable(16384);
		OpenGL.glEnable(16385);
		OpenGL.glFogf(2914, 0.95F);
		OpenGL.glFogi(2917, 9729);
		OpenGL.glHint(3156, 4353);
		((GLToolkit) this).anInt8139 = -1;
		((GLToolkit) this).anInt8033 = -1;
		method5011();
		L();
	}

	final void method5283(Class233 class233) {
		OpenGL.glPushMatrix();
		OpenGL.glMultMatrixf(class233.aFloatArray2594, 0);
	}

	public void method5010(int i, int i_694_, int i_695_, int i_696_, int i_697_, int i_698_, int i_699_) {
		OpenGL.glLineWidth((float) i_698_);
		method5091(i, i_694_, i_695_, i_696_, i_697_, i_699_);
		OpenGL.glLineWidth(1.0F);
	}

	public final void method5175() {
		((GLToolkit) this).aClass42_8055.method483();
	}

	public Sprite method5104(int i, int i_700_, boolean bool, boolean bool_701_) {
		return new Class57_Sub3(this, i, i_700_, bool);
	}

	public final void method5153() {
		((GLToolkit) this).aClass42_8055.method483();
	}

	final Interface2 method5284(int i, byte[] is, int i_702_, boolean bool) {
		if (((GLToolkit) this).aBoolean8126 && (!bool || ((GLToolkit) this).aBoolean8176))
			return new Class40_Sub1(this, i, is, i_702_, bool);
		return new Class46_Sub1(this, i, is, i_702_);
	}

	void method5064(int i, int i_703_) throws Exception_Sub1 {
		try {
			aClass52_Sub2_5312.method580();
		} catch (Exception exception) {
			/* empty */
		}
		if (anInterface_ma5299 != null)
			anInterface_ma5299.method176(1477655879);
	}

	public final boolean method5052() {
		if (((GLToolkit) this).aClass298_Sub8_Sub1_8056 != null) {
			if (!((GLToolkit) this).aClass298_Sub8_Sub1_8056.method2886()) {
				if (((GLToolkit) this).aClass42_8055.method484(((GLToolkit) this).aClass298_Sub8_Sub1_8056))
					((GLToolkit) this).aClass61_8052.method718();
				else
					return false;
			}
			return true;
		}
		return false;
	}

	public Sprite method5108(int i, int i_704_, int i_705_, int i_706_, boolean bool) {
		return new Class57_Sub3(this, i, i_704_, i_705_, i_706_);
	}

	public final void es(int[] is) {
		is[0] = ((GLToolkit) this).anInt8081;
		is[1] = ((GLToolkit) this).anInt8109;
		is[2] = ((GLToolkit) this).anInt8024;
		is[3] = ((GLToolkit) this).anInt8059;
	}

	public void go(int i, Class_ta class_ta, int i_707_, int i_708_) {
		Class_ta_Sub1 class_ta_sub1 = (Class_ta_Sub1) class_ta;
		Class30_Sub2_Sub1 class30_sub2_sub1 = ((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441;
		method5251();
		method5256(((Class_ta_Sub1) class_ta_sub1).aClass30_Sub2_Sub1_8441);
		method5266(1);
		method5258(7681, 8448);
		method5259(0, 34167, 768);
		float f = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9049
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9048);
		float f_709_ = (((Class30_Sub2_Sub1) class30_sub2_sub1).aFloat9051
				/ (float) ((Class30_Sub2_Sub1) class30_sub2_sub1).anInt9047);
		OpenGL.glColor4ub((byte) (i >> 16), (byte) (i >> 8), (byte) i, (byte) (i >> 24));
		OpenGL.glBegin(7);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8081 - i_707_),
				f_709_ * (float) (((GLToolkit) this).anInt8109 - i_708_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8081, ((GLToolkit) this).anInt8109);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8081 - i_707_),
				f_709_ * (float) (((GLToolkit) this).anInt8059 - i_708_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8081, ((GLToolkit) this).anInt8059);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8024 - i_707_),
				f_709_ * (float) (((GLToolkit) this).anInt8059 - i_708_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8024, ((GLToolkit) this).anInt8059);
		OpenGL.glTexCoord2f(f * (float) (((GLToolkit) this).anInt8024 - i_707_),
				f_709_ * (float) (((GLToolkit) this).anInt8109 - i_708_));
		OpenGL.glVertex2i(((GLToolkit) this).anInt8024, ((GLToolkit) this).anInt8109);
		OpenGL.glEnd();
		method5259(0, 5890, 768);
	}

	final void method5285(int i, int i_710_, int i_711_) {
		OpenGL.glDrawArrays(i, i_710_, i_711_);
	}

	public void B(int i, int i_712_, int i_713_, int i_714_, int i_715_, int i_716_) {
		float f = (float) i + 0.35F;
		float f_717_ = (float) i_712_ + 0.35F;
		float f_718_ = f + (float) i_713_;
		float f_719_ = f_717_ + (float) i_714_;
		method5250();
		method5266(i_716_);
		OpenGL.glColor4ub((byte) (i_715_ >> 16), (byte) (i_715_ >> 8), (byte) i_715_, (byte) (i_715_ >> 24));
		if (((GLToolkit) this).aBoolean8173)
			OpenGL.glDisable(32925);
		OpenGL.glBegin(7);
		OpenGL.glVertex2f(f, f_717_);
		OpenGL.glVertex2f(f, f_719_);
		OpenGL.glVertex2f(f_718_, f_719_);
		OpenGL.glVertex2f(f_718_, f_717_);
		OpenGL.glEnd();
		if (((GLToolkit) this).aBoolean8173)
			OpenGL.glEnable(32925);
	}

	final void method5286(int i, int i_720_, int i_721_) {
		OpenGL.glTexEnvi(8960, 34184 + i, i_720_);
		OpenGL.glTexEnvi(8960, 34200 + i, i_721_);
	}

	public void G(int i, int i_722_, int i_723_, int i_724_, int i_725_) {
		method5250();
		method5266(i_725_);
		float f = (float) i + 0.35F;
		float f_726_ = (float) i_722_ + 0.35F;
		OpenGL.glColor4ub((byte) (i_724_ >> 16), (byte) (i_724_ >> 8), (byte) i_724_, (byte) (i_724_ >> 24));
		OpenGL.glBegin(1);
		OpenGL.glVertex2f(f, f_726_);
		OpenGL.glVertex2f(f, f_726_ + (float) i_723_);
		OpenGL.glEnd();
	}

	public final boolean method5144() {
		if (((GLToolkit) this).aClass298_Sub8_Sub1_8056 != null) {
			if (!((GLToolkit) this).aClass298_Sub8_Sub1_8056.method2886()) {
				if (((GLToolkit) this).aClass42_8055.method484(((GLToolkit) this).aClass298_Sub8_Sub1_8056))
					((GLToolkit) this).aClass61_8052.method718();
				else
					return false;
			}
			return true;
		}
		return false;
	}

	final void method5287() {
		OpenGL.glPopMatrix();
	}

	public void N(int i, int i_727_, int i_728_, int i_729_, int i_730_, int i_731_, byte[] is, int i_732_,
			int i_733_) {
		float f;
		float f_734_;
		if (((GLToolkit) this).aClass30_Sub2_Sub1_8111 == null
				|| (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).anInt6746 < i_728_)
				|| (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).anInt6747 < i_729_)) {
			((GLToolkit) this).aClass30_Sub2_Sub1_8111 = Class30_Sub2_Sub1.method428(this, Class55.aClass55_567,
					Class77.aClass77_717, i_728_, i_729_, false, is, Class55.aClass55_567);
			((GLToolkit) this).aClass30_Sub2_Sub1_8111.method420(false, false);
			f = ((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).aFloat9051;
			f_734_ = ((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).aFloat9049;
		} else {
			((GLToolkit) this).aClass30_Sub2_Sub1_8111.method421(0, 0, i_728_, i_729_, is, Class55.aClass55_567, 0, 0,
					false);
			f = (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).aFloat9051 * (float) i_729_
					/ (float) (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).anInt6747));
			f_734_ = (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).aFloat9049 * (float) i_728_
					/ (float) (((Class30_Sub2_Sub1) ((GLToolkit) this).aClass30_Sub2_Sub1_8111).anInt6746));
		}
		method5251();
		method5256(((GLToolkit) this).aClass30_Sub2_Sub1_8111);
		method5266(i_733_);
		OpenGL.glColor4ub((byte) (i_730_ >> 16), (byte) (i_730_ >> 8), (byte) i_730_, (byte) (i_730_ >> 24));
		method5273(i_731_);
		method5258(34165, 34165);
		method5259(0, 34166, 768);
		method5259(2, 5890, 770);
		method5286(0, 34166, 770);
		method5286(2, 5890, 770);
		float f_735_ = (float) i;
		float f_736_ = (float) i_727_;
		float f_737_ = f_735_ + (float) i_728_;
		float f_738_ = f_736_ + (float) i_729_;
		OpenGL.glBegin(7);
		OpenGL.glTexCoord2f(0.0F, 0.0F);
		OpenGL.glVertex2f(f_735_, f_736_);
		OpenGL.glTexCoord2f(0.0F, f_734_);
		OpenGL.glVertex2f(f_735_, f_738_);
		OpenGL.glTexCoord2f(f, f_734_);
		OpenGL.glVertex2f(f_737_, f_738_);
		OpenGL.glTexCoord2f(f, 0.0F);
		OpenGL.glVertex2f(f_737_, f_736_);
		OpenGL.glEnd();
		method5259(0, 5890, 768);
		method5259(2, 34166, 770);
		method5286(0, 5890, 770);
		method5286(2, 34166, 770);
	}

	final int method5288(int i) {
		if (i == 1)
			return 7681;
		if (i == 0)
			return 8448;
		if (i == 2)
			return 34165;
		if (i == 3)
			return 260;
		if (i == 4)
			return 34023;
		throw new IllegalArgumentException();
	}

	public final void IA(float f) {
		if (((GLToolkit) this).aFloat8130 != f) {
			((GLToolkit) this).aFloat8130 = f;
			method5239();
		}
	}

	public final void ep() {
		if (aClass52_5292 != null) {
			((GLToolkit) this).anInt8081 = 0;
			((GLToolkit) this).anInt8109 = 0;
			((GLToolkit) this).anInt8024 = aClass52_5292.method545();
			((GLToolkit) this).anInt8059 = aClass52_5292.method552();
			OpenGL.glDisable(3089);
		}
	}

	final void method5289(int i, int i_739_) {
		((GLToolkit) this).anInt8113 = i;
		((GLToolkit) this).anInt8114 = i_739_;
		method5231();
		method5232();
	}

	public void fd(int i, int i_740_, int i_741_, int i_742_, int i_743_) {
		method5250();
		method5266(i_743_);
		float f = (float) i + 0.35F;
		float f_744_ = (float) i_740_ + 0.35F;
		OpenGL.glColor4ub((byte) (i_742_ >> 16), (byte) (i_742_ >> 8), (byte) i_742_, (byte) (i_742_ >> 24));
		OpenGL.glBegin(1);
		OpenGL.glVertex2f(f, f_744_);
		OpenGL.glVertex2f(f + (float) i_741_, f_744_);
		OpenGL.glEnd();
	}

	void method5290() {
		if (((GLToolkit) this).aBoolean8050 && !((GLToolkit) this).aBoolean8027)
			OpenGL.glEnable(2896);
		else
			OpenGL.glDisable(2896);
	}

	public boolean method5072() {
		return true;
	}

	public void fh(int i, int i_745_) {
		int i_746_ = 0;
		if ((i & 0x1) != 0) {
			OpenGL.glClearColor((float) (i_745_ & 0xff0000) / 1.671168E7F, (float) (i_745_ & 0xff00) / 65280.0F,
					(float) (i_745_ & 0xff) / 255.0F, (float) (i_745_ >>> 24) / 255.0F);
			i_746_ = 16384;
		}
		if ((i & 0x2) != 0) {
			method5281(true);
			i_746_ |= 0x100;
		}
		if ((i & 0x4) != 0)
			i_746_ |= 0x400;
		OpenGL.glClear(i_746_);
	}

	final void method5291() {
		if (((GLToolkit) this).anInt8107 != 0) {
			((GLToolkit) this).anInt8107 = 0;
			method5231();
			method5276();
			((GLToolkit) this).anInt8080 &= ~0xf;
		}
	}
}
