/* Class202 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class IncommingPacket {
    public static IncommingPacket SET_CAMERA_LOOK_PACKET;
    public static IncommingPacket aClass202_2151;
    public static IncommingPacket FRIENDS_PACKET;
    public static IncommingPacket aClass202_2153;
    public static IncommingPacket aClass202_2154;
    public static IncommingPacket CLOSE_INTERFACE_PACKET;
    public static IncommingPacket PLAYER_UNDER_NPC_PRIORITY_PACKET;
    public static IncommingPacket aClass202_2157;
    public static IncommingPacket aClass202_2158;
    public static IncommingPacket MUSIC_EFFECT_PACKET;
    public static IncommingPacket aClass202_2160;
    public static IncommingPacket WORLD_LIST_PACKET;
    public static IncommingPacket aClass202_2162;
    public static IncommingPacket aClass202_2163;
    public static IncommingPacket INTERFACE_PACKET;
    public int anInt2165;
    public static IncommingPacket aClass202_2166;
    public static IncommingPacket OPEN_URL_PACKET;
    public static IncommingPacket aClass202_2168;
    public static IncommingPacket ICOMPONENT_TEXT_PACKET;
    public static IncommingPacket PROJECTILE_PACKET;
    public static IncommingPacket SHAKE_CAMERA_PACKET;
    public static IncommingPacket aClass202_2172;
    public static IncommingPacket PLAYER_ON_ICOMPONENT_PACKET;
    public static IncommingPacket aClass202_2174;
    public static IncommingPacket RUN_ENERGY_PACKET;
    public static IncommingPacket INDEX14_SOUND_PACKET;
    public static IncommingPacket aClass202_2177;
    public static IncommingPacket aClass202_2178;
    public static IncommingPacket aClass202_2179;
    public static IncommingPacket SEND_PRIVATE_QUICK_CHAT_MESSAGE_PACKET;
    public static IncommingPacket NPC_ON_ICOMPONENT_PACKET;
    public static IncommingPacket aClass202_2182;
    public static IncommingPacket RECEIVE_PERSONAL_MESSAGE_PACKET;
    public static IncommingPacket aClass202_2184;
    public static IncommingPacket aClass202_2185;
    public static IncommingPacket aClass202_2186;
    public int anInt2187;
    public static IncommingPacket aClass202_2188;
    public static IncommingPacket GAME_PANE_PACKET;
    public static IncommingPacket ICOMPONENT_SETTINGS_PACKET;
    public static IncommingPacket aClass202_2191;
    public static IncommingPacket LOAD_MAP_SCENE_PACKET;
    public static IncommingPacket aClass202_2193;
    public static IncommingPacket aClass202_2194;
    public static IncommingPacket aClass202_2195;
    public static IncommingPacket RESET_CAMERA_PACKET;
    public static IncommingPacket WORLD_TILE_PACKET;
    public static IncommingPacket SWITCH_ITEMS_LOOK_PACKET;
    public static IncommingPacket aClass202_2198;
    public static IncommingPacket aClass202_2199;
    public static IncommingPacket NPC_UPDATE_PACKET;
    public static IncommingPacket aClass202_2201;
    public static IncommingPacket SPAWN_OBJECT_PACKET;
    public static IncommingPacket aClass202_2203;
    public static IncommingPacket aClass202_2204;
    public static IncommingPacket SET_MOUSE_PACKET;
    public static IncommingPacket CONFIG2_PACKET;
    public static IncommingPacket OPEN_INTERFACE_NPC;
    public static IncommingPacket aClass202_2208;
    public static IncommingPacket aClass202_2209;
    public static IncommingPacket GLOBAL_STRING_PACKET_2;
    public static IncommingPacket IGNORES_PACKET;
    public static IncommingPacket aClass202_2212;
    public static IncommingPacket GLOBAL_CONFIG2_PACKET;
    public static IncommingPacket LARGE_NPC_UPDATE_PACKET;
    public static IncommingPacket aClass202_2215;
    public static IncommingPacket ITEMS_PACKET;
    public static IncommingPacket aClass202_2217;
    public static IncommingPacket aClass202_2218;
    public static IncommingPacket RECEIVE_FRIEND_CHAT_QUICK_MESSAGE_PACKET;
    public static IncommingPacket aClass202_2220;
    public static IncommingPacket aClass202_2221;
    public static IncommingPacket GLOBAL_STRING_PACKET;
    public static IncommingPacket aClass202_2223;
    public static IncommingPacket SET_CAMERA_POS_PACKET;
    public static IncommingPacket PRIVATE_GAME_BAR_STAGE_PACKET;
    public static IncommingPacket OBJECT_ANIMATION_PACKET;
    public static IncommingPacket aClass202_2227 = new IncommingPacket(0, -1);
    public static IncommingPacket aClass202_2228;
    public static IncommingPacket INDEX15_SOUND_PACKET;
    public static IncommingPacket aClass202_2230;
    public static IncommingPacket aClass202_2231;
    public static IncommingPacket aClass202_2232;
    public static IncommingPacket CUTSCENE_PACKET;
    public static IncommingPacket aClass202_2234;
    public static IncommingPacket CONFIG_BY_FILE2_PACKET;
    public static IncommingPacket aClass202_2236;
    public static IncommingPacket aClass202_2237;
    public static IncommingPacket aClass202_2238;
    public static IncommingPacket OTHER_GAME_BAR_STAGES_PACKET;
    public static IncommingPacket GRAPHICS_PACKET;
    public static IncommingPacket CAMERA_ROTATION_PACKET;
    public static IncommingPacket aClass202_2242;
    public static IncommingPacket LOBBY_LOGOUT_PACKET;
    public static IncommingPacket FRIENDS_CHAT_CHANNEL_PACKET;
    public static IncommingPacket CLAN_CHANNEL_PACKET;
    public static IncommingPacket PLAYER_UPDATE_PACKET;
    public static IncommingPacket aClass202_2247;
    public static IncommingPacket aClass202_2248;
    public static IncommingPacket aClass202_2249;
    public static IncommingPacket aClass202_2250;
    public static IncommingPacket aClass202_2251;
    public static IncommingPacket SEND_PRIVATE_MESSAGE_PACKET;
    public static IncommingPacket ICOMPONENT_ANIMATION_PACKET;
    public static IncommingPacket RECEIVE_PRIVATE_QUICK_CHAT_MESSAGE_PACKET;
    public static IncommingPacket aClass202_2255;
    public static IncommingPacket PUBLIC_MESSAGE_PACKET;
    public static IncommingPacket TILE_MESSAGE_PACKET;
    public static IncommingPacket REMOVE_GROUND_ITEM_PACKET;
    public static IncommingPacket aClass202_2259;
    public static IncommingPacket CONFIG1_PACKET;
    public static IncommingPacket aClass202_2261;
    public static IncommingPacket HIDE_ICOMPONENT_PACKET;
    public static IncommingPacket OPEN_INTERFACE_PLAYER;
    public static IncommingPacket ICOMPONENT_MODEL_PACKET;
    public static IncommingPacket aClass202_2265;
    public static IncommingPacket RECEIVE_QUICK_PRIVATE_MESSAGE = new IncommingPacket(1, -1);
    public static IncommingPacket aClass202_2267;
    public static IncommingPacket PLAYER_OPTION_PACKET;
    public static IncommingPacket RUN_SCRIPT_PACKET;
    public static IncommingPacket aClass202_2270;
    public static IncommingPacket ICOMPONENT_SPRITE_PACKET;
    public static IncommingPacket aClass202_2272;
    public static IncommingPacket OPEN_INTERFACE_OBJECT;
    public static IncommingPacket aClass202_2274;
    public static IncommingPacket SEND_GROUND_ITEM_PACKET;
    public static IncommingPacket aClass202_2276;
    public static IncommingPacket aClass202_2277;
    public static IncommingPacket IGNORE_PACKET;
    public static IncommingPacket MUSIC_PACKET;
    public static IncommingPacket DESTROY_OBJECT_PACKET;
    public static IncommingPacket STOP_CAMERA_SHAKE_PACKET;
    public static IncommingPacket HELPER_PACKET;
    public static IncommingPacket CLAN_SETTINGS_PACKET;
    public static IncommingPacket aClass202_2284;
    public static IncommingPacket BLACK_OUT_PACKET;
    public static IncommingPacket MESSAGE_PACKET;
    public static IncommingPacket aClass202_2287;
    public static IncommingPacket ITEMS_UPDATE_PACKET;
    public static IncommingPacket RECEIVE_FRIEND_CHAT_MESSAGE_PACKET;
    public static IncommingPacket aClass202_2290;
    public static IncommingPacket SYSTEM_UPDATE_PACKET;
    public static IncommingPacket RECEIVE_PRIVATE_MESSAGE_PACKET;
    public static IncommingPacket aClass202_2293;
    public static IncommingPacket LOAD_MAP_SCENE_DYNAMIC_PACKET;
    public static IncommingPacket RESET_SOUNDS_PACKET;
    public static IncommingPacket SKILL_LEVEL_PACKET;
    public static IncommingPacket aClass202_2297;
    public static IncommingPacket aClass202_2298;
    public static IncommingPacket aClass202_2299;
    public static IncommingPacket HINT_ICON_PACKET;
    public static IncommingPacket CLIENT_CONSOLE_COMMAND_PACKET;
    public static IncommingPacket ITEM_ON_ICOMPONENT_PACKET;

    /**
     * The keep alive packet, also used as ping packet.
     */
    public static IncommingPacket KEEP_ALIVE_PACKET;
    public static IncommingPacket GLOBAL_CONFIG1_PACKET;
    public static IncommingPacket aClass202_2305;
    public static IncommingPacket aClass202_2306;
    public static IncommingPacket aClass202_2307;
    public static IncommingPacket LOGOUT_PACKET;
    public static IncommingPacket aClass202_2309;
    public static IncommingPacket CONFIG_BY_FILE1_PACKET;

    static {
	FRIENDS_PACKET = new IncommingPacket(2, -2);
	aClass202_2153 = new IncommingPacket(3, -1);
	aClass202_2154 = new IncommingPacket(4, 19);
	CLOSE_INTERFACE_PACKET = new IncommingPacket(5, 4);
	PLAYER_UNDER_NPC_PRIORITY_PACKET = new IncommingPacket(6, 1);
	aClass202_2157 = new IncommingPacket(7, 4);
	aClass202_2158 = new IncommingPacket(8, -1);
	MUSIC_EFFECT_PACKET = new IncommingPacket(9, 6);
	SET_MOUSE_PACKET = new IncommingPacket(10, -1);
	WORLD_LIST_PACKET = new IncommingPacket(11, -2);
	aClass202_2162 = new IncommingPacket(12, 1);
	aClass202_2163 = new IncommingPacket(13, 2);
	INTERFACE_PACKET = new IncommingPacket(14, 23);
	aClass202_2195 = new IncommingPacket(15, 1);
	aClass202_2166 = new IncommingPacket(16, 0);
	OPEN_URL_PACKET = new IncommingPacket(17, -2);
	aClass202_2168 = new IncommingPacket(18, 0);
	aClass202_2186 = new IncommingPacket(19, 2);
	PROJECTILE_PACKET = new IncommingPacket(20, 16);
	aClass202_2151 = new IncommingPacket(21, 6);
	aClass202_2172 = new IncommingPacket(22, 10);
	PLAYER_ON_ICOMPONENT_PACKET = new IncommingPacket(23, 4);
	aClass202_2174 = new IncommingPacket(24, -1);
	RUN_ENERGY_PACKET = new IncommingPacket(25, 1);
	INDEX14_SOUND_PACKET = new IncommingPacket(26, 8);
	aClass202_2177 = new IncommingPacket(27, 28);
	aClass202_2284 = new IncommingPacket(28, 7);
	aClass202_2179 = new IncommingPacket(29, 9);
	SEND_PRIVATE_QUICK_CHAT_MESSAGE_PACKET = new IncommingPacket(30, -1);
	NPC_ON_ICOMPONENT_PACKET = new IncommingPacket(31, 8);
	RECEIVE_FRIEND_CHAT_QUICK_MESSAGE_PACKET = new IncommingPacket(32, -1);
	RECEIVE_PERSONAL_MESSAGE_PACKET = new IncommingPacket(33, -1);
	GLOBAL_STRING_PACKET_2 = new IncommingPacket(34, -2);
	aClass202_2185 = new IncommingPacket(35, 0);
	aClass202_2160 = new IncommingPacket(36, 29);
	aClass202_2259 = new IncommingPacket(37, 4);
	aClass202_2188 = new IncommingPacket(38, 6);
	GAME_PANE_PACKET = new IncommingPacket(39, 19);
	ICOMPONENT_SETTINGS_PACKET = new IncommingPacket(40, 12);
	aClass202_2191 = new IncommingPacket(41, 6);
	LOAD_MAP_SCENE_PACKET = new IncommingPacket(42, -2);
	aClass202_2193 = new IncommingPacket(43, -1);
	SHAKE_CAMERA_PACKET = new IncommingPacket(44, 6);
	DESTROY_OBJECT_PACKET = new IncommingPacket(45, 2);
	aClass202_2209 = new IncommingPacket(46, 4);
	aClass202_2184 = new IncommingPacket(47, 8);
	aClass202_2198 = new IncommingPacket(48, 10);
	aClass202_2199 = new IncommingPacket(49, -1);
	aClass202_2212 = new IncommingPacket(50, 5);
	aClass202_2201 = new IncommingPacket(51, 2);
	aClass202_2194 = new IncommingPacket(52, 11);
	aClass202_2203 = new IncommingPacket(53, 20);
	aClass202_2238 = new IncommingPacket(54, 10);
	IGNORES_PACKET = new IncommingPacket(55, -2);
	CONFIG2_PACKET = new IncommingPacket(56, 6);
	OPEN_INTERFACE_NPC = new IncommingPacket(57, 25);
	aClass202_2208 = new IncommingPacket(58, 2);
	LOBBY_LOGOUT_PACKET = new IncommingPacket(59, 0);
	LOGOUT_PACKET = new IncommingPacket(60, 0);
	CLIENT_CONSOLE_COMMAND_PACKET = new IncommingPacket(61, -1);
	aClass202_2261 = new IncommingPacket(62, -2);
	GLOBAL_CONFIG2_PACKET = new IncommingPacket(63, 6);
	LARGE_NPC_UPDATE_PACKET = new IncommingPacket(64, -2);
	aClass202_2215 = new IncommingPacket(65, 7);
	aClass202_2204 = new IncommingPacket(66, 0);
	aClass202_2217 = new IncommingPacket(67, 0);
	aClass202_2218 = new IncommingPacket(68, 8);
	BLACK_OUT_PACKET = new IncommingPacket(69, 1);
	INDEX15_SOUND_PACKET = new IncommingPacket(70, 6);
	aClass202_2221 = new IncommingPacket(71, 9);
	NPC_UPDATE_PACKET = new IncommingPacket(72, -2);
	aClass202_2223 = new IncommingPacket(73, 4);
	SET_CAMERA_POS_PACKET = new IncommingPacket(74, 6);
	PRIVATE_GAME_BAR_STAGE_PACKET = new IncommingPacket(75, 1);
	OBJECT_ANIMATION_PACKET = new IncommingPacket(76, 9);
	ITEMS_PACKET = new IncommingPacket(77, -2);
	aClass202_2228 = new IncommingPacket(78, 0);
	HINT_ICON_PACKET = new IncommingPacket(79, 14);
	aClass202_2230 = new IncommingPacket(80, 6);
	CONFIG_BY_FILE2_PACKET = new IncommingPacket(81, 6);
	aClass202_2248 = new IncommingPacket(82, 1);
	aClass202_2247 = new IncommingPacket(83, -1);
	aClass202_2270 = new IncommingPacket(84, 6);
	CLAN_CHANNEL_PACKET = new IncommingPacket(85, -2);
	aClass202_2290 = new IncommingPacket(86, 22);
	aClass202_2237 = new IncommingPacket(87, 3);
	aClass202_2236 = new IncommingPacket(88, -2);
	OTHER_GAME_BAR_STAGES_PACKET = new IncommingPacket(89, 2);
	GRAPHICS_PACKET = new IncommingPacket(90, 12);
	aClass202_2178 = new IncommingPacket(91, -1);
	aClass202_2242 = new IncommingPacket(92, 1);
	aClass202_2293 = new IncommingPacket(93, 3);
	aClass202_2231 = new IncommingPacket(94, 17);
	RESET_CAMERA_PACKET = new IncommingPacket(95, 0);
	PLAYER_UPDATE_PACKET = new IncommingPacket(96, -2);
	aClass202_2234 = new IncommingPacket(97, -2);
	aClass202_2309 = new IncommingPacket(98, 2);
	aClass202_2249 = new IncommingPacket(99, 10);
	aClass202_2267 = new IncommingPacket(100, 10);
	aClass202_2251 = new IncommingPacket(101, 8);
	ICOMPONENT_MODEL_PACKET = new IncommingPacket(102, 8);
	ICOMPONENT_ANIMATION_PACKET = new IncommingPacket(103, 8);
	RECEIVE_PRIVATE_QUICK_CHAT_MESSAGE_PACKET = new IncommingPacket(104, -1);
	RECEIVE_PRIVATE_MESSAGE_PACKET = new IncommingPacket(105, -2);
	PUBLIC_MESSAGE_PACKET = new IncommingPacket(106, -1);
	TILE_MESSAGE_PACKET = new IncommingPacket(107, -1);
	REMOVE_GROUND_ITEM_PACKET = new IncommingPacket(108, 3);
	aClass202_2250 = new IncommingPacket(109, 4);
	CONFIG1_PACKET = new IncommingPacket(110, 3);
	CONFIG_BY_FILE1_PACKET = new IncommingPacket(111, 3);
	HIDE_ICOMPONENT_PACKET = new IncommingPacket(112, 5);
	OPEN_INTERFACE_PLAYER = new IncommingPacket(113, 25);
	aClass202_2182 = new IncommingPacket(114, 6);
	aClass202_2265 = new IncommingPacket(115, 5);
	SET_CAMERA_LOOK_PACKET = new IncommingPacket(116, 6);
	FRIENDS_CHAT_CHANNEL_PACKET = new IncommingPacket(117, -2);
	PLAYER_OPTION_PACKET = new IncommingPacket(118, -1);
	RUN_SCRIPT_PACKET = new IncommingPacket(119, -2);
	SPAWN_OBJECT_PACKET = new IncommingPacket(120, 6);
	ICOMPONENT_SPRITE_PACKET = new IncommingPacket(121, 8);
	aClass202_2272 = new IncommingPacket(122, 8);
	CAMERA_ROTATION_PACKET = new IncommingPacket(123, 4);
	aClass202_2274 = new IncommingPacket(124, 8);
	SEND_GROUND_ITEM_PACKET = new IncommingPacket(125, 5);
	aClass202_2276 = new IncommingPacket(126, -2);
	aClass202_2277 = new IncommingPacket(127, 10);
	IGNORE_PACKET = new IncommingPacket(128, -1);
	MUSIC_PACKET = new IncommingPacket(129, 4);
	SEND_PRIVATE_MESSAGE_PACKET = new IncommingPacket(130, -2);
	STOP_CAMERA_SHAKE_PACKET = new IncommingPacket(131, 0);
	HELPER_PACKET = new IncommingPacket(132, -2);
	CLAN_SETTINGS_PACKET = new IncommingPacket(133, -2);
	GLOBAL_STRING_PACKET = new IncommingPacket(134, -1);
	ICOMPONENT_TEXT_PACKET = new IncommingPacket(135, -2);
	MESSAGE_PACKET = new IncommingPacket(136, -1);
	aClass202_2287 = new IncommingPacket(137, 5);
	ITEMS_UPDATE_PACKET = new IncommingPacket(138, -2);
	RECEIVE_FRIEND_CHAT_MESSAGE_PACKET = new IncommingPacket(139, -1);
	aClass202_2232 = new IncommingPacket(140, 8);
	SYSTEM_UPDATE_PACKET = new IncommingPacket(141, 2);
	CUTSCENE_PACKET = new IncommingPacket(142, -2);
	OPEN_INTERFACE_OBJECT = new IncommingPacket(143, 32);
	LOAD_MAP_SCENE_DYNAMIC_PACKET = new IncommingPacket(144, -2);
	RESET_SOUNDS_PACKET = new IncommingPacket(145, 0);
	SKILL_LEVEL_PACKET = new IncommingPacket(146, 6);
	aClass202_2297 = new IncommingPacket(147, 1);
	aClass202_2298 = new IncommingPacket(148, -2);
	aClass202_2299 = new IncommingPacket(149, 2);
	aClass202_2255 = new IncommingPacket(150, 2);
	aClass202_2220 = new IncommingPacket(151, 3);
	ITEM_ON_ICOMPONENT_PACKET = new IncommingPacket(152, 10);
	KEEP_ALIVE_PACKET = new IncommingPacket(153, 0);
	GLOBAL_CONFIG1_PACKET = new IncommingPacket(154, 3);
	aClass202_2305 = new IncommingPacket(155, 8);
	aClass202_2306 = new IncommingPacket(156, 3);
	aClass202_2307 = new IncommingPacket(157, 5);
	WORLD_TILE_PACKET = new IncommingPacket(158, 3);
	SWITCH_ITEMS_LOOK_PACKET = new IncommingPacket(159, 1);
    }

    IncommingPacket(int i, int i_0_) {
	anInt2187 = -477306055 * i;
	anInt2165 = -1324781857 * i_0_;
    }

    static final void method1903(Class403 class403, int i) {
	try {
	    ((Class403) class403).anInt5239 -= -783761378;
	    int i_1_ = (((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239]);
	    int i_2_ = (((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239 + 1]);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = Class82_Sub6.method886(i_1_, i_2_, false, 1051533242);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("in.tv(").append(')').toString());
	}
    }

    static final void method1904(Class403 class403, byte i) {
	try {
	    ((Class403) class403).anInt5239 -= -783761378;
	    int i_3_ = (((Class403) class403).anIntArray5244[681479919 * ((Class403) class403).anInt5239]);
	    int i_4_ = (((Class403) class403).anIntArray5244[1 + ((Class403) class403).anInt5239 * 681479919]);
	    ((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 += -391880689) * 681479919 - 1)] = i_4_ + i_3_;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("in.yk(").append(')').toString());
	}
    }

    static final void method1905(Class403 class403, byte i) {
	try {
	    Class422_Sub25.aClass298_Sub48_8425.method3540(Class422_Sub25.aClass298_Sub48_8425.aClass422_Sub3_7556, (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]) == 1 ? 1 : 0, -802327901);
	    pb.aClass283_8716.method2667(549218846);
	    Class3.method300(656179282);
	    pb.aBoolean8666 = false;
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("in.aii(").append(')').toString());
	}
    }

    static final void method1906(Class403 class403, byte i) {
	try {
	    String string = (String) (((Class403) class403).anObjectArray5240[(((Class403) class403).anInt5241 -= 969361751) * -203050393]);
	    int i_5_ = 0;
	    if (Class51.method543(string, 1423765975))
		i_5_ = Class216.method1998(string, (short) 6366);
	    Class298_Sub36 class298_sub36 = Class18.method359(OutcommingPacket.aClass198_2074, pb.aClass25_8711.aClass449_330, (byte) 125);
	    class298_sub36.aClass298_Sub53_Sub2_7396.writeInt(i_5_, -1055367891);
	    pb.aClass25_8711.method390(class298_sub36, (byte) -42);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("in.sz(").append(')').toString());
	}
    }

    static final void method1907(Class403 class403, int i) {
	try {
	    Class390 class390 = (((Class403) class403).aBoolean5261 ? ((Class403) class403).aClass390_5247 : ((Class403) class403).aClass390_5246);
	    IComponentDefinition class105 = ((Class390) class390).aClass105_4168;
	    Class119 class119 = ((Class390) class390).aClass119_4167;
	    Class388.method4854(class105, class119, class403, (byte) 16);
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("in.gd(").append(')').toString());
	}
    }
}
