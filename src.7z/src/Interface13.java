/* Interface13 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface13 {
    public static int anInt1 = 2;
}
