/* Interface17 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface17 {
    public boolean method228(Class365_Sub1_Sub1 class365_sub1_sub1);

    public boolean method229(Class365_Sub1_Sub1 class365_sub1_sub1, int i);

    public boolean method230(Class365_Sub1_Sub1 class365_sub1_sub1);
}
