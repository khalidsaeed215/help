/* Interface18 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface18 {
    public long method231();

    public boolean method232(Interface18 interface18_0_);

    public long method233();

    public long method234();

    public boolean method235(Interface18 interface18_1_);

    public boolean method236(Interface18 interface18_2_);
}
