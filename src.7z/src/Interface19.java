/* Interface19 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface19 {
    public boolean method237(Class298_Sub50 class298_sub50, Interface16[] interface16s, int i, Class323 class323);

    public boolean method238(Class298_Sub50 class298_sub50, Interface16[] interface16s, int i, Class323 class323);

    public boolean method239(Class298_Sub50 class298_sub50, Interface16[] interface16s, int i, Class323 class323, int i_0_);
}
