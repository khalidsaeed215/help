/* Interface2 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface2 {
    public void method18(int i, byte[] is, int i_0_);

    public void method19(int i, byte[] is, int i_1_);

    public long method20();

    public int method21();

    public int method22();

    public long method23();

    public long method24();

    public void method25(int i, byte[] is, int i_2_);

    public int method26();

    public void method27(int i, byte[] is, int i_3_);
}
