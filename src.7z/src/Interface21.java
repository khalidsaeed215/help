/* Interface21 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface21 {
    public int getType(int i);

    public int method243();

    public int method244();
}
