/* Interface24 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface24 {
    public int method256(int i);

    public Class463 method257();

    public int method258();

    public Class463 method259();

    public Class463 method260(int i);

    public Class463 method261();
}
