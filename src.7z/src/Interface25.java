/* Interface25 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface25 {
    public void ma(boolean bool);

    public void z(boolean bool);
}
