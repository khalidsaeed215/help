/* Interface26 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface26 {
    public static int anInt9 = 10;
}
