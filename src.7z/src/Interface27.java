/* Interface27 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface27 {
    public boolean method262();

    public boolean method263(String string, int i);

    public boolean method264(int i);

    public boolean method265(String string, int i);

    public boolean method266(String string);

    public boolean method267(String string);

    public boolean method268();

    public boolean method269();

    public boolean method270(String string);
}
