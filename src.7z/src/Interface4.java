/* Interface4 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface4 {
    public long method46(String string);

    public long method47(String string, byte i);

    public long method48(String string);
}
