/* Interface8_Impl1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface8_Impl1 extends Interface8 {
    public int a();

    public int f();

    public int p();

    public int i();

    public int k();
}
