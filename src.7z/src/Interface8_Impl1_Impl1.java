/* Interface8_Impl1_Impl1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface8_Impl1_Impl1 extends Interface8_Impl1 {
    public void b();

    public void d();

    public void x();

    public void u();
}
