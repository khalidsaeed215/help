/* Interface8_Impl1_Impl1_Impl1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface8_Impl1_Impl1_Impl1 extends Interface8_Impl1_Impl1 {
    public void method143();

    public void b();

    public long method144();

    public void d();

    public void u();

    public void x();

    public long method147();

    public long method145();

    public void method146();

    public void method142();

    public void method141();

    public void method148();
}
