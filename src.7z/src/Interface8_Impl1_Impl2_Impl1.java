/* Interface8_Impl1_Impl2_Impl1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface8_Impl1_Impl2_Impl1 extends Interface8_Impl1_Impl2 {
    public void d();

    public void x();

    public void method141();

    public void method142();

    public void u();

    public void method143();

    public long method144();

    public long method145();

    public void method146();

    public void b();

    public long method147();

    public void method148();
}
