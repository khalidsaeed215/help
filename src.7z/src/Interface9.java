/* Interface9 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface9 {
    public void b();

    public void method122(Class179 class179);

    public void method123();

    public void d();

    public void method124(Class179 class179);

    public void x();

    public void method125();

    public void method126();

    public void u();

    public void method127(Class179 class179);

    public void method128();

    public void method129(Class179 class179);
}
