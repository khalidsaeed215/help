/* Interface9_Impl1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface9_Impl1 extends Interface9 {
}
