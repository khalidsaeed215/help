/* Interface9_Impl3 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface9_Impl3 extends Interface9 {
}
