/* Interface_ma - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public interface Interface_ma {
    public int method169();

    public boolean method170(int i, int i_0_);

    public int[] method171(int i, float f, int i_1_, int i_2_, boolean bool, int i_3_);

    public int[] method172(int i, float f, int i_4_, int i_5_, boolean bool, int i_6_);

    public int[] method173(int i, float f, int i_7_, int i_8_, boolean bool);

    public TextureMetrics getTexture(int i, int i_9_);

    public int method175();

    public void method176(int i);

    public int method177(int i);

    public int[] method178(int i, float f, int i_10_, int i_11_, boolean bool);

    public float[] method179(int i, float f, int i_12_, int i_13_, boolean bool);

    public boolean method180(int i);

    public float[] method181(int i, float f, int i_14_, int i_15_, boolean bool, byte i_16_);

    public int[] method182(int i, float f, int i_17_, int i_18_, boolean bool);

    public int[] method183(int i, float f, int i_19_, int i_20_, boolean bool);

    public float[] method184(int i, float f, int i_21_, int i_22_, boolean bool);

    public int method185();

    public int method186();

    public TextureMetrics method187(int i);

    public TextureMetrics method188(int i);

    public void method189();

    public int[] method190(int i, float f, int i_23_, int i_24_, boolean bool);
}
