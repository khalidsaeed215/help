/* Class68 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class MagnetConfig {
	public int anInt671;
	public MagnetConfig aClass68_672;
	public int skin;
	public int point;
	public int anInt675;
	public int anInt676;
	public Class233 aClass233_677;
	public static short[] aShortArray678;
	static String[] aStringArray679;

	public Class190 method775(byte i) {
		try {
			return Class140.method1554(617796067 * skin, 1222993102);
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ct.a(").append(')').toString());
		}
	}

	MagnetConfig translatePoint(int point) {
		try {
			return new MagnetConfig(skin * 617796067, point);
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ct.f(").append(')').toString());
		}
	}

	MagnetConfig(int i, int i_1_) {
		skin = i * -1460732981;
		point = i_1_ * -356109865;
	}

	static void method777(boolean bool, Class298_Sub19_Sub1 class298_sub19_sub1, int i) {
		try {
			Class300.aClass284_3212.method2679(class298_sub19_sub1, 547638939);
			if (bool)
				Class445.method5897(Class114.idx15, Class439.idx14, Class52.idx4, class298_sub19_sub1, Class300.aClass284_3212, (byte) -102);
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ct.p(").append(')').toString());
		}
	}

	static final void method778(Class403 class403, int i) {
		try {
			int i_2_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_2_, (byte) 16);
			Class429.method5758(class105, class403, 1803760029);
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ct.cs(").append(')').toString());
		}
	}

	static final void method779(Class403 class403, int i) {
		try {
			Shadow.method3478(-2146138663);
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ct.agt(").append(')').toString());
		}
	}

	static final void method780(Class403 class403, int i) {
		try {
			Class211.method1947(-783761378);
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ct.ahr(").append(')').toString());
		}
	}

	public static boolean method781(int i) {
		try {
			if (0 != Class79.anInt734 * 617004265)
				return true;
			return Class79.aClass298_Sub19_Sub1_737.method2985(2054273045);
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ct.s(").append(')').toString());
		}
	}

	static final void method782(IComponentDefinition class105, Class119 class119, Class403 class403, int i) {
		try {
			String string = (String) (((Class403) class403).anObjectArray5240[(((Class403) class403).anInt5241 -= 969361751) * -203050393]);
			if (Class298_Sub6.method2863(string, class403, -1567676113) != null)
				string = string.substring(0, string.length() - 1);
			class105.anObjectArray1250 = Class128_Sub2.method1441(string, class403, -2046058202);
			class105.aBoolean1238 = true;
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ct.ny(").append(')').toString());
		}
	}

	static Class98_Sub3 method783(RsByteBuffer class298_sub53, int i) {
		try {
			return new Class98_Sub3(class298_sub53.readShort(1676982896), class298_sub53.readShort(1624262508), class298_sub53.readShort(1772094350), class298_sub53.readShort(1995341177), class298_sub53.read24BitUnsignedInteger((byte) -98), class298_sub53.read24BitUnsignedInteger((byte) -6), class298_sub53.readUnsignedByte());
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ct.r(").append(')').toString());
		}
	}

	static final int method784(int i, byte i_3_) {
		try {
			return i >> 11 & 0x7f;
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ct.p(").append(')').toString());
		}
	}

	public static Class298_Sub50_Sub2 method785(int i, int i_4_, int i_5_, int i_6_, byte i_7_) {
		try {
			synchronized (Class298_Sub50_Sub2.aClass298_Sub50_Sub2Array9770) {
				Class298_Sub50_Sub2 class298_sub50_sub2;
				if (Class446.anInt5614 * 656179585 == 0)
					class298_sub50_sub2 = new Class298_Sub50_Sub2();
				else
					class298_sub50_sub2 = (Class298_Sub50_Sub2.aClass298_Sub50_Sub2Array9770[(Class446.anInt5614 -= 453361281) * 656179585]);
				((Class298_Sub50_Sub2) class298_sub50_sub2).anInt9762 = 1060004021 * i;
				((Class298_Sub50_Sub2) class298_sub50_sub2).anInt9748 = i_4_ * 1196163649;
				((Class298_Sub50_Sub2) class298_sub50_sub2).anInt9771 = i_5_ * -398953071;
				((Class298_Sub50_Sub2) class298_sub50_sub2).anInt9772 = 1960569825 * i_6_;
				((Class298_Sub50_Sub2) class298_sub50_sub2).aLong9768 = Class122.method1319((byte) 1) * -212908250700906157L;
				Class298_Sub50_Sub2 class298_sub50_sub2_8_ = class298_sub50_sub2;
				return class298_sub50_sub2_8_;
			}
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ct.av(").append(')').toString());
		}
	}

	static final void method786(Class403 class403, byte i) {
		try {
			int i_9_ = (((Class403) class403).anIntArray5244[((((Class403) class403).anInt5239 -= -391880689) * 681479919)]);
			IComponentDefinition class105 = Class50.getIComponentDefinitions(i_9_, (byte) 31);
			Class119 class119 = Class389.aClass119Array4165[i_9_ >> 16];
			Class21.method365(class105, class119, true, 2, class403, -1869405446);
		}
		catch (RuntimeException runtimeexception) {
			throw Class346.method4175(runtimeexception, new StringBuilder().append("ct.hb(").append(')').toString());
		}
	}
}
