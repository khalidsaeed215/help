/* Class32 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class OpenGlArrayBufferPointer {
    short aShort395;
    byte aByte396;
    Interface1 buffer;
    byte aByte398;

    OpenGlArrayBufferPointer(Interface1 interface1, int i, int i_0_, int i_1_) {
	((OpenGlArrayBufferPointer) this).buffer = interface1;
	((OpenGlArrayBufferPointer) this).aShort395 = (short) i;
	((OpenGlArrayBufferPointer) this).aByte396 = (byte) i_0_;
	((OpenGlArrayBufferPointer) this).aByte398 = (byte) i_1_;
    }
}
