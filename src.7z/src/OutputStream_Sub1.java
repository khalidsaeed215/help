/* OutputStream_Sub1 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
import java.io.IOException;
import java.io.OutputStream;

public class OutputStream_Sub1 extends OutputStream {
    public void write(int i) throws IOException {
	try {
	    throw new IOException();
	}
	catch (RuntimeException runtimeexception) {
	    throw Class346.method4175(runtimeexception, new StringBuilder().append("aeh.write(").append(')').toString());
	}
    }

    OutputStream_Sub1() {
	/* empty */
    }
}
