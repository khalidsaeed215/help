/* Class454 - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class Tuple {
    public Object first;
    public Object second;

    public Tuple(Object object, Object object_0_) {
	first = object;
	second = object_0_;
    }
}
