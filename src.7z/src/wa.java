/* wa - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

public class wa extends Class_ta implements Interface25 {
    long nativeid;

    
    protected void finalize() {
	if (nativeid != 0L)
	    Class71.method809(this, (short) 18758);
    }
    
    public native void ma(boolean bool);

    native void b(ja var_ja, ba var_ba, int i, int i_0_, int[] is, int[] is_1_);

    native void l(ja var_ja, ba var_ba, int i, int i_2_, int[] is, int[] is_3_);

    public native void z(boolean bool);

    native void a(ja var_ja, ba var_ba, int i, int i_4_, int[] is, int[] is_5_);

    native void f(ja var_ja, ba var_ba, int i, int i_6_, int[] is, int[] is_7_);

    wa(ja var_ja, ba var_ba, int i, int i_8_, int[] is, int[] is_9_) {
	l(var_ja, var_ba, i, i_8_, is, is_9_);
    }
}
